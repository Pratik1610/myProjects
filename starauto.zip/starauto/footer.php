  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Designed &amp; Developed By | Pratik Deshpande</b>
    </div>
    <strong>Copyright &copy; 2021 Star Auto.  All Rights
    Reserved.</strong>
  </footer>