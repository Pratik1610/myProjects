<?php session_start(); 
include("authentication.php");
if(!empty($_SESSION['variable'])){
	header("location: main.php");
	 }
else {
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Star Auto | Login</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!--<link rel="icon" type="image/png" href="../images/favicon.png">-->
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">

 
  <!-- Google Font -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition login-page">
<div class="login-box">
  
  <!-- /.login-logo -->
  <div class="login-logo">
   <h2 style="color:red; font-size:32px;">Star Auto</h2>
    <p class="login-box-msg">Welcome To The Admin Panel</p>
  </div>
  <div class="login-box-body">
  
   <?php
  if(@$_GET['msg']=="logout")
  {
  ?>
  <p class="login-box-msg" style="font-size:15px !important; color:red;">Logged Out Successfully!</p>
  <?php
  }
  ?>
    
    <p class="login-box-msg" style="font-size:15px !important;">Sign In To Start Your Session</p>

    <form method="post" enctype="multipart/form-data">
      <div class="form-group has-feedback">
        <input type="text" class="form-control" name="username" placeholder="User Name">
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" name="password" placeholder="Password">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
        <div class="col-xs-8">
          
        </div>
        <!-- /.col -->
        <div class="col-xs-4">
        	<input type="submit" class="btn btn-primary btn-block btn-flat" value="Login" name="login">
         
        </div>
        <!-- /.col -->
      </div>
    </form>
    
    <?php
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      @$myusername = mysqli_real_escape_string($db,$_POST['username']);
      @$mypassword = mysqli_real_escape_string($db,$_POST['password']); 
      
      $sql = "SELECT * FROM master_admin WHERE username = '$myusername' and password = '$mypassword'";
      @$result = mysqli_query($db,$sql);
      @$row = mysqli_fetch_array($result);
      if($row>0){
$_SESSION['variable']=$row['username'];
$_SESSION['roll']='sa';

/*Time Tracking*/

/*$tmforre = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
$logintime=$tmforre->format('H:i:s');

$insert_time=date("Y-m-d");
$cdate=$insert_time;
		  
$loginby=$row['id'];

$sql = ("INSERT INTO login_report (logintime, cdate, loginby) VALUES ('$logintime', '$cdate', '$loginby')"); 
      
   $retval = mysqli_query($db,$sql );
   
   if(! $retval ) {
      die('Could not enter data: ' . mysqli_error($db));
   }
   else {
	   
header("location: main.php");
}*/
/*Time Tracking*/	  
		  
header("location: main.php");
}
else
	{?>
    
    <div style="color:#F00;;" align="center">
    <?php
		 echo "Email or Password is Not Match";
	
	}
   }
?>

    

  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->
<?php }?>

<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
</body>
</html>
