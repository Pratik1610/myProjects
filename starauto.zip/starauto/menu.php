 <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
       <?php  $id=$_SESSION['variable'];
$ccad = mysqli_query($db,"SELECT * FROM master_admin where username='$id'");
$rowad=mysqli_fetch_object($ccad);
?>
        <div class="pull-left image">
        <img src="images/<?php echo !is_numeric($rowad->pic) ? $rowad->pic : 'placeholderimg.png' ; ?>" class="img-circle" alt="User Profile">
        </div>
        <div class="pull-left info">
       
          <p><?php echo $rowad->name; ?></p>
          <a href="index.php"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- search form -->
    
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        
        <li class=""><a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        
        <li class="treeview">
          <a href="#">
            <i class="fa fa-align-justify" aria-hidden="true"></i>
            <span>Entry</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
     <li><a href="purchase-entry.php"><i class="fa fa-file" aria-hidden="true"></i>Purchase Entry</a></li>
     <li><a href="sell-entry.php"><i class="fa fa-file" aria-hidden="true"></i>Sell Entry</a></li>
         </ul>
        </li>
        
	<li class=""><a href="file-upload.php"><i class="fa fa-cloud-upload" aria-hidden="true"></i> <span>File Upload</span></a></li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-align-justify" aria-hidden="true"></i>
           
            <span>View</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
          <li><a href="purchase-view.php"><i class="fa fa-file" aria-hidden="true"></i>Purchase View</a></li>
          <li><a href="sell-view.php"><i class="fa fa-file" aria-hidden="true"></i> Sell View</a></li>
          </ul>
        </li>
        
		<li class=""><a href="invoice.php"><i class="fa fa-print" aria-hidden="true"></i> <span>Invoice</span></a></li>
		
      </ul>
	  
    </section>
    <!-- /.sidebar -->
	
  </aside>
  <script>
  $("#whcolor").click(function(){
	  $(".content-wrapper").css("background-color","white");
  })
    $("#grcolor").click(function(){
	  
	  $(".content-wrapper").css("background-color","#ecf0f5");
  })
  $("#hdgrcolor").click(function(){
	  
	  $(".navbar-static-top").css("background-color","#525354");
  })
  $("#hbluecolor").click(function(){
	  
	  $(".navbar-static-top").css("background-color","#337ab7");
  })
  $("#slgrcolor").click(function(){
	  
	  $(".main-sidebar").css("background-color","#525354");
  })
  $("#swhgrcolor").click(function(){
	  
	  $(".main-sidebar").css("background-color","#337ab7");
  })
  </script>