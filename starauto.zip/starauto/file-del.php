<?php
include "authentication.php";

$id=$_GET["id"];
// delete country image
$seldoc=mysqli_query($db,"select name from files where id='$id'");
$docrow=mysqli_fetch_object($seldoc);

unlink('docs/'.$docrow->name);

//delete country in database
$delsql=mysqli_query($db,"delete from files where id='$id'");

echo "<script> alert('File Deleted Successfully') </script>";
echo "<script> window.location.href='file-upload.php' </script>";

?>