<?php
include "authentication.php";

$id=$_GET["id"];
$ref=$_SERVER["HTTP_REFERER"];

$delsql=mysqli_query($db,"delete from purchase where id='$id'");
echo "<script> alert('Purchase Item Deleted Successfully') </script>";
echo "<script> window.location.href='$ref' </script>";

?>