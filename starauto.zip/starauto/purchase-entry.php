<?php session_start(); 
include("authentication.php");
$role = $_SESSION['roll'];
if(empty($_SESSION['variable']) || $role!="sa"){
	header("location: index.php");
	 }
else { ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Star Auto | Purchase Entry</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="icon" type="image/png" href="../images/favicon.png">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- daterange picker -->
  <link rel="stylesheet" href="bower_components/bootstrap-daterangepicker/daterangepicker.css">
  <!-- bootstrap datepicker -->
  <link rel="stylesheet" href="bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
  <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="plugins/iCheck/all.css">
  <!-- Bootstrap Color Picker -->
  <link rel="stylesheet" href="bower_components/bootstrap-colorpicker/dist/css/bootstrap-colorpicker.min.css">
  <!-- Bootstrap time Picker -->
  <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.min.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="bower_components/select2/dist/css/select2.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

<?php include("header.php"); ?>
 <?php include("menu.php"); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      Purchase Entry
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="#">Entry</a></li>
        <li><a href="#">Purchase Entry</a></li>
        
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
      <div class="box box-default">
        <div class="box-header with-border">
         

          
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="row">
            <div class="col-md-12">
            <form role="form">
              <div class="box-body">
              <div class="form-group">
                  <label>Purchase Date</label>
                  <input type="date" name="pur_date" class="form-control" required>
                </div>
                
                
                <div class="form-group">
                  <label>Customer Name</label>
                  <input type="text" name="cust_name" class="form-control"  placeholder="Customer Name">
                </div>
                
                
                <div class="form-group">
                  <label>Vehicle</label>
                  <input type="text" name="vehicle" class="form-control" placeholder="Vehicle">
                </div>
				
				<div class="form-group">
                  <label>Model</label>
                  <input type="text" name="model" class="form-control" placeholder="model">
                </div>
				
				<div class="form-group">
                 <label>Registration Number</label>
                  <input type="text" name="regno" class="form-control" placeholder="Registration Number">
                </div>
				
				<div class="form-group">
                 <label>Cost</label>
                  <input type="text" name="cost" class="form-control" placeholder="Cost">
                </div>
                
                <div class="form-group">
                 <label>Expense</label>
                  <input type="text" name="expense" class="form-control" placeholder="Expense">
                </div>
				
				<div class="form-group">
                 <label>Mobile</label>
                  <input type="text" name="mobile" class="form-control" placeholder="Mobile Number">
                </div>
				
               <div class="form-group"> 
                 <label>Note/ Remark</label>
                
                <textarea name="remark" class="form-control" rows="10" cols="80">
                                  
                    </textarea>
                </div>
                
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
              <input type="submit" class="btn btn-primary" name="submit" value="Submit">
               
              </div>
            </form>
<?php
if(isset($_REQUEST['submit'])){
$date=mysqli_real_escape_string($db,$_REQUEST['pur_date']);
$name=mysqli_real_escape_string($db,$_REQUEST['cust_name']);
$vehicle=mysqli_real_escape_string($db, $_REQUEST['vehicle']);
$model=mysqli_real_escape_string($db, $_REQUEST['model']);
$regno=mysqli_real_escape_string($db, $_REQUEST['regno']);
$cost=mysqli_real_escape_string($db, $_REQUEST['cost']);
$expense=mysqli_real_escape_string($db, $_REQUEST['expense']);
$mobile=mysqli_real_escape_string($db, $_REQUEST['mobile']);
$remark=mysqli_real_escape_string($db, $_REQUEST['remark']);

$sql = ("insert into purchase values('','$date','$name','$vehicle','$model','$regno','$cost','$expense','$remark','$mobile')"); 
      
   $retval = mysqli_query($db,$sql );
   
   if(! $retval ) {
      die('Could not enter data: ' . mysqli_error($db));
   }
   else {
	   
		echo "<script> alert('Purchase Entry Added Successfully') </script>";
	   	echo "<script> window.location = 'purchase-entry.php' </script>";
} 
}
	  ?> 
            
            
              
              <!-- /.form-group -->
              
              <!-- /.form-group -->
            </div>
            <!-- /.col -->
            
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </div>
        <!-- /.box-body -->
        
      </div>
      <!-- /.box -->

      
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php include("footer.php") ?>
</div>
<!-- ./wrapper -->
<?php }?>

<!-- jQuery 3 -->
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- CK Editor -->
<script src="bower_components/ckeditor/ckeditor.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<script>
  $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('editor1')
    //bootstrap WYSIHTML5 - text editor
    $('.textarea').wysihtml5()
  })
</script>
</body>
</html>
