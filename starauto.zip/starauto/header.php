<header class="main-header">

    <!-- Logo -->
    <a href="index.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>C</b>MS</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Star Auto</span>
    </a>

    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <!--<a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>-->
      <!-- Navbar Right Menu -->


      
      <div class="navbar-custom-menu">
      
      
      
        <ul class="nav navbar-nav">
        
<!-- Pop up start-->      
<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script>
function blinker()
{
$('#blink_me').fadeOut(1500);
$('#blink_me').fadeIn(1500);
}
setInterval(blinker,1000);
</script>
        
     <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">

              <i class="fa fa-cog" aria-hidden="true"></i>
              <span class="hidden-xs">Setting</span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
             
              <!-- Menu Body -->
              
              <!-- Menu Footer-->
              <li class="user-footer">
               
                <div class="pull-right">
                  <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
				  
                </div>
				<a href="usr-profile.php"><i class="fa fa-user-o" aria-hidden="true"></i> Manage Account</a>
              </li>
			  <li>
						  <!-- <div class="container" style="padding-bottom:130px;">
				<h4>Filters</h3>
				<label>Theme Background</label><br>
				<input type="radio" id="whcolor" name="color"> White
				<input type="radio" id="grcolor" name="color" checked> Grey
				<br><br>
				<label>Header Background</label><br>
				<input type="radio" id="hbluecolor" name="headcolor"> Blue
				<input type="radio" id="hdgrcolor" name="headcolor" checked> Dark Grey
				<br><br>
				<label>Sidebar Background</label><br>
				<input type="radio" id="slgrcolor" name="sidecolor" checked> Dark Grey
				<input type="radio" id="swhgrcolor" name="sidecolor"> Blue
				</div>-->
			  
			  </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          
        </ul>
      </div>

    </nav>
  </header>