<?php
include "authentication.php";

$bid=$_GET["bid"];
$ref=$_SERVER["HTTP_REFERER"];

$delsql=mysqli_query($db,"delete from invoice where id='$bid'");
echo "<script> alert('Invoice Deleted Successfully') </script>";
echo "<script> window.location.href='$ref' </script>";

?>