<?php
include "authentication.php";

$id=$_GET["id"];
$ref=$_SERVER["HTTP_REFERER"];

$delsql=mysqli_query($db,"delete from sell where id='$id'");
echo "<script> alert('Sell Item Deleted Successfully') </script>";
echo "<script> window.location.href='$ref' </script>";

?>