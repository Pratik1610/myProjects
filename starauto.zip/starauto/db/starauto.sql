-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 03, 2019 at 02:31 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `starauto`
--

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE IF NOT EXISTS `files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `name`) VALUES
(2, '1556621975blog1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE IF NOT EXISTS `invoice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perticulars` varchar(100) NOT NULL,
  `qty` varchar(100) NOT NULL,
  `rate` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `net_amount` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`id`, `perticulars`, `qty`, `rate`, `amount`, `net_amount`) VALUES
(2, 'test', '1', '100', '100', '100');

-- --------------------------------------------------------

--
-- Table structure for table `master_admin`
--

CREATE TABLE IF NOT EXISTS `master_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `pic` varchar(200) NOT NULL,
  `username` varchar(555) NOT NULL,
  `password` varchar(555) NOT NULL,
  `roll` varchar(255) NOT NULL,
  `created` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `master_admin`
--

INSERT INTO `master_admin` (`id`, `name`, `pic`, `username`, `password`, `roll`, `created`) VALUES
(1, 'Administrator', '1234', 'admin', 'admin', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE IF NOT EXISTS `purchase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchse_date` varchar(200) NOT NULL,
  `customer_name` varchar(200) NOT NULL,
  `vehicle` varchar(200) NOT NULL,
  `model` varchar(200) NOT NULL,
  `registration_no` varchar(200) NOT NULL,
  `cost` varchar(100) NOT NULL,
  `expense` varchar(100) NOT NULL,
  `remark` text NOT NULL,
  `mobile` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`id`, `purchse_date`, `customer_name`, `vehicle`, `model`, `registration_no`, `cost`, `expense`, `remark`, `mobile`) VALUES
(1, '2019-04-27', 'pratik deshpande', 'test', 'test', 'test', 'test', 'test', '                                  \n                    testing', '9907120508');

-- --------------------------------------------------------

--
-- Table structure for table `sell`
--

CREATE TABLE IF NOT EXISTS `sell` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `selling_date` varchar(200) NOT NULL,
  `customer_name` varchar(200) NOT NULL,
  `vehicle` varchar(200) NOT NULL,
  `model` varchar(100) NOT NULL,
  `registration_no` varchar(200) NOT NULL,
  `address` text NOT NULL,
  `adhar_no` varchar(100) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `sell`
--

INSERT INTO `sell` (`id`, `selling_date`, `customer_name`, `vehicle`, `model`, `registration_no`, `address`, `adhar_no`, `mobile`) VALUES
(1, '2019-04-27', 'pratik deshpande', 'test', 'test', 'test', 'ward number 8 , raman nagar', 'resr', '9907120508');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
