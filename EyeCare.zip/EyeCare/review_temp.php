<!DOCTYPE html>
<?php
    ob_start();
	require_once 'logincheck.php';
	require_once 'authentication.php';
?>
<html lang = "eng">
	<head>
		<title>EyeCare</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "shortcut icon" href = "images/eye-gb51ecb13e_1280.PNG" />
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/customize.css" />
	</head>
<body>
	<div class = "navbar navbar-default navbar-fixed-top">
		<img src = "images/eye-gb51ecb13e_1280.PNG" style = "float:left;" height = "55px" /><label class = "navbar-brand">EyeCare</label>
			<?php
				$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
				$q = $conn->query("SELECT * FROM `user` WHERE `user_id` = '$_SESSION[user_id]'") or die(mysqli_error());
				$f = $q->fetch_array();
			?>
			<ul class = "nav navbar-nav navbar-right">	
			    
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#" style="color:white;">
						<span class = "glyphicon glyphicon-user"></span>
						<?php
							echo $f['firstname']." ".$f['middlename']." ".$f['lastname'];
							$conn->close();
						?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
					<li>
						<a class = "me" href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
	</div>
		<br />
		<br />
		<br />
		<div class = "panel panel-success">	
		<?php
			$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
			$query = $conn->query("SELECT * FROM `appointments` WHERE `id` = '$_GET[apid]'") or die(mysqli_error());
			$fetch = $query->fetch_array();
			$pid=$fetch["pid"]; // patient id
			$selp=mysqli_query($db,"select * from itr where patient_id='$pid'");
			$rowp=mysqli_fetch_array($selp);
			
			$selreview = mysqli_query($db,"SELECT * FROM `review_temp` where pid='$pid' and apid='".$_GET['apid']."'") or die(mysqli_error());
			$fetchreview=mysqli_fetch_array($selreview);
		?>
			<div class = "panel-heading">
				<label>ADD Prescription>> Review After</label>
			</div>
			<div class = "panel-body">
					<div class = "panel panel-default">
					<div class = "panel-heading">
					  <label>Patient Details</label>
					  <p><strong>Patient Name: </strong><?php echo ucwords($fetch["patient_name"]);?> &nbsp; &nbsp; 
				   <strong>Gender: </strong><?php echo ucwords($rowp["gender"]);?> &nbsp; &nbsp; 
				</p>
				<p><strong>Address: </strong><?php 
				if(!empty($rowp["house"]))
				{
					echo $rowp["house"]." ";
					$address=$rowp["house"]." ";
				}
				if(!empty($rowp["street"]))
				{
					echo $rowp["street"]." ";
					$address.=$rowp["street"]." ";
				}
				if(!empty($rowp["locality"]))
				{
					echo $rowp["locality"]." ";
					$address.=$rowp["locality"]." ";
				}
				if(!empty($rowp["city"]))
				{
					echo ",".$rowp["city"]." ";
					$address.=$rowp["city"]." ";
				}
				if(!empty($rowp["state"]))
				{
					echo $rowp["state"]." ";
					$address.=$rowp["state"]." ";
				}
				if(!empty($rowp["pin"]))
				{
					echo $rowp["pin"]." ";
					$address.=$rowp["pin"]." ";
				}
				?> &nbsp; &nbsp; 
				<strong>Age: </strong><?php echo ucwords($rowp["age"]);?><span> Years</span>
				</p>
					</div>
					</div>
					<form id = "form_admin" method = "POST" enctype = "multi-part/form-data" >
					    <ul class="nav nav-tabs">
							<li><a href="prescription_add.php?apid=<?php echo $_GET['apid'];?>">C/o</a></li>
							<li><a href="diagnosis_temp.php?apid=<?php echo $_GET['apid'];?>">Diagnosis</a></li>
							<li><a href="rx_temp.php?apid=<?php echo $_GET['apid'];?>">Rx</a></li>
							<li><a href="glasses_temp.php?apid=<?php echo $_GET['apid'];?>">Glasses</a></li>
							<li><a href="advice_temp.php?apid=<?php echo $_GET['apid'];?>">Advice</a></li>
							<li  class="active"><a href="review_temp.php?apid=<?php echo $_GET['apid'];?>">Review</a></li>
							<li><a href="examination_temp.php?apid=<?php echo $_GET['apid'];?>">Examination</a></li>
							<li><a href="followup_temp.php?apid=<?php echo $_GET['apid'];?>">Followup Notes</a></li>
						</ul>
						<br>
						<br>
							<input type="hidden" name="apid" value="<?php echo $_GET["apid"];?>">
							<input type="hidden" name="pid" value="<?php echo $pid;?>">
						<div class="form-inline">
						<label>Review After</label>
						<select name="ra" id="ra" class="form-control" required>
						    <?php 
															   if(!empty($fetchreview["duration"]))
															   {
															?>
															<option><?php echo $fetchreview["duration"]; ?></option>
															<?php
															   }
															   else
															   {
																   ?>
							<option value="">----Select Duration-----</option>
							
							<?php
															   }
							 $selra=mysqli_query($db,"select distinct duration from prescription_analysis where duration!=''");
							 while($rowra=mysqli_fetch_array($selra))
							 {
							?>
							<option><?php echo $rowra["duration"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 <?php 
						   if(mysqli_num_rows($selreview)==0)
						   {
						?>
						<input type="submit" name="submit" id="submit" class="btn btn-primary" value="Add">
						<?php 
						   }
						   else
						   {
						   ?>
						   <button  class = "btn btn-warning" name = "edit" ><span class = "glyphicon glyphicon-edit"></span> SAVE</button>
							 <?php
						   }
						   ?>
						</div>
						<br>
						<br>
					</form>
					<?php
					  if(isset($_POST["submit"]))
					  {
						  $ra=mysqli_real_escape_string($db,$_POST['ra']);
						  $apid=mysqli_real_escape_string($db,$_POST['apid']); // appointments id
						  $pid=mysqli_real_escape_string($db,$_POST['pid']); // patient id
						  $insdate=date("Y-m-d");
					  $inssql=mysqli_query($db,"insert into review_temp values('','$pid','$apid','$ra','$insdate')");
					  if($inssql)
					  {
						  echo "<script> window.location.href='review_temp.php?apid=$apid' </script>";
					  }
					  }
					  elseif(isset($_POST["edit"]))
					  {
						 $ra=mysqli_real_escape_string($db,$_POST['ra']);
						  $apid=mysqli_real_escape_string($db,$_POST['apid']); // appointments id
						  $pid=mysqli_real_escape_string($db,$_POST['pid']); // patient id
						  $insdate=date("Y-m-d");
						  $updsql=mysqli_query($db,"UPDATE `review_temp` SET `duration`='$ra',`ins_date`='$insdate' WHERE pid='$pid' and apid='".$_GET["apid"]."'");
						  if($updsql)
						  {
							  echo "<script> alert('Saved Successfully!') </script>";
							  echo "<script> window.location.href='review_temp.php?apid=$apid' </script>";
						  }
						  
					  }
					?>
			</div>
		</div>	
	<div id = "footer">
		<label class = "footer-title">&copy; Copyright EyeCare 2022</label>
	</div>
<?php require'script.php' ?>
<script type = "text/javascript">
    $(document).ready(function() {
		$("#submit").attr("disabled",true);
        function disableBack() { window.history.forward() }

        window.onload = disableBack();
        window.onpageshow = function(evt) { if (evt.persisted) disableBack() }
	});
</script>
<script type = "text/javascript">
$("#ra").change(function(){
	$("#submit").attr("disabled",false);
})
</script>
</body>
</html>