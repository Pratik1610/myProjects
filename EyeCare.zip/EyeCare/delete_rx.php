<?php 
include "authentication.php";
$id=$_GET["id"];
$sql=mysqli_query($db,"delete from rx_temp where id='$id'");
$ref=$_SERVER["HTTP_REFERER"];
echo "<script> alert('Deleted Successfully!') </script>";
echo "<script> window.location.href='$ref' </script>";
?>