<!DOCTYPE html>
<?php
 @date_default_timezone_set("Asia/Kolkata");
	require_once 'logincheck.php';
	require_once 'authentication.php';
	$date = date("Y", strtotime("+ 8 HOURS"));
	$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
	
	// get all appointment data
	$cur=date('m/d/Y');
	@$apid=$_GET["apid"];
	@$pid=$_GET["pid"];
	if(!isset($_GET["date"]))
					{
						$chkpres=mysqli_query($db,"select * from prescriptions where appointment_id='$apid' OR patient_id='$pid' order by id desc limit 1");
					}
					else{
						$chkpres=mysqli_query($db,"select * from prescriptions where appointment_id='$apid' OR patient_id='$pid' and pres_date='".$_GET["date"]."'");
					}
					$checksql=mysqli_query($db,"select * from patients_visits where patient_id='$pid' order by id desc");
?>
<html lang = "eng">
	<head>
		<title>EyeCare</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!--<link rel = "shortcut icon" href = "../images/eye-gb51ecb13e_1280.PNG" />-->
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/customize.css" />
		<?php require 'script.php'?>
		 <style>
    .invoice-box {
        max-width: 800px;
        margin: auto;
        padding: 30px;
        border: 1px solid #eee;
        box-shadow: 0 0 10px rgba(0, 0, 0, .15);
        font-size: 16px;
        line-height: 24px;
        font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
        color: #555;
    }
    
    .invoice-box table {
        width: 100%;
        line-height: inherit;
        text-align: left;
    }
    
    .invoice-box table td {
        padding: 5px;
        vertical-align: top;
		
    }
    
    .invoice-box table tr td:nth-child(2) {
        text-align: right;
    }
    
    .invoice-box table tr.top table td {
        padding-bottom: 20px;
    }
    
    .invoice-box table tr.top table td.title {
        font-size: 45px;
        line-height: 45px;
        color: #333;
    }
    
    .invoice-box table tr.information table td {
        padding-bottom: 40px;
    }
    
    .invoice-box table tr.heading td {
        background: #eee;
        border-bottom: 1px solid #ddd;
        font-weight: bold;
    }
    
    .invoice-box table tr.details td {
        padding-bottom: 20px;
    }
    
    .invoice-box table tr.item td{
        border-bottom: 1px solid #eee;
    }
    
    .invoice-box table tr.item.last td {
        border-bottom: none;
    }
    
    .invoice-box table tr.total td:nth-child(2) {
        border-top: 2px solid #eee;
        font-weight: bold;
    }
    
    @media only screen and (max-width: 600px) {
        .invoice-box table tr.top table td {
            width: 100%;
            display: block;
            text-align: center;
        }
        
        .invoice-box table tr.information table td {
            width: 100%;
            display: block;
            text-align: center;
        }
    }
    
    /** RTL **/
    .rtl {
        direction: rtl;
        font-family: Tahoma, 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
    }
    
    .rtl table {
        text-align: right;
    }
    
    .rtl table tr td:nth-child(2) {
        text-align: left;
    }
	#doPrint{
		padding:5px;
		background:#1e38b7;
		color:white;
		border:1px solid black;
		cursor:pointer;
	}
    </style>
	</head>
<body>
	<div class = "navbar navbar-default navbar-fixed-top">
		<img src = "images/eye-gb51ecb13e_1280.PNG" style = "float:left;" height = "55px" /><label class = "navbar-brand">EyeCare</label>
		<?php 
			$q = $conn->query("SELECT * FROM `user` WHERE `user_id` = $_SESSION[user_id]") or die(mysqli_error());
			$f = $q->fetch_array();
		?>
			<ul class = "nav navbar-nav navbar-right">
			       <li><a href="home.php" style="color:#fff; font-size:16px;"><span class = "glyphicon glyphicon-hand-left"></span> Back to the dashboard</a></li>
				  <li class = "dropdown"><a href="#" class = "user dropdown-toggle" style="color:white;" data-toggle = "dropdown">
				  <span class = "glyphicon glyphicon-folder-close"></span>
				  Visits<b class = "caret"></b></a>
				  <ul class = "dropdown-menu">
								<?php 
							if(mysqli_num_rows($checksql)==0)
							{
							?>
									<li><a href = "prescription_add.php?apid=<?php echo @$_GET['apid'];?>"><i class = "glyphicon glyphicon-plus"></i> Add New Visit</a></li>
									<?php
							}
							else
							{
								while($rowchk=mysqli_fetch_array($checksql))
								{
							?>
							<li><a href = "prescription.php?apid=<?php echo @$_GET['apid'];?>&date=<?php echo $rowchk["visit_date"];?>&pid=<?php echo $rowchk["patient_id"]; ?>"><i class = "glyphicon glyphicon-folder-open"></i> Visit- <?php echo date("d-m-Y",strtotime($rowchk["visit_date"]));?></a></li>
							<?php
								}
								?>
								<li><a href = "prescription_add.php?apid=<?php echo @$_GET['apid'];?>"><i class = "glyphicon glyphicon-plus"></i> Add New Visit</a></li>
								<?php
							}
							?>
				</ul>
				  </li>
				<li class = "dropdown">
					<a class = "user dropdown-toggle" style="color:white;" data-toggle = "dropdown" href = "#">
						<span class = "glyphicon glyphicon-user"></span>
						<?php 
							echo $f['firstname']." ".$f["middlename"]." ".$f['lastname'];
						?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
					<li>
						<a class = "me" href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
	</div>
		<br />
		<br />
		<br />
		<div class = "well">
		<div class="panel-heading panel-success">
		<?php
		 if(mysqli_fetch_array($chkpres)>0)
		 {
			 if(!isset($_GET["date"]))
			 {
		 ?>
		 
		 <h2 class="text-center"><?php echo "Latest Prescription ";?></h2>
		 <?php
			 }
			 else
			 {
			 ?>
				<h2 class="text-center"><?php echo "Prescription : ".date("d-m-Y",strtotime($_GET["date"]));?></h2>	
			 <?php 
			 }
			 ?>
		   <button id="doPrint"><span class = "glyphicon glyphicon-print"></span> Click here to print</button>
		   <a href="lab_report_form.php?pid=<?php echo $_GET["pid"];?>" class="btn btn-success"><span class = "glyphicon glyphicon-plus"></span> Create Lab Report</a>
		   <a href="lab_report.php?pid=<?php echo $_GET["pid"];?>" class="btn btn-warning"><span class = "glyphicon glyphicon-file"></span> View Lab Report</a>
		   <?php 
		 }
		   ?>
		</div>
			<div id="chartContainer" style="width: 100%; height: 700px; overflow-y:scroll; background:white;">
			   	<?php 
				if(mysqli_num_rows($checksql)==0)
				{
					echo "<h2 class='text-center'>NO Prescription yet!</h2>";
				}
				else
				{
					if(!isset($_GET["date"]))
					{
					$selpres=mysqli_query($db,"select * from prescriptions where patient_id='$pid' order by id desc limit 1");
					$selglass=mysqli_query($db,"select * from glasses where patient_id='$pid' order by id desc limit 1");
					}
					else
					{
					$selpres=mysqli_query($db,"select * from prescriptions where patient_id='$pid' and pres_date='".$_GET["date"]."'");
					$selglass=mysqli_query($db,"select * from glasses where patient_id='$pid' and ins_date='".$_GET["date"]."'");
					}
					$rowpres=mysqli_fetch_array($selpres);
					$fetchglass=mysqli_fetch_array($selglass);
				?>
			<p style="text-align: center;"><span style="color: #ff0000;"><strong>Clinic name with address</strong></span></p>
			<table width="1013">
				<tbody>
				<tr>
				<td width="128"><?php echo ucwords($rowpres["patient_name"]);?></td>
				<td colspan="5" width="320">&nbsp;</td>
				<td width="64">&nbsp;<?php echo $rowpres["age"];?> yrs /</td>
				<td width="64"><?php echo $rowpres["gender"];?></td>
				<td colspan="2" width="128"><?php echo date("d-m-Y",strtotime($rowpres["pres_date"]));?></td>
				<td width="64">&nbsp;</td>
				<td colspan="2" width="128">Contact number:</td>
				<td colspan="2" width="128"> <?php echo $rowpres["contact_num"];?></td>
				<td width="64">&nbsp;</td>
				</tr>
				<tr>
				<td>C/O-</td>
				<td>&nbsp;</td>
				<td colspan="2">&nbsp;</td>
				<td>&nbsp;</td>
				<td colspan="5">&nbsp;</td>
				<td>&nbsp;</td>
				<td>Address</td>
				<td colspan="3"><?php echo $rowpres["address"];?></td>
				<td>&nbsp;</td>
				</tr>
				<tr>
				<td colspan="6"><?php echo $rowpres["co"];?></td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td colspan="5">&nbsp;</td>
				<td>&nbsp;</td>
				<td colspan="4">&nbsp;</td>
				<td>&nbsp;</td>
				</tr>
				<tr>
				<td colspan="3">&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td colspan="5">&nbsp;</td>
				<td>&nbsp;</td>
				<td colspan="4">&nbsp;</td>
				<td>&nbsp;</td>
				</tr>
				<tr>
				<td colspan="3">&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td colspan="5">&nbsp;</td>
				<td>&nbsp;</td>
				<td colspan="4">&nbsp;</td>
				<td>&nbsp;</td>
				</tr>
				<tr>
				<td>&nbsp;</td>
				<td colspan="4">&nbsp;</td>
				<td>&nbsp;</td>
				<td colspan="4">&nbsp;</td>
				<td>&nbsp;</td>
				<td colspan="4">&nbsp;</td>
				<td>&nbsp;</td>
				</tr>
				<tr>
				<td>&nbsp;</td>
				<td colspan="4">&nbsp;</td>
				<td>&nbsp;</td>
				<td colspan="4">&nbsp;</td>
				<td colspan="2"><span style="color:red;">DATE</span><br>
				 <?php 
				 if(!empty($rowpres["folowup_date"]))
				 {
					 
				 echo !empty($rowpres["folowup_date"])?$rowpres["folowup_date"]:"";
				 }
				 ?>
				</td>
				<td colspan="3"><span style="color:red;">FOLLOW UP NOTES</span><br>
				 <?php echo $rowpres["followup_note"];?>
				</td>
				<td>&nbsp;</td>
				</tr>
				<tr>
				<td><?php echo $rowpres["eye"];?></td>
				<td colspan="4">
				<?php echo nl2br($rowpres["diagnosis"]);?>
				</td>
				<td>&nbsp;</td>
				<td colspan="4">&nbsp;</td>
				<td colspan="2">&nbsp;</td>
				<td colspan="3">&nbsp;</td>
				<td>&nbsp;</td>
				</tr>
				<tr>
				<td>&nbsp;</td>
				<td colspan="4">&nbsp;</td>
				<td>&nbsp;</td>
				<td colspan="4">&nbsp;</td>
				<td colspan="2">&nbsp;</td>
				<td colspan="3">&nbsp;</td>
				<td>&nbsp;</td>
				</tr>
				<tr>
				<td>&nbsp;</td>
				<td>Rx</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td colspan="2">&nbsp;</td>
				<td colspan="2">&nbsp;</td>
				<td colspan="3">&nbsp;</td>
				<td>&nbsp;</td>
				</tr>
				<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td colspan="3">
				<?php echo nl2br($rowpres["drug"]);?>
				</td>
				<td colspan="2">
				<?php echo nl2br($rowpres["freq"]);?>
				</td>
				<td>
				<?php echo nl2br($rowpres["duration"]);?>
				</td>
				<td colspan="2">
				<?php echo nl2br($rowpres["diagnosis_eye"]);?>
				</td>
				<td colspan="2">&nbsp;</td>
				<td colspan="3">&nbsp;</td>
				<td>&nbsp;</td>
				</tr>
				<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td colspan="3">&nbsp;</td>
				<td colspan="2">&nbsp;</td>
				<td>&nbsp;</td>
				<td colspan="2">&nbsp;</td>
				<td colspan="2">&nbsp;</td>
				<td colspan="3">&nbsp;</td>
				<td>&nbsp;</td>
				</tr>
				<tr>
				<td>&nbsp;</td>
				<td colspan="4">&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td colspan="3" width="192">&nbsp;</td>
				<td width="64">&nbsp;</td>
				<td colspan="2" width="128">&nbsp;</td>
				</tr>
				<tr>
				<td colspan="9">Patient is advised to have-</td>
				<td></td>
				</tr>
				<tr>
				<td>&nbsp;</td>
				<td colspan="4">
				<?php echo nl2br($rowpres["advice"]);?></td>
				<td colspan="4">&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td width="64">&nbsp;</td>
				<td>&nbsp;</td>
				<td width="64">&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				</tr>
				
				<tr>
				<td>&nbsp;</td>
				<td colspan="4">&nbsp;</td>
				<td colspan="4">&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td width="64">&nbsp;</td>
				<td width="64">&nbsp;</td>
				<td width="64">&nbsp;</td>
				<td width="64">&nbsp;</td>
				<td>&nbsp;</td>
				</tr>
				
				<tr>
								<td colspan="2">GLASSES-</td>
								</tr>
								<tr>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center"  rowspan="2">&nbsp;</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="8">RE</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="8">LE</td>
								<td  >&nbsp;</td>
								<td  >&nbsp;</td>
								<td  >&nbsp;</td>
								<td  >&nbsp;</td>
								<td  >&nbsp;</td>
								<td>&nbsp;</td>
								</tr>
								<tr>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="2">Sph.</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="2">Cyl.</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="3">Axis</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="1">VA</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="2">Sph.</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="2">Cyl.</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="3">Axis</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="1">VA</td>
								<td  >&nbsp;</td>
								<td  >&nbsp;</td>
								<td  >&nbsp;</td>
								<td  >&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								</tr>
								<tr>
								
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center">Dist.</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="2">
								<?php echo $fetchglass["re_sph"]; ?>
								</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="2">
								<?php echo $fetchglass["re_cyl"]; ?>
								</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="3">
								<?php echo $fetchglass["re_axis"]; ?>
								</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="1">
								<?php echo $fetchglass["re_va"]; ?></td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="2">
								<?php echo $fetchglass["le_sph"]; ?>
								</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="2">
								<?php echo $fetchglass["le_cyl"]; ?>
								</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="3">
								<?php echo $fetchglass["le_axis"]; ?>
								</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="1"><?php echo $fetchglass["le_va"]; ?></td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								</tr>
								<tr>
								
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center">Near</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="2">Add</td>
								<td style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="5">
								<?php echo $fetchglass["re_add"]; ?>
								</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="1">
								<?php echo $fetchglass["re_nva"]; ?>
								</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="2">Add</td>
								<td style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="4">
								<?php echo $fetchglass["le_add"]; ?>
								</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="2">
								<?php echo $fetchglass["le_nva"]; ?>
								</td>
								<td colspan="2">&nbsp;</td>
								<td colspan="2">&nbsp;</td>
								<td colspan="2">&nbsp;</td>
								<td colspan="2">&nbsp;</td>
								<td colspan="2">&nbsp;</td>
								<td colspan="5">&nbsp;</td>
								</tr>
								<tr>
								
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="2">
								<?php echo $fetchglass["colour"]; ?>
								</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="5">
								<?php echo $fetchglass["focal"]; ?>
								</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center"><?php echo $fetchglass["ipd"]; ?></td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" class="text-center" colspan="9"><?php echo $fetchglass["vd"]; ?></td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								</tr>
								<tr>
								
								<td colspan="4">&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td colspan="3" width="192">&nbsp;</td>
								<td width="64"></td>
								<td colspan="2" width="128">&nbsp;</td>
								</tr>
				
				<tr>
				
				<td colspan="4">&nbsp;</td>
				<td colspan="4">&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td width="64">&nbsp;</td>
				<td width="64">&nbsp;</td>
				<td width="64">&nbsp;</td>
				<td width="64">&nbsp;</td>
				<td>&nbsp;</td>
				</tr>
				<tr>
				
				<td colspan="4">&nbsp;</td>
				<td colspan="4">&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td width="64">&nbsp;</td>
				<td colspan="3" width="192">&nbsp;</td>
				<td>&nbsp;</td>
				</tr>
				<tr>
				
				<td colspan="4">&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td width="64">&nbsp;</td>
				<td colspan="3" width="192">&nbsp;</td>
				<td>&nbsp;</td>
				</tr>
				<tr>
				<td>Review after -</td>
				<td><?php echo $rowpres["review_after"];?></td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td colspan="5">&nbsp;</td>
				<td>&nbsp;</td>
				<td width="64">&nbsp;</td>
				<td colspan="3" width="192">&nbsp;</td>
				<td>&nbsp;</td>
				</tr>
				<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td colspan="3" width="192">&nbsp;</td>
				<td>&nbsp;</td>
				</tr>
				</tbody>
				</table>
		
		<table border="2px" width="979">
		<tbody>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3" width="181">EXAMINATION</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="12" width="768"><?php echo $rowpres["uppersec"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">ANT. SEGMENT</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;">OD</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;">OS</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">&nbsp;</td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3" rowspan="2">Visual Acuity</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Unaided</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Old Spectacles</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">PH/ SS</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Unaided</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Old Spectacles</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">PH/ SS</td>
		</tr>
		<tr>
		<?php $od_unaided=$rowpres["od_unaided"];
		$od_unaided_exp=explode(" ",$od_unaided);
		
		$od_old=$rowpres["od_old_spectacles"];
		$od_old_exp=explode(" ",$od_old);
		
		$od_phss=$rowpres["od_ph_ss"];
		$od_phss_exp=explode(" ",$od_phss);
		
		
		$os_unaided=$rowpres["os_unaided"];
		$os_unaided_exp=explode(" ",$os_unaided);
		
		$os_old=$rowpres["os_old_spectacles"];
		$os_old_exp=explode(" ",$os_old);
		
		$os_phss=$rowpres["os_ph_ss"];
		$os_phss_exp=explode(" ",$os_phss);
		?>
		<td  style="border:solid thin; border-width:2px; border-style:double;"><?php echo !empty($od_unaided_exp[0])?$od_unaided_exp[0]:""; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;"><?php echo !empty($od_unaided_exp[1])?$od_unaided_exp[1]:""; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;"><?php echo !empty($od_old_exp[0])?$od_old_exp[0]:""; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;"><?php echo !empty($od_old_exp[1])?$od_old_exp[1]:""; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;"><?php echo !empty($od_phss_exp[0])?$od_phss_exp[0]:""; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;"><?php echo !empty($od_phss_exp[1])?$od_phss_exp[1]:""; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;"><?php echo !empty($os_unaided_exp[0])?$os_unaided_exp[0]:""; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;"><?php echo !empty($os_unaided_exp[1])?$os_unaided_exp[1]:""; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;"><?php echo !empty($os_old_exp[0])?$os_old_exp[0]:""; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;"><?php echo !empty($os_old_exp[1])?$os_old_exp[1]:""; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;"><?php echo !empty($os_phss_exp[0])?$os_phss_exp[0]:""; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;"><?php echo !empty($os_phss_exp[1])?$os_phss_exp[1]:""; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">Projection of ray</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_pr"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_pr"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">ARK</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;">Sph.</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;">Cyl.</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;">Axis</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;">VA</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Comment</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;">Sph.</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;">Cyl.</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;">Axis</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;">VA</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Comment</td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" rowspan="2">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;">IPD</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;">Dist.</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;"><?php echo $rowpres["od_sph"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;"><?php echo $rowpres["od_cyl"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;"><?php echo $rowpres["od_axis"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;"><?php echo $rowpres["od_va"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2" rowspan="2"><?php echo $rowpres["od_comment"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;"><?php echo $rowpres["os_sph"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;"><?php echo $rowpres["os_cyl"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;"><?php echo $rowpres["os_axis"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;"><?php echo $rowpres["os_va"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2" rowspan="2"><?php echo $rowpres["os_comment"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;"><?php echo $rowpres["ipd"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;">Near</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;">Add</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2"><?php echo $rowpres["od_add"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;"><?php echo $rowpres["od_nva"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;">Add</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2"><?php echo $rowpres["os_add"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;"><?php echo $rowpres["os_nva"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">Head posture</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="12"><?php echo $rowpres["head_posture"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">Forehead</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_forehead"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_forehead"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">Orbit</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_orbit"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_orbit"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">Eye brows</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_eye_brows"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_eye_brows"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">Eye lids</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_eye_lids"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_eye_lids"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Position</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_position_eyelids"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_position_eyelids"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Skin</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_skin_eyelids"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_skin_eyelids"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Margins</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_margins_eyelids"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_margins_eyelids"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">Lacrimal app.</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_lacrimal_app"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_lacrimal_app"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">Eye ball</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_eye_ball"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_eye_ball"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Moments</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_moments_eyeball"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_moments_eyeball"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">Conjunctiva</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_conjunctiva"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_conjunctiva"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" rowspan="2">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Palpebral</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_pulpebral_conjunctiva"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_pulpebral_conjunctiva"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Bulbar</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_bulbar_conjunctiva"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_bulbar_conjunctiva"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">Sclera</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">Cornea</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" rowspan="5">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Size</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_size_cornea"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_size_cornea"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Surface</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_surface_cornea"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_surface_cornea"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Tansparancy</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_transparency_cornea"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_transparency_cornea"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Stroma</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_stroma_cornea"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_stroma_cornea"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Endothelium</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_endothelium_cornea"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_endothelium_cornea"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">AC</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" rowspan="2">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Contant</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_ac_contant"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_ac_contant"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Depth</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_ac_depth"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_ac_depth"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">Iris</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" rowspan="2">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Colour</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_iris_colour"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_iris_colour"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Pattern</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_iris_pattern"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_iris_pattern"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">Pulpil</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" rowspan="3">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Size</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_pupil_size"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_pupil_size"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Shape</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_pupil_shape"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_pupil_shape"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Reaction</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_pupil_reaction"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_pupil_reaction"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">Lens</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Opacity</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_lens_opacity"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_lens_opacity"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">IOP</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_iop"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_iop"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Fundus</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;">Direct</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">Media</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_media"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_media"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">Optic Disc</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_optic_disc"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_optic_disc"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Size</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_optic_disc_size"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_optic_disc_size"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Shape</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_optic_disc_shape"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_optic_disc_shape"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Colour</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_optic_disc_colour"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_optic_disc_colour"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Margine</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_optic_disc_margine"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_optic_disc_margine"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">C:D ratio</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_cd_ratio"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_cd_ratio"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">Blood vessels</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">Disc</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_bv_over_disc"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_bv_over_disc"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">GF</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_bv_over_gf"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_bv_over_gf"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">Macula</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo nl2br($rowpres["od_macula"]); ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo nl2br($rowpres["os_macula"]); ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">General fundus</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo nl2br($rowpres["od_gf"]); ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo nl2br($rowpres["os_gf"]); ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">Special tests</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">Syringing</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_syringing"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_syringing"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">Shirmers test</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_shirmers_test"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_shirmers_test"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">Gonioscopy</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_gonioscopy"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_gonioscopy"]; ?></td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6">&nbsp;</td>
		</tr>
		<tr>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">Photograph No.</td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["od_photograph_num"]; ?></td>
		<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="6"><?php echo $rowpres["os_photograph_num"]; ?></td>
		</tr>
		</tbody>
		</table>
		<br>
		
		<?php
		if($rowpres["pres_date"]==date("Y-m-d"))
		{
		?>
		<form action="" method="post">
		   <div class="form-group">
		   <label>Notes:</label><br>
		   
		   <input type="hidden" name="presid" value="<?php echo $rowpres["id"];?>">
		   <textarea name="other_note" id="other_note" rows="6" cols="80" required="required"><?php echo $rowpres["other_note"]; ?></textarea>
		   </div>
		   <input type="submit" id="save_note" name="save_note" value="Save" class="btn btn-primary">
		</form>
		
				<?php
		}
		else{
			?>
			<label><?php echo !empty($rowpres["other_note"])?"Notes":"";?></label>
			<p><?php echo nl2br($rowpres["other_note"]); ?></p>
			<?php
		}
				}
				?>
			</div>
			</div> 
		</div>
		<?php 
		if(isset($_REQUEST["save_note"]))
		{
			@$presid=$_POST["presid"];
			@$note=$_POST["other_note"];
			@$ref=$_SERVER["HTTP_REFERER"];
			$updsql=mysqli_query($db,"update prescriptions set other_note='$note' where id='$presid'");
			if($updsql)
			{
				echo "<script> alert('Saved!') </script>";
				echo "<script> window.location.href='$ref' </script>";
			}
		}
		?>
		
		
	<div id = "footer" style="margin-top:200px !important;">
		<label class = "footer-title">&copy; Copyright EyeCare 2022</label>
	</div>
	<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.12.1.min.js"></script>
<script type="text/javascript" src="js/popper.min.js"></script>
<script type="text/javascript" src="js/bootstrap-v4.3.1.min.js"></script>
<script type="text/javascript" src="js/jquery.form.js"></script>
<script type="text/javascript" src="js/jquery.timeago.js"></script>
<script type="text/javascript" src="js/jstz.min.js"></script>
<script type="text/javascript" src="js/script.js?v=80.0"></script>
<script type="text/javascript" src="js/jquery.autosize.min.js"></script>
<script type="text/javascript" src="js/jquery.noty.packaged.min.js"></script>
<script type="text/javascript" src="js/star-rating.min.js"></script>
<script type="text/javascript" src="js/jquery.timeago.js"></script>
<script type="text/javascript" src="js/chat.js?v=80.0"></script>
<script type="text/javascript" src="js/select2.js?v=80.0"></script>
<script type="text/javascript" src="js/login_old.js?v=80.0"></script>

	
	<script>
		document.getElementById("doPrint").addEventListener("click", function() {
			document.querySelector('#save_note').style.visibility = 'hidden';
			document.querySelector('#other_note').style.border = 'none';
     var printContents = document.getElementById('chartContainer').innerHTML;
     var originalContents = document.body.innerHTML;
     document.body.innerHTML = printContents;
     window.print();
     document.body.innerHTML = originalContents;
});
	</script>
</body>
</html>