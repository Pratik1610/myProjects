<?php
	if(ISSET($_POST['save_patient'])){
		$title = $_POST['title'];
		$firstname = $_POST['firstname'];
		$middlename = $_POST['middlename'];
		$lastname = $_POST['lastname'];
		$birthdate = $_POST['birthdate'];
		$bday=date("Y-m-d",strtotime($birthdate));
		$from= new DateTime($bday);
		$to= new DateTime('today');
		$age=$from->diff($to)->y;
		$gender = $_POST['gender'];
		$house = $_POST['house'];
		$street = $_POST['street'];
		$locality = $_POST['locality'];
		$city = $_POST['city'];
		$state = $_POST['state'];
		$pin = $_POST['pin'];
		$contact = $_POST['contact'];
		$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
			$conn->query("INSERT INTO `itr` VALUES('','$title','$firstname', '$middlename', '$lastname', '$birthdate', '$age', '$gender', '$house', '$street', '$locality', '$city', '$state', '$pin','$contact')") or die(mysqli_error());
			header("location: patient.php");	
	}
	