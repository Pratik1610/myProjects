<?php
include "authentication.php";
date_default_timezone_set("Asia/Kolkata");
$cur= date("Y-m-d");
// Delete data from temporary tables
	$del1=mysqli_query($db,"delete from advice_temp");
	$del2=mysqli_query($db,"delete from co_temp");
	$del3=mysqli_query($db,"delete from diagnosis_temp");
	$del4=mysqli_query($db,"delete from examination_temp");
	$del5=mysqli_query($db,"delete from followup_temp");
	$del6=mysqli_query($db,"delete from glasses_temp");
	$del7=mysqli_query($db,"delete from review_temp");
	$del8=mysqli_query($db,"delete from rx_temp");
	 echo "<script> alert('Presscription Canceled Successfully!') </script>";
	 echo "<script> window.location.href='home.php' </script>";
?>