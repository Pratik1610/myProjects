<!DOCTYPE html>
<?php
    ob_start();
	require_once 'logincheck.php';
	require_once 'authentication.php';
	
?>
<html lang = "eng">
	<head>
		<title>EyeCare</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "shortcut icon" href = "images/eye-gb51ecb13e_1280.PNG" />
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/customize.css" />
	</head>
<body>
	<div class = "navbar navbar-default navbar-fixed-top">
		<img src = "images/eye-gb51ecb13e_1280.PNG" style = "float:left;" height = "55px" /><label class = "navbar-brand">EyeCare</label>
			<?php
				$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
				$q = $conn->query("SELECT * FROM `user` WHERE `user_id` = '$_SESSION[user_id]'") or die(mysqli_error());
				$f = $q->fetch_array();
			?>
			<ul class = "nav navbar-nav navbar-right">	
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#" style="color:white;">
						<span class = "glyphicon glyphicon-user"></span>
						<?php
							echo $f['firstname']." ".$f["middlename"]." ".$f['lastname'];
							$conn->close();
						?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
					<li>
						<a class = "me" href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
	</div>
		<br />
		<br />
		<br />
		<div class = "panel panel-success">	
		<?php
			$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
			$query = $conn->query("SELECT * FROM `appointments` WHERE `id` = '$_GET[apid]'") or die(mysqli_error());
			$fetch = $query->fetch_array();
			$pid=$fetch["pid"]; // patient id
			$selp=mysqli_query($db,"select * from itr where patient_id='$pid'");
			$rowp=mysqli_fetch_array($selp);
			
			$selglass = mysqli_query($db,"SELECT * FROM `glasses_temp` where pid='$pid' and apid='".$_GET['apid']."'") or die(mysqli_error());
			$fetchglass=mysqli_fetch_array($selglass);
		?>
			<div class = "panel-heading">
				<label>ADD Prescription>> Glasses</label>
			</div>
			<div class = "panel-body">
					<div class = "panel panel-default">
					<div class = "panel-heading">
					  <label>Patient Details</label>
					  <p><strong>Patient Name: </strong><?php echo ucwords($fetch["patient_name"]);?> &nbsp; &nbsp; 
				   <strong>Gender: </strong><?php echo ucwords($rowp["gender"]);?> &nbsp; &nbsp; 
				</p>
				<p><strong>Address: </strong><?php 
				if(!empty($rowp["house"]))
				{
					echo $rowp["house"]." ";
					$address=$rowp["house"]." ";
				}
				if(!empty($rowp["street"]))
				{
					echo $rowp["street"]." ";
					$address.=$rowp["street"]." ";
				}
				if(!empty($rowp["locality"]))
				{
					echo $rowp["locality"]." ";
					$address.=$rowp["locality"]." ";
				}
				if(!empty($rowp["city"]))
				{
					echo ",".$rowp["city"]." ";
					$address.=$rowp["city"]." ";
				}
				if(!empty($rowp["state"]))
				{
					echo $rowp["state"]." ";
					$address.=$rowp["state"]." ";
				}
				if(!empty($rowp["pin"]))
				{
					echo $rowp["pin"]." ";
					$address.=$rowp["pin"]." ";
				}
				?> &nbsp; &nbsp; 
				<strong>Age: </strong><?php echo ucwords($rowp["age"]);?><span> Years</span>
				</p>
					</div>
					</div>
					<form id = "form_admin" method = "POST" enctype = "multi-part/form-data" >
					<input type="hidden" name="apid" value="<?php echo $_GET["apid"];?>">
							<input type="hidden" name="pid" value="<?php echo $pid;?>">
					    <ul class="nav nav-tabs">
							<li><a href="prescription_add.php?apid=<?php echo $_GET['apid'];?>">C/o</a></li>
							<li><a href="diagnosis_temp.php?apid=<?php echo $_GET['apid'];?>">Diagnosis</a></li>
							<li><a href="rx_temp.php?apid=<?php echo $_GET['apid'];?>">Rx</a></li>
							<li  class="active"><a href="glasses_temp.php?apid=<?php echo $_GET['apid'];?>">Glasses</a></li>
							<li><a href="advice_temp.php?apid=<?php echo $_GET['apid'];?>">Advice</a></li>
							<li><a href="review_temp.php?apid=<?php echo $_GET['apid'];?>">Review</a></li>
							<li><a href="examination_temp.php?apid=<?php echo $_GET['apid'];?>">Examination</a></li>
							<li><a href="followup_temp.php?apid=<?php echo $_GET['apid'];?>">Followup Notes</a></li>
						</ul>
						<br>
						<br>
						<table width="1200">
						<tbody>
						<tr>
								<td colspan="2">GLASSES-</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								</tr>
								<tr>
								<td >&nbsp;</td>
								<td  style="border:solid thin; border-width:2px; border-style:double; text-align:center;"  rowspan="2">&nbsp;</td>
								<td  style="border:solid thin; border-width:2px; border-style:double; text-align:center;" colspan="8">RE</td>
								<td  style="border:solid thin; border-width:2px; border-style:double; text-align:center;" colspan="9">LE</td>
								<td  >&nbsp;</td>
								<td  >&nbsp;</td>
								<td  >&nbsp;</td>
								<td  >&nbsp;</td>
								<td  >&nbsp;</td>
								<td>&nbsp;</td>
								</tr>
								<tr>
								<td  >&nbsp;</td>
								<td  style="border:solid thin; border-width:2px; border-style:double; text-align:center;" colspan="2">Sph.</td>
								<td  style="border:solid thin; border-width:2px; border-style:double; text-align:center;" colspan="2">Cyl.</td>
								<td  style="border:solid thin; border-width:2px; border-style:double; text-align:center;" colspan="3">Axis</td>
								<td  style="border:solid thin; border-width:2px; border-style:double; text-align:center;" colspan="1">VA</td>
								<td  style="border:solid thin; border-width:2px; border-style:double; text-align:center;" colspan="2">Sph.</td>
								<td  style="border:solid thin; border-width:2px; border-style:double; text-align:center;" colspan="3">Cyl.</td>
								<td  style="border:solid thin; border-width:2px; border-style:double; text-align:center;" colspan="3">Axis</td>
								<td  style="border:solid thin; border-width:2px; border-style:double; text-align:center;" colspan="1">VA</td>
								<td  >&nbsp;</td>
								<td  >&nbsp;</td>
								<td  >&nbsp;</td>
								<td  >&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								</tr>
								<tr>
								<td>&nbsp;</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;">Dist.</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">
								<select name="re_sph" id="re_sph" class="form-control" required>
								                            <?php 
															   if(!empty($fetchglass["re_sph"]))
															   {
															?>
															<option><?php echo $fetchglass["re_sph"]; ?></option>
															<?php
															   }
															   else
															   {
															?>
															<option value="">----Sph----</option>
															
															<?php
															   }
															 $selsph=mysqli_query($db,"select distinct glass from prescription_analysis where glass!=''");
															 while($rowsph=mysqli_fetch_array($selsph))
															 {
															?>
															<option><?php echo $rowsph["glass"];?></option>
															<?php
															 }
															 ?>
															 </select>

								</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">
								<select name="re_cyl" class="form-control"  required>
															<?php 
															   if(!empty($fetchglass["re_cyl"]))
															   {
															?>
															<option><?php echo $fetchglass["re_cyl"]; ?></option>
															<?php
															   }
															   else
															   {
															?>
															<option value="">----Cyl----</option>
															<?php
															   }
															 $selcyl=mysqli_query($db,"select distinct glass from prescription_analysis where glass!=''");
															 while($rowcyl=mysqli_fetch_array($selcyl))
															 {
															?>
															<option><?php echo $rowcyl["glass"];?></option>
															<?php
															 }
															 ?>
															 </select>
								</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">
								<select name="re_axis" class="form-control"  required>
															<?php 
															   if(!empty($fetchglass["re_axis"]))
															   {
															?>
															<option><?php echo $fetchglass["re_axis"]; ?></option>
															<?php
															   }
															   else
															   {
															?>
															<option value="">---Axis---</option>
															<?php
															   }
															 $selaxis=mysqli_query($db,"select distinct axis from prescription_analysis where axis!=''");
															 while($rowaxis=mysqli_fetch_array($selaxis))
															 {
															?>
															<option><?php echo $rowaxis["axis"];?></option>
															<?php
															 }
															 ?>
															 </select>

								</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="1">
								<select name="re_va" class="form-control"  required>
															<?php 
															   if(!empty($fetchglass["re_va"]))
															   {
															?>
															<option><?php echo $fetchglass["re_va"]; ?></option>
															<?php
															   }
															   else
															   {
															?>
															<option value="">----Va----</option>
															<?php
															   }
															 $selva=mysqli_query($db,"select distinct va from prescription_analysis where va!=''");
															 while($rowva=mysqli_fetch_array($selva))
															 {
															?>
															<option><?php echo $rowva["va"];?></option>
															<?php
															 }
															 ?>
															 </select></td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">
								<select name="le_sph" class="form-control"  required>
								                             <?php 
															   if(!empty($fetchglass["le_sph"]))
															   {
															?>
															<option><?php echo $fetchglass["le_sph"]; ?></option>
															<?php
															   }
															   else
															   {
															?>
															<option value="">----Sph----</option>
															<?php
															   }
															 $selsph=mysqli_query($db,"select distinct glass from prescription_analysis where glass!=''");
															 while($rowsph=mysqli_fetch_array($selsph))
															 {
															?>
															<option><?php echo $rowsph["glass"];?></option>
															<?php
															 }
															 ?>
															 </select>

								</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">
								<select name="le_cyl" class="form-control"  required>
															<?php 
															   if(!empty($fetchglass["le_cyl"]))
															   {
															?>
															<option><?php echo $fetchglass["le_cyl"]; ?></option>
															<?php
															   }
															   else
															   {
															?>
															<option value="">--Cyl--</option>
															<?php
															   }
															 $selcyl=mysqli_query($db,"select distinct glass from prescription_analysis where glass!=''");
															 while($rowcyl=mysqli_fetch_array($selcyl))
															 {
															?>
															<option><?php echo $rowcyl["glass"];?></option>
															<?php
															 }
															 ?>
															 </select>
								</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">
								<select name="le_axis" class="form-control"  required>
															<?php 
															   if(!empty($fetchglass["le_axis"]))
															   {
															?>
															<option><?php echo $fetchglass["le_axis"]; ?></option>
															<?php
															   }
															   else
															   {
															?>
															<option value="">--Axis----</option>
															<?php
															   }
															 $selaxis=mysqli_query($db,"select distinct axis from prescription_analysis where axis!=''");
															 while($rowaxis=mysqli_fetch_array($selaxis))
															 {
															?>
															<option><?php echo $rowaxis["axis"];?></option>
															<?php
															 }
															 ?>
															 </select>

								</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="1"><select name="le_va" class="form-control"  required>
															<?php 
															   if(!empty($fetchglass["le_va"]))
															   {
															?>
															<option><?php echo $fetchglass["le_va"]; ?></option>
															<?php
															   }
															   else
															   {
															?>
															<option value="">----Va----</option>
															<?php
															   }
															 $selva=mysqli_query($db,"select distinct va from prescription_analysis where va!=''");
															 while($rowva=mysqli_fetch_array($selva))
															 {
															?>
															<option><?php echo $rowva["va"];?></option>
															<?php
															 }
															 ?>
															 </select></td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								</tr>
								<tr>
								<td>&nbsp;</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;">Near</td>
								<td  style="border:solid thin; border-width:2px; border-style:double; text-align:center;" colspan="2">Add</td>
								<td style="border:solid thin; border-width:2px; border-style:double;" colspan="5">
								<select name="re_add" class="form-control"  required>
															<?php 
															   if(!empty($fetchglass["re_add"]))
															   {
															?>
															<option><?php echo $fetchglass["re_add"]; ?></option>
															<?php
															   }
															   else
															   {
															?>
															<option value="">----Add----</option>
															<?php
															   }
															 $seladd=mysqli_query($db,"select distinct ad from prescription_analysis where ad!=''");
															 while($rowadd=mysqli_fetch_array($seladd))
															 {
															?>
															<option><?php echo $rowadd["ad"];?></option>
															<?php
															 }
															 ?>
															 </select>
								</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="1">
								<select name="re_nva" class="form-control"  required>
															<?php 
															   if(!empty($fetchglass["re_nva"]))
															   {
															?>
															<option><?php echo $fetchglass["re_nva"]; ?></option>
															<?php
															   }
															   else
															   {
															?>
															<option value="">----Nva----</option>
															<?php
															   }
															 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis where nva!=''");
															 while($rownva=mysqli_fetch_array($selnva))
															 {
															?>
															<option><?php echo $rownva["nva"];?></option>
															<?php
															 }
															 ?>
															 </select>
								</td>
								<td  style="border:solid thin; border-width:2px; border-style:double; text-align:center;" colspan="2">Add</td>
								<td style="border:solid thin; border-width:2px; border-style:double;" colspan="4">
								<select name="le_add" class="form-control"  required>
															<?php 
															   if(!empty($fetchglass["le_add"]))
															   {
															?>
															<option><?php echo $fetchglass["le_add"]; ?></option>
															<?php
															   }
															   else
															   {
															?>
															<option value="">----Add----</option>
															<?php
															   }
															 $seladd=mysqli_query($db,"select distinct ad from prescription_analysis where ad!=''");
															 while($rowadd=mysqli_fetch_array($seladd))
															 {
															?>
															<option><?php echo $rowadd["ad"];?></option>
															<?php
															 }
															 ?>
															 </select>
								</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="3">
								<select name="le_nva" class="form-control"  required>
															<?php 
															   if(!empty($fetchglass["le_nva"]))
															   {
															?>
															<option><?php echo $fetchglass["le_nva"]; ?></option>
															<?php
															   }
															   else
															   {
															?>
															<option value="">----Nva----</option>
															<?php
															   }
															 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis where nva!=''");
															 while($rownva=mysqli_fetch_array($selnva))
															 {
															?>
															<option><?php echo $rownva["nva"];?></option>
															<?php
															 }
															 ?>
															 </select>
								</td>
								<td colspan="2">&nbsp;</td>
								<td colspan="2">&nbsp;</td>
								<td colspan="2">&nbsp;</td>
								<td colspan="2">&nbsp;</td>
								<td colspan="2">&nbsp;</td>
								<td colspan="5">&nbsp;</td>
								</tr>
								<tr>
								<td>&nbsp;</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">
								<select name="colour" class="form-control"  required>
															<?php 
															   if(!empty($fetchglass["colour"]))
															   {
															?>
															<option><?php echo $fetchglass["colour"]; ?></option>
															<?php
															   }
															   else
															   {
															?>
															<option value="">----Colour----</option>
															<?php
															   }
															 $selcolour=mysqli_query($db,"select distinct colour from prescription_analysis where colour!=''");
															 while($rowcolour=mysqli_fetch_array($selcolour))
															 {
															?>
															<option><?php echo $rowcolour["colour"];?></option>
															<?php
															 }
															 ?>
															 </select>
								</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="5">
								<select name="focal" class="form-control"  required>
															<?php 
															   if(!empty($fetchglass["focal"]))
															   {
															?>
															<option><?php echo $fetchglass["focal"]; ?></option>
															<?php
															   }
															   else
															   {
															?>
															<option value="">----Focal----</option>
															<?php
															   }
															 $selfocal=mysqli_query($db,"select distinct focal from prescription_analysis where focal!=''");
															 while($rowfocal=mysqli_fetch_array($selfocal))
															 {
															?>
															<option><?php echo $rowfocal["focal"];?></option>
															<?php
															 }
															 ?>
															 </select>
								
								</td>
								<td  style="border:solid thin; border-width:2px; border-style:double;"><select name="ipd" class="form-control"  required>
															<?php 
															   if(!empty($fetchglass["ipd"]))
															   {
															?>
															<option><?php echo $fetchglass["ipd"]; ?></option>
															<?php
															   }
															   else
															   {
															?>
															<option value="">----IPD----</option>
															<?php
															   }
															 $selipd=mysqli_query($db,"select distinct pd from prescription_analysis where pd!=''");
															 while($rowipd=mysqli_fetch_array($selipd))
															 {
															?>
															<option><?php echo $rowipd["pd"];?></option>
															<?php
															 }
															 ?>
															 </select></td>
								<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="10"><input type="text" name="vd" class="form-control" value="<?php echo !empty($fetchglass["vd"])?$fetchglass["vd"]:""; ?>" placeholder="VD" required></td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								</tr>
								<tr>
								<td>&nbsp;</td>
								<td colspan="4">&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td colspan="3" width="192">&nbsp;</td>
								<td width="64"></td>
								<td colspan="2" width="128">&nbsp;</td>
								</tr>
						</tbody>
						</table>
						<br>
						<br>
						<?php 
						   if(mysqli_num_rows($selglass)==0)
						   {
						?>
						<input type="submit" name="submit" id="submit" class="btn btn-primary" value="Add">
						<?php 
						   }
						   else
						   {
						   ?>
						   <button  class = "btn btn-warning" name = "edit" id="edit" ><span class = "glyphicon glyphicon-edit"></span> SAVE</button>
						   <?php
						   }
						   ?>
					</form>
					<?php
					  if(isset($_POST["submit"]))
					  {
						  $re_sph=mysqli_real_escape_string($db,$_POST['re_sph']);
						  $re_cyl=mysqli_real_escape_string($db,$_POST['re_cyl']);
						  $re_axis=mysqli_real_escape_string($db,$_POST['re_axis']);
						  $re_va=mysqli_real_escape_string($db,$_POST['re_va']);
						  $le_sph=mysqli_real_escape_string($db,$_POST['le_sph']);
						  $le_cyl=mysqli_real_escape_string($db,$_POST['le_cyl']);
						  $le_axis=mysqli_real_escape_string($db,$_POST['le_axis']);
						  $le_va=mysqli_real_escape_string($db,$_POST['le_va']);
						  $re_add=mysqli_real_escape_string($db,$_POST['re_add']);
						  $re_nva=mysqli_real_escape_string($db,$_POST['re_nva']);
						  $le_add=mysqli_real_escape_string($db,$_POST['le_add']);
						  $le_nva=mysqli_real_escape_string($db,$_POST['le_nva']);
						  $ipd=mysqli_real_escape_string($db,$_POST['ipd']);
						  $colour=mysqli_real_escape_string($db,$_POST['colour']);
						  $focal=mysqli_real_escape_string($db,$_POST['focal']);
						  $vd=mysqli_real_escape_string($db,$_POST['vd']);
						  $apid=mysqli_real_escape_string($db,$_POST['apid']); // appointments id
						  $pid=mysqli_real_escape_string($db,$_POST['pid']); // patient id
						  $insdate=date("Y-m-d");
					  $inssql=mysqli_query($db,"insert into glasses_temp values('','$pid','$apid','$re_sph','$re_cyl','$re_axis','$re_va','$le_sph','$le_cyl','$le_axis','$le_va','$re_add','$re_nva','$le_add','$le_nva','$colour','$focal','$vd','$ipd','$insdate')");
					  if($inssql)
					  {
						  echo "<script> window.location.href='glasses_temp.php?apid=$apid' </script>";
					  }
					  }
					  elseif(isset($_POST["edit"]))
					  {
						  $re_sph=mysqli_real_escape_string($db,$_POST['re_sph']);
						  $re_cyl=mysqli_real_escape_string($db,$_POST['re_cyl']);
						  $re_axis=mysqli_real_escape_string($db,$_POST['re_axis']);
						  $re_va=mysqli_real_escape_string($db,$_POST['re_va']);
						  $le_sph=mysqli_real_escape_string($db,$_POST['le_sph']);
						  $le_cyl=mysqli_real_escape_string($db,$_POST['le_cyl']);
						  $le_axis=mysqli_real_escape_string($db,$_POST['le_axis']);
						  $le_va=mysqli_real_escape_string($db,$_POST['le_va']);
						  $re_add=mysqli_real_escape_string($db,$_POST['re_add']);
						  $re_nva=mysqli_real_escape_string($db,$_POST['re_nva']);
						  $le_add=mysqli_real_escape_string($db,$_POST['le_add']);
						  $le_nva=mysqli_real_escape_string($db,$_POST['le_nva']);
						  $colour=mysqli_real_escape_string($db,$_POST['colour']);
						  $focal=mysqli_real_escape_string($db,$_POST['focal']);
						  $vd=mysqli_real_escape_string($db,$_POST['vd']);
						  $ipd=mysqli_real_escape_string($db,$_POST['ipd']);
						  $apid=mysqli_real_escape_string($db,$_POST['apid']); // appointments id
						  $pid=mysqli_real_escape_string($db,$_POST['pid']); // patient id
						  $insdate=date("Y-m-d");
						  $updsql=mysqli_query($db,"UPDATE `glasses_temp` SET `re_sph`='$re_sph',`re_cyl`='$re_cyl',`re_axis`='$re_axis',`re_va`='$re_va',`le_sph`='$le_sph',`le_cyl`='$le_cyl',`le_axis`='$le_axis',`le_va`='$le_va',`re_add`='$re_add',`re_nva`='$re_nva',`le_add`='$le_add',`le_nva`='$re_nva',`colour`='$colour', `focal`='$focal', `vd`='$vd',`ipd`='$ipd',`ins_date`='$insdate' WHERE pid='$pid' and apid='".$_GET["apid"]."'");
						  if($updsql)
						  {
							  echo "<script> alert('Saved Successfully!') </script>";
							  echo "<script> window.location.href='glasses_temp.php?apid=$apid' </script>";
						  }
					  }
					?>
			</div>
		</div>	
	<div id = "footer">
		<label class = "footer-title">&copy; Copyright EyeCare 2022</label>
	</div>
<?php require'script.php' ?>
<script type = "text/javascript">
    $(document).ready(function() {
		$("#submit").attr("disabled",true);
        function disableBack() { window.history.forward() }

        window.onload = disableBack();
        window.onpageshow = function(evt) { if (evt.persisted) disableBack() }
	});
</script>
<script type = "text/javascript">
$("#re_sph").change(function(){
	$("#submit").attr("disabled",false);
})
</script>
</body>
</html>