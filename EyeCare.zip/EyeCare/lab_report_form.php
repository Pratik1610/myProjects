<!DOCTYPE html>
<?php
    ob_start();
	require_once 'logincheck.php';
	require_once 'authentication.php';
	$refs=$_SERVER["HTTP_REFERER"];
?>
<html lang = "eng">
	<head>
		<title>EyeCare</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "shortcut icon" href = "images/eye-gb51ecb13e_1280.PNG" />
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/customize.css" />
	</head>
<body>
	<div class = "navbar navbar-default navbar-fixed-top">
		<img src = "images/eye-gb51ecb13e_1280.PNG" style = "float:left;" height = "55px" /><label class = "navbar-brand">EyeCare</label>
			<?php
				$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
				$q = $conn->query("SELECT * FROM `user` WHERE `user_id` = '$_SESSION[user_id]'") or die(mysqli_error());
				$f = $q->fetch_array();
			?>
			<ul class = "nav navbar-nav navbar-right">	
			    <li><a href="home.php" style="color:#fff; font-size:16px;"><span class = "glyphicon glyphicon-hand-left"></span> Back to the dashboard</a></li>
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#" style="color:white;">
						<span class = "glyphicon glyphicon-user"></span>
						<?php
							echo $f['firstname']." ".$f["middlename"]." ".$f['lastname'];
							$conn->close();
						?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
					<li>
						<a class = "me" href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
	</div>
		<br />
		<br />
		<br />
		<div class = "panel panel-success">	
		<?php
			$selapsql=mysqli_query($db,"select * from appointments where pid='".$_GET["pid"]."' limit 1");
			$fetchap=mysqli_fetch_array($selapsql);
		?>
			<div class = "panel-heading">
				<label>&nbsp;Lab Report</label>
			</div>
			<div class = "panel-body">
				<form id = "form_admin" method = "POST" enctype = "multi-part/form-data" >
					<div class = "panel panel-default" style = "width:60%; margin:auto;">
					<div class = "panel-heading">
					</div>
					<div class = "panel-body">
						<div class = "form-group">
							<label for = "username">Patient ID: </label>
							<input class = "form-control" name = "pid" type = "text" value="<?php echo $fetchap["pid"];?>" readonly>
						</div>
						<div class = "form-group">
							<label for = "username">Patient Name: </label>
							<input class = "form-control" name = "pname" type = "text" value="<?php echo $fetchap["patient_name"];?>" readonly>
						</div>
						<div class = "form-group">
							<label for = "middlename">Report Date: </label>
							<input class = "form-control" type = "date" name = "report_date" value = "<?php echo date("Y-m-d"); ?>" required = "required">
						</div>
						<div class = "form-group">
							<label for = "lastname">HB: </label>
							<input class = "form-control" type = "text" name = "hb" >
						</div>
						
					    <div class = "form-group">
							<label for = "username">N: </label>
							<input class = "form-control" name = "n" type = "text">
						</div>
						
						<div class = "form-group">
							<label for = "username">M: </label>
							<input class = "form-control" name = "m" type = "text">
						</div>
						
						<div class = "form-group">
							<label for = "username">Sug F: </label>
							<input class = "form-control" name = "sugf" type = "text">
						</div>
						
						<div class = "form-group">
							<label for = "username">ESR: </label>
							<input class = "form-control" name = "esr" type = "text">
						</div>
						
						<div class = "form-group">
							<label for = "username">Culture: </label>
							<input class = "form-control" name = "culture" type = "text">
						</div>
						
						<div class = "form-group">
							<label for = "username">X-Ray: </label>
							<input class = "form-control" name = "xray" type = "text">
						</div>
						
						<div class = "form-group">
							<label for = "username">USG: </label>
							<input class = "form-control" name = "usg" type = "text">
						</div>
						
						<div class = "form-group">
							<label for = "username">Others: </label>
							<input class = "form-control" name = "others" type = "text">
						</div>
						
						<div class = "form-group">
							<label for = "username">TLC: </label>
							<input class = "form-control" name = "tlc" type = "text">
						</div>
						
						<div class = "form-group">
							<label for = "username">E: </label>
							<input class = "form-control" name = "e" type = "text">
						</div>
						<div class = "form-group">
							<label for = "username">B: </label>
							<input class = "form-control" name = "b" type = "text">
						</div>
						
						<div class = "form-group">
							<label for = "username">PP: </label>
							<input class = "form-control" name = "pp" type = "text">
						</div>
						<div class = "form-group">
							<label for = "username">RA: </label>
							<input class = "form-control" name = "ra" type = "text">
						</div>
							<button  class = "btn btn-warning" name = "submit" ><span class = "glyphicon glyphicon-edit"></span> SAVE</button>
							<br />
					</div>
										
					</div>
				</form>
				<?php 
				if(isset($_REQUEST["submit"]))
				{
					$pid=mysqli_real_escape_string($db,$_POST["pid"]);
					$pname=mysqli_real_escape_string($db,$_POST["pname"]);
					$report_date=mysqli_real_escape_string($db,date("Y-m-d",strtotime($_POST["report_date"])));
					$hb=mysqli_real_escape_string($db,$_POST["hb"]);
					$n=mysqli_real_escape_string($db,$_POST["n"]);
					$m=mysqli_real_escape_string($db,$_POST["m"]);
					$sugf=mysqli_real_escape_string($db,$_POST["sugf"]);
					$esr=mysqli_real_escape_string($db,$_POST["esr"]);
					$culture=mysqli_real_escape_string($db,$_POST["culture"]);
					$xray=mysqli_real_escape_string($db,$_POST["xray"]);
					$usg=mysqli_real_escape_string($db,$_POST["usg"]);
					$others=mysqli_real_escape_string($db,$_POST["others"]);
					$tlc=mysqli_real_escape_string($db,$_POST["tlc"]);
					$e=mysqli_real_escape_string($db,$_POST["e"]);
					$b=mysqli_real_escape_string($db,$_POST["b"]);
					$pp=mysqli_real_escape_string($db,$_POST["pp"]);
					$ra=mysqli_real_escape_string($db,$_POST["ra"]);
					$cur=date("Y-m-d");
					// check if lab report is already created
					$chklab=mysqli_query($db,"select * from lab_report where patient_id='".$_GET["pid"]."' and report_date='$report_date'");
					if(mysqli_num_rows($chklab)>0)
					{
						echo "<script> alert('Lab Report is already created for this date!') </script>";
						echo "<script> window.location.href='$refs' </script>";
					}
					else
					{
					$inssql=mysqli_query($db,"insert into lab_report values('','$pid','$pname','','$report_date','$hb','$n','$m','$sugf','$esr','$culture','$xray','$usg','$others','$tlc','$e','$b','$pp','$ra')");
					
						if($inssql)
						{
							echo "<script> alert('Lab Report Created Successfully!') </script>";
							echo "<script> window.location.href='$refs' </script>";
						}
					}
					
				}
				?>
			</div>	
		</div>	
	<div id = "footer">
		<label class = "footer-title">&copy; Copyright EyeCare 2022</label>
	</div>
<?php require'script.php' ?>
<script type = "text/javascript">
    $(document).ready(function() {
        function disableBack() { window.history.forward() }

        window.onload = disableBack();
        window.onpageshow = function(evt) { if (evt.persisted) disableBack() }
    });
</script>	
</body>
</html>