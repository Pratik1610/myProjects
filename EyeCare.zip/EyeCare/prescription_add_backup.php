<!DOCTYPE html>
<?php
    ob_start();
	require_once 'logincheck.php';
	require_once 'authentication.php';
?>
<html lang = "eng">
	<head>
		<title>EyeCare</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "shortcut icon" href = "images/eye-gb51ecb13e_1280.PNG" />
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/customize.css" />
	</head>
<body>
	<div class = "navbar navbar-default navbar-fixed-top">
		<img src = "images/eye-gb51ecb13e_1280.PNG" style = "float:left;" height = "55px" /><label class = "navbar-brand">EyeCare</label>
			<?php
				$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
				$q = $conn->query("SELECT * FROM `user` WHERE `user_id` = '$_SESSION[user_id]'") or die(mysqli_error());
				$f = $q->fetch_array();
			?>
			<ul class = "nav navbar-right">	
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#">
						<span class = "glyphicon glyphicon-user"></span>
						<?php
							echo $f['firstname']." ".$f['lastname'];
							$conn->close();
						?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
					<li>
						<a class = "me" href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
	</div>
	<div id = "sidebar">
			<ul id = "menu" class = "nav menu">
				<li><a href = "home.php"><i class = "glyphicon glyphicon-home"></i> Dashboard</a></li>
				<li><a href = ""><i class = "glyphicon glyphicon-cog"></i> Accounts</a>
					<ul>
						<li><a href = "user.php"><i class = "glyphicon glyphicon-cog"></i> My Account</a></li>
					</ul>
				</li>
			</ul>
	</div>
	<div id = "content">
		<br />
		<br />
		<br />
		<div class = "panel panel-success">	
		<?php
			$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
			$query = $conn->query("SELECT * FROM `appointments` WHERE `id` = '$_GET[apid]'") or die(mysqli_error());
			$fetch = $query->fetch_array();
			$pid=$fetch["pid"]; // patient id
			$selp=mysqli_query($db,"select * from itr where patient_id='$pid'");
			$rowp=mysqli_fetch_array($selp);
		?>
			<div class = "panel-heading">
				<label>ADD Prescription</label>
				<a href = "home.php" class = "btn btn-sm btn-info" style = "float:right; margin-top:-5px;"><span class = "glyphicon glyphicon-hand-right"></span> BACK</a>
			</div>
			<div class = "panel-body">
				<form id = "form_admin" method = "POST" enctype = "multi-part/form-data" >
					<div class = "panel panel-default">
					<div class = "panel-heading">
					  <label>Patient Details</label>
					  <p><strong>Patient Name: </strong><?php echo ucwords($fetch["patient_name"]);?> &nbsp; &nbsp; 
				   <strong>Gender: </strong><?php echo ucwords($rowp["gender"]);?> &nbsp; &nbsp; 
				</p>
				<p><strong>Address: </strong><?php 
				if(!empty($rowp["house"]))
				{
					echo $rowp["house"]." ";
					$address=$rowp["house"]." ";
				}
				if(!empty($rowp["street"]))
				{
					echo $rowp["street"]." ";
					$address.=$rowp["street"]." ";
				}
				if(!empty($rowp["locality"]))
				{
					echo $rowp["locality"]." ";
					$address.=$rowp["locality"]." ";
				}
				if(!empty($rowp["city"]))
				{
					echo ",".$rowp["city"]." ";
					$address.=$rowp["city"]." ";
				}
				if(!empty($rowp["state"]))
				{
					echo $rowp["state"]." ";
					$address.=$rowp["state"]." ";
				}
				if(!empty($rowp["pin"]))
				{
					echo $rowp["pin"]." ";
					$address.=$rowp["pin"]." ";
				}
				?>
				</p>
					</div>
					<div class = "panel-body">
							<input class = "form-control" name = "name" value = "<?php echo $fetch['patient_name'] ?>" type = "hidden" readonly>
							<input class = "form-control" name = "pid" value = "<?php echo $fetch['pid'] ?>" type = "hidden">
							<input class = "form-control" name = "apid" value = "<?php echo $fetch['id'] ?>" type = "hidden">
						
						<div class = "form-group">	
							<label for = "co">co: </label>
							<input class = "form-control" name = "co"  maxlength = "12" type = "text" required = "required">
						</div>
							<input class = "form-control" type = "hidden" value = "<?php echo $rowp['age'] ?>" name = "age"  required = "required">
							<input class = "form-control" type = "hidden" value = "<?php echo $rowp['gender'] ?>" name = "gender"  required = "required">
						<div class = "form-group">
							<label for = "pres_date">Date: </label>
							<input class = "form-control" type = "date" name = "pres_date" required>
						</div>
						
						<div class = "form-group">
							<label for = "contact">Contact Number: </label>
							<input class = "form-control" type = "text" name = "contact"  required = "required">
						</div>
						
							<input class = "form-control" type = "hidden" name = "address" value = "<?php echo $address; ?>"  required = "required">
						
							<br />
					</div>				
					</div>
					
					<div class = "panel panel-default">
					<div class = "panel-heading">
					  <label>Diagnosis / RX Field</label>
					</div>
					<div class = "panel-body">
						<div class = "form-group">
							<label for = "username">Eye: </label>
							<select name="eye" class="form-control" required>
							<option value="">----Select Eye----</option>
							<?php
							 $seleye=mysqli_query($db,"select distinct eye from prescription_analysis");
							 while($roweye=mysqli_fetch_array($seleye))
							 {
							?>
							<option><?php echo $roweye["eye"];?></option>
							<?php
							 }
							 ?>
							 </select>
						</div>
						<div class = "form-group">	
							<label for = "username">Diagnosis: </label>
							<select id="diagnosissel" class="form-control" onchange="pushdiagnosis()">
							<option value="">----Select Diagnosis----</option>
							<?php
							 $seldiagnosis=mysqli_query($db,"select distinct diagnosis from prescription_analysis");
							 while($rowdiagnosis=mysqli_fetch_array($seldiagnosis))
							 {
							?>
							<option><?php echo $rowdiagnosis["diagnosis"];?></option>
							<?php
							 }
							 ?>
							 </select><br>
							 <textarea name="diagnosis" id="diagnosistxt" placeholder="Your diagnosis will show here" rows="5" cols="143" required></textarea>
						</div>
						<div class = "form-group">	
							<label for = "username">Drug: </label>
							<select id="drugsel" class="form-control" onchange="pushdrug()">
							<option value="">----Select Drug----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct drug from prescription_analysis");
							 while($rowdrug=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowdrug["drug"];?></option>
							<?php
							 }
							 ?>
							 </select><br>
							 <textarea name="drug" id="drugtxt" placeholder="Your drug will show here" rows="5" cols="143" required></textarea>
						</div>
						<div class = "form-group">	
							<label for = "username">Frequency: </label>
							<select id="freqsel" class="form-control" onchange="pushfreq()">
							<option value="">----Select Frequency----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct freq from prescription_analysis");
							 while($rowfreq=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowfreq["freq"];?></option>
							<?php
							 }
							 ?>
							 </select><br>
							 <textarea name="frequency" id="freqtxt" placeholder="Frequency will show here" rows="5" cols="143" required></textarea>
						</div>
						
						<div class = "form-group">	
							<label for = "username">Duration: </label>
							<select id="dursel" class="form-control" onchange="pushdur()">
							<option value="">----Select Duration----</option>
							<?php
							 $seldur=mysqli_query($db,"select distinct duration from prescription_analysis");
							 while($rowdur=mysqli_fetch_array($seldur))
							 {
							?>
							<option><?php echo $rowdur["duration"];?></option>
							<?php
							 }
							 ?>
							 </select><br>
							 <textarea name="duration" id="durtxt" placeholder="Duration will show here" rows="5" cols="143" required></textarea>
						</div>
						
						<div class = "form-group">	
							<label for = "username">Diagnosis Eye: </label>
							<select id="deyesel" class="form-control" onchange="pushdeye()">
							<option value="">----Select Diagnosis Eye----</option>
							<?php
							 $seldeye=mysqli_query($db,"select distinct eye2 from prescription_analysis");
							 while($rowdeye=mysqli_fetch_array($seldeye))
							 {
							?>
							<option><?php echo $rowdeye["eye2"];?></option>
							<?php
							 }
							 ?>
							 </select><br>
							 <textarea name="deye" id="deyetxt" placeholder="Diagnosis eye will show here" rows="5" cols="143" required></textarea>
						</div>
						<div class = "form-group">	
							<label for = "advice">Advice: </label>
							<select id="advicesel" class="form-control" onchange="pushadvice()">
							<option value="">----Select Advice----</option>
							<?php
							 $seladv=mysqli_query($db,"select distinct adv from prescription_analysis");
							 while($rowadv=mysqli_fetch_array($seladv))
							 {
							?>
							<option><?php echo $rowadv["adv"];?></option>
							<?php
							 }
							 ?>
							 </select><br>
							 <textarea name="advice" id="advicetxt" placeholder="Your Advice" rows="5" cols="143" required></textarea>
						</div>
					</div>
					<?php //require 'edit_query.php' ?>					
					</div>
					
					<div class = "panel panel-default">
					<div class = "panel-heading">
					  <label>Examination</label>
					</div>
					<div class = "panel-body">
						<div class = "form-group">
							<label for = "od_unaided">OD Unaided: </label>
							<div class = "form-inline">
							<select name="od_unaided_va" class="form-control">
							<option value="">----Select va----</option>
							<?php
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 &nbsp;&nbsp;&nbsp;
							 <select name="od_unaided_nva" class="form-control">
							<option value="">----Select nva----</option>
							<?php
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						<div class = "form-group">
							<label for = "od_unaided">OD Old Spectacles: </label>
							<div class = "form-inline">
							<select name="od_old_va" class="form-control">
							<option value="">----Select va----</option>
							<?php
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 &nbsp;&nbsp;&nbsp;
							 <select name="od_old_nva" class="form-control">
							<option value="">----Select nva----</option>
							<?php
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						<div class = "form-group">
							<label>OD PH/SS: </label>
							<div class = "form-inline">
							<select name="od_phss_va" class="form-control">
							<option value="">----Select va----</option>
							<?php
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 &nbsp;&nbsp;&nbsp;
							 <select name="od_phss_nva" class="form-control">
							<option value="">----Select nva----</option>
							<?php
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						<div class = "form-group">
							<label for = "os_unaided">OS Unaided: </label>
							<div class = "form-inline">
							<select name="os_unaided_va" class="form-control">
							<option value="">----Select va----</option>
							<?php
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 &nbsp;&nbsp;&nbsp;
							 <select name="os_unaided_nva" class="form-control">
							<option value="">----Select nva----</option>
							<?php
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						<div class = "form-group">
							<label for = "os_unaided">OS Old Spectacles: </label>
							<div class = "form-inline">
							<select name="os_old_va" class="form-control">
							<option value="">----Select va----</option>
							<?php
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 &nbsp;&nbsp;&nbsp;
							 <select name="os_old_nva" class="form-control">
							<option value="">----Select nva----</option>
							<?php
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						<div class = "form-group">
							<label>OS PH/SS: </label>
							<div class = "form-inline">
							<select name="os_phss_va" class="form-control">
							<option value="">----Select va----</option>
							<?php
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 &nbsp;&nbsp;&nbsp;
							 <select name="os_phss_nva" class="form-control">
							<option value="">----Select nva----</option>
							<?php
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						<div class = "form-group">
							<label>OD SPH: </label>
							<select name="od_sph" class="form-control">
							<option value="">----Select----</option>
							<?php
							 $selglass=mysqli_query($db,"select distinct glass from prescription_analysis");
							 while($rowglass=mysqli_fetch_array($selglass))
							 {
							?>
							<option><?php echo $rowglass["glass"];?></option>
							<?php
							 }
							 ?>
							 </select>
						</div>
						<div class = "form-group">
							<label for = "od_unaided">OD CYL: </label>
							<select name="od_cyl" class="form-control">
							<option value="">----Select----</option>
							<?php
							 $selglass=mysqli_query($db,"select distinct glass from prescription_analysis");
							 while($rowglass=mysqli_fetch_array($selglass))
							 {
							?>
							<option><?php echo $rowglass["glass"];?></option>
							<?php
							 }
							 ?>
							 </select>
						</div>
						<div class = "form-group">
							<label for = "od_unaided">OD Axis: </label>
							<select name="od_axis" class="form-control">
							<option value="">----Select----</option>
							<?php
							 $selaxis=mysqli_query($db,"select distinct axis from prescription_analysis");
							 while($rowaxis=mysqli_fetch_array($selaxis))
							 {
							?>
							<option><?php echo $rowaxis["axis"];?></option>
							<?php
							 }
							 ?>
							 </select>
						</div>
						<div class = "form-group">
							<label for = "od_unaided">OD VA: </label>
							<select name="od_va" class="form-control">
							<option value="">----Select va----</option>
							<?php
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
						</div>
						<div class = "form-group">
							<label>OD Comment: </label>
							<input class = "form-control" type = "text" name = "od_comment">
						</div>
						<div class = "form-group">
							<label>OD Add: </label>
							<select name="od_add" class="form-control">
							<option value="">----Select----</option>
							<?php
							 $seladd=mysqli_query($db,"select distinct ad from prescription_analysis");
							 while($rowadd=mysqli_fetch_array($seladd))
							 {
							?>
							<option><?php echo $rowadd["ad"];?></option>
							<?php
							 }
							 ?>
							 </select>
						</div>
						<div class = "form-group">
							<label>OS SPH: </label>
							<select name="os_sph" class="form-control">
							<option value="">----Select----</option>
							<?php
							 $selglass=mysqli_query($db,"select distinct glass from prescription_analysis");
							 while($rowglass=mysqli_fetch_array($selglass))
							 {
							?>
							<option><?php echo $rowglass["glass"];?></option>
							<?php
							 }
							 ?>
							 </select>
						</div>
						<div class = "form-group">
							<label>OD CYL: </label>
							<select name="os_cyl" class="form-control">
							<option value="">----Select----</option>
							<?php
							 $selglass=mysqli_query($db,"select distinct glass from prescription_analysis");
							 while($rowglass=mysqli_fetch_array($selglass))
							 {
							?>
							<option><?php echo $rowglass["glass"];?></option>
							<?php
							 }
							 ?>
							 </select>
						</div>
						<div class = "form-group">
							<label>OD Axis: </label>
							<select name="os_axis" class="form-control">
							<option value="">----Select----</option>
							<?php
							 $selaxis=mysqli_query($db,"select distinct axis from prescription_analysis");
							 while($rowaxis=mysqli_fetch_array($selaxis))
							 {
							?>
							<option><?php echo $rowaxis["axis"];?></option>
							<?php
							 }
							 ?>
							 </select>
						</div>
						<div class = "form-group">
							<label>OS VA: </label>
							<select name="os_va" class="form-control">
							<option value="">----Select va----</option>
							<?php
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
						</div>
						<div class = "form-group">
							<label>OS Comment: </label>
							<input class = "form-control" type = "text" name = "os_comment">
						</div>
						<div class = "form-group">
							<label>OS Add: </label>
							<select name="os_add" class="form-control">
							<option value="">----Select----</option>
							<?php
							 $seladd=mysqli_query($db,"select distinct ad from prescription_analysis");
							 while($rowadd=mysqli_fetch_array($seladd))
							 {
							?>
							<option><?php echo $rowadd["ad"];?></option>
							<?php
							 }
							 ?>
							 </select>
						</div>
						<div class = "form-group">
							<label>IPD: </label>
							<select name="ipd" class="form-control">
							<option value="">----Select----</option>
							<?php
							 $selpd=mysqli_query($db,"select distinct pd from prescription_analysis");
							 while($rowpd=mysqli_fetch_array($selpd))
							 {
							?>
							<option><?php echo $rowpd["pd"];?></option>
							<?php
							 }
							 ?>
							 </select>
						</div>
						<div class = "form-group">
							<label>Head Posture: </label>
							<select name="head_posture" class="form-control">
							<option value="">----Select----</option>
							<?php
							 $selhead=mysqli_query($db,"select distinct head from prescription_analysis");
							 while($rowhead=mysqli_fetch_array($selhead))
							 {
							?>
							<option><?php echo $rowhead["head"];?></option>
							<?php
							 }
							 ?>
							 </select>
						</div>
						<div class = "form-group">
							<label>Forehead: </label>
							<div class="form-inline">
							<select name="od_forehead" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selfhead=mysqli_query($db,"select distinct forehead from prescription_analysis");
							 while($rowfhead=mysqli_fetch_array($selfhead))
							 {
							?>
							<option><?php echo $rowfhead["forehead"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 &nbsp; 
							 <select name="os_forehead" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selfhead=mysqli_query($db,"select distinct forehead from prescription_analysis");
							 while($rowfhead=mysqli_fetch_array($selfhead))
							 {
							?>
							<option><?php echo $rowfhead["forehead"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						<div class = "form-group">
							<label>Orbit: </label>
							<div class="form-inline">
							<input class = "form-control" type = "text" name="od_orbit" placeholder="OD Orbit">&nbsp;
							<input class = "form-control" type = "text" name="os_orbit" placeholder="OS Orbit">
							</div>
						</div>
						<div class = "form-group">
							<label>Eye brows: </label>
							<div class="form-inline">
							<select name="od_eyebrows" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $seleyebrows=mysqli_query($db,"select distinct eyebrows from prescription_analysis");
							 while($roweyebrows=mysqli_fetch_array($seleyebrows))
							 {
							?>
							<option><?php echo $roweyebrows["eyebrows"];?></option>
							<?php
							 }
							 ?>
							 </select>&nbsp;
							 <select name="os_eyebrows" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $seleyebrows=mysqli_query($db,"select distinct eyebrows from prescription_analysis");
							 while($roweyebrows=mysqli_fetch_array($seleyebrows))
							 {
							?>
							<option><?php echo $roweyebrows["eyebrows"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						<div class = "form-group">
							<label>Eye Lids: </label>
							<div class="form-inline">
							<input class = "form-control" type = "text" name = "od_eye_lids" placeholder="OD Eye Lid">&nbsp;
							<input class = "form-control" type = "text" name = "os_eye_lids" placeholder="OS Eye Lid">
							</div>
						</div>
						<div class = "form-group">
							<label>Eye Lids Position: </label>
							<div class="form-inline">
							<select name="od_eyelid_position" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $sellidpos=mysqli_query($db,"select distinct lidposition from prescription_analysis");
							 while($rowlidpos=mysqli_fetch_array($sellidpos))
							 {
							?>
							<option><?php echo $rowlidpos["lidposition"];?></option>
							<?php
							 }
							 ?>
							 </select>&nbsp;
							 <select name="os_eyelid_position" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $sellidpos=mysqli_query($db,"select distinct lidposition from prescription_analysis");
							 while($rowlidpos=mysqli_fetch_array($sellidpos))
							 {
							?>
							<option><?php echo $rowlidpos["lidposition"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						<div class = "form-group">
							<label>Eye Lids Skin: </label>
							<div class="form-inline">
							<select name="od_eyelid_skin" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $sellidskin=mysqli_query($db,"select distinct lidskin from prescription_analysis");
							 while($rowlidskin=mysqli_fetch_array($sellidskin))
							 {
							?>
							<option><?php echo $rowlidskin["lidskin"];?></option>
							<?php
							 }
							 ?>
							 </select>&nbsp;
							 <select name="os_eyelid_skin" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $sellidskin=mysqli_query($db,"select distinct lidskin from prescription_analysis");
							 while($rowlidskin=mysqli_fetch_array($sellidskin))
							 {
							?>
							<option><?php echo $rowlidskin["lidskin"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						<div class = "form-group">
							<label>Eye Lids Margine: </label>
							<div class="form-inline">
							<select name="od_eyelid_margine" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $sellidmargine=mysqli_query($db,"select distinct lidmargine from prescription_analysis");
							 while($rowlidmargine=mysqli_fetch_array($sellidmargine))
							 {
							?>
							<option><?php echo $rowlidmargine["lidmargine"];?></option>
							<?php
							 }
							 ?>
							 </select>&nbsp;
							 <select name="os_eyelid_margine" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $sellidmargine=mysqli_query($db,"select distinct lidmargine from prescription_analysis");
							 while($rowlidmargine=mysqli_fetch_array($sellidmargine))
							 {
							?>
							<option><?php echo $rowlidmargine["lidmargine"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						<div class = "form-group">
							<label>Lacrimal App: </label>
							<div class="form-inline">
							<input class = "form-control" type = "text" name = "od_lacrimal_app" placeholder="OD Lacrimal App">&nbsp;
							<input class = "form-control" type = "text" name = "os_lacrimal_app" placeholder="OS Lacrimal App">
							</div>
						</div>
						<div class = "form-group">
							<label>Eye Ball: </label>
							<div class="form-inline">
							<select name="od_eye_ball" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $seleyeball=mysqli_query($db,"select distinct eyeball from prescription_analysis");
							 while($roweyeball=mysqli_fetch_array($seleyeball))
							 {
							?>
							<option><?php echo $roweyeball["eyeball"];?></option>
							<?php
							 }
							 ?>
							 </select>&nbsp;
							 <select name="os_eye_ball" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $seleyeball=mysqli_query($db,"select distinct eyeball from prescription_analysis");
							 while($roweyeball=mysqli_fetch_array($seleyeball))
							 {
							?>
							<option><?php echo $roweyeball["eyeball"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						<div class = "form-group">
							<label>Eye Ball Moments: </label>
							<div class="form-inline">
							<select name="od_eyeball_moments" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selmoment=mysqli_query($db,"select distinct moments from prescription_analysis");
							 while($rowmoment=mysqli_fetch_array($selmoment))
							 {
							?>
							<option><?php echo $rowmoment["moments"];?></option>
							<?php
							 }
							 ?>
							 </select>&nbsp;
							<select name="os_eyeball_moments" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selmoment=mysqli_query($db,"select distinct moments from prescription_analysis");
							 while($rowmoment=mysqli_fetch_array($selmoment))
							 {
							?>
							<option><?php echo $rowmoment["moments"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						<div class = "form-group">
							<label>Conjunctiva: </label>
							<div class="form-inline">
							<select name="od_conjunctiva" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selconjunctiva=mysqli_query($db,"select distinct conjunctiva from prescription_analysis");
							 while($rowconjunctiva=mysqli_fetch_array($selconjunctiva))
							 {
							?>
							<option><?php echo $rowconjunctiva["conjunctiva"];?></option>
							<?php
							 }
							 ?>
							 </select>&nbsp;
							 <select name="os_conjunctiva" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selconjunctiva=mysqli_query($db,"select distinct conjunctiva from prescription_analysis");
							 while($rowconjunctiva=mysqli_fetch_array($selconjunctiva))
							 {
							?>
							<option><?php echo $rowconjunctiva["conjunctiva"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						<div class = "form-group">
							<label>Pulpebral Conjunctiva: </label>
							<div class="form-inline">
							<select name="od_pulpebral_conjunctiva" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selpulp=mysqli_query($db,"select distinct conjunctiva from prescription_analysis");
							 while($rowpulp=mysqli_fetch_array($selpulp))
							 {
							?>
							<option><?php echo $rowpulp["conjunctiva"];?></option>
							<?php
							 }
							 ?>
							 </select>&nbsp;
							 <select name="os_pulpebral_conjunctiva" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selpulp=mysqli_query($db,"select distinct conjunctiva from prescription_analysis");
							 while($rowpulp=mysqli_fetch_array($selpulp))
							 {
							?>
							<option><?php echo $rowpulp["conjunctiva"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						<div class = "form-group">
							<label>Bulbar Conjunctiva: </label>
							<div class="form-inline">
							<select name="od_bulbar_conjunctiva" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selbulbar=mysqli_query($db,"select distinct conjunctiva from prescription_analysis");
							 while($rowbulbar=mysqli_fetch_array($selbulbar))
							 {
							?>
							<option><?php echo $rowbulbar["conjunctiva"];?></option>
							<?php
							 }
							 ?>
							 </select>&nbsp;
							 <select name="os_bulbar_conjunctiva" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selbulbar=mysqli_query($db,"select distinct conjunctiva from prescription_analysis");
							 while($rowbulbar=mysqli_fetch_array($selbulbar))
							 {
							?>
							<option><?php echo $rowbulbar["conjunctiva"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						<div class = "form-group">
							<label>Cornea Size: </label>
							<div class="form-inline">
							<select name="od_cornea_size" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selcsize=mysqli_query($db,"select distinct corneasize from prescription_analysis");
							 while($rowcsize=mysqli_fetch_array($selcsize))
							 {
							?>
							<option><?php echo $rowcsize["corneasize"];?></option>
							<?php
							 }
							 ?>
							 </select>&nbsp;
							 <select name="os_cornea_size" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selcsize=mysqli_query($db,"select distinct corneasize from prescription_analysis");
							 while($rowcsize=mysqli_fetch_array($selcsize))
							 {
							?>
							<option><?php echo $rowcsize["corneasize"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						
						<div class = "form-group">
							<label>Cornea Surface: </label>
							<div class="form-inline">
							<select name="od_cornea_surface" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selcsurface=mysqli_query($db,"select distinct corneasurface from prescription_analysis");
							 while($rowcsurface=mysqli_fetch_array($selcsurface))
							 {
							?>
							<option><?php echo $rowcsurface["corneasurface"];?></option>
							<?php
							 }
							 ?>
							 </select>&nbsp;
							 <select name="os_cornea_surface" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selcsurface=mysqli_query($db,"select distinct corneasurface from prescription_analysis");
							 while($rowcsurface=mysqli_fetch_array($selcsurface))
							 {
							?>
							<option><?php echo $rowcsurface["corneasurface"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						<div class = "form-group">
							<label>Cornea Transparency: </label>
							<div class="form-inline">
							<select name="od_transparency" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $seltransparency=mysqli_query($db,"select distinct transparency from prescription_analysis");
							 while($rowtransparency=mysqli_fetch_array($seltransparency))
							 {
							?>
							<option><?php echo $rowtransparency["transparency"];?></option>
							<?php
							 }
							 ?>
							 </select>&nbsp;
							 <select name="os_transparency" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $seltransparency=mysqli_query($db,"select distinct transparency from prescription_analysis");
							 while($rowtransparency=mysqli_fetch_array($seltransparency))
							 {
							?>
							<option><?php echo $rowtransparency["transparency"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						
						<div class = "form-group">
							<label>Cornea Stroma: </label>
							<div class="form-inline">
							<select name="od_stroma" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selstroma=mysqli_query($db,"select distinct stroma from prescription_analysis");
							 while($rowstroma=mysqli_fetch_array($selstroma))
							 {
							?>
							<option><?php echo $rowstroma["stroma"];?></option>
							<?php
							 }
							 ?>
							 </select>&nbsp;
							 <select name="os_stroma" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selstroma=mysqli_query($db,"select distinct stroma from prescription_analysis");
							 while($rowstroma=mysqli_fetch_array($selstroma))
							 {
							?>
							<option><?php echo $rowstroma["stroma"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						<div class = "form-group">
							<label>Cornea Endothelium: </label>
							<div class="form-inline">
							<select name="od_endothelium" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selendoth=mysqli_query($db,"select distinct endoth from prescription_analysis");
							 while($rowendoth=mysqli_fetch_array($selendoth))
							 {
							?>
							<option><?php echo $rowendoth["endoth"];?></option>
							<?php
							 }
							 ?>
							 </select>&nbsp;
							 <select name="os_endothelium" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selendoth=mysqli_query($db,"select distinct endoth from prescription_analysis");
							 while($rowendoth=mysqli_fetch_array($selendoth))
							 {
							?>
							<option><?php echo $rowendoth["endoth"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						
						<div class = "form-group">
							<label>AC Contant: </label>
							<div class="form-inline">
							<select name="od_accontant" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selaccontant=mysqli_query($db,"select distinct accontant from prescription_analysis");
							 while($rowaccontant=mysqli_fetch_array($selaccontant))
							 {
							?>
							<option><?php echo $rowaccontant["accontant"];?></option>
							<?php
							 }
							 ?>
							 </select>&nbsp;
							 <select name="os_accontant" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selaccontant=mysqli_query($db,"select distinct accontant from prescription_analysis");
							 while($rowaccontant=mysqli_fetch_array($selaccontant))
							 {
							?>
							<option><?php echo $rowaccontant["accontant"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						
						<div class = "form-group">
							<label>AC Depth: </label>
							<div class="form-inline">
							<select name="od_acdepth" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selacdepth=mysqli_query($db,"select distinct acdepth from prescription_analysis");
							 while($rowacdepth=mysqli_fetch_array($selacdepth))
							 {
							?>
							<option><?php echo $rowacdepth["acdepth"];?></option>
							<?php
							 }
							 ?>
							 </select>&nbsp;
							 <select name="os_acdepth" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selacdepth=mysqli_query($db,"select distinct acdepth from prescription_analysis");
							 while($rowacdepth=mysqli_fetch_array($selacdepth))
							 {
							?>
							<option><?php echo $rowacdepth["acdepth"];?></option>
							<?php
							 }
							 ?>
							 </select>&nbsp;
							 </div>
						</div>
						
						<div class = "form-group">
							<label>IRIS Colour: </label>
							<div class="form-inline">
							<select name="od_iriscolour" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $seliriscolour=mysqli_query($db,"select distinct iriscolour from prescription_analysis");
							 while($rowiriscolour=mysqli_fetch_array($seliriscolour))
							 {
							?>
							<option><?php echo $rowiriscolour["iriscolour"];?></option>
							<?php
							 }
							 ?>
							 </select>&nbsp;
							 <select name="os_iriscolour" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $seliriscolour=mysqli_query($db,"select distinct iriscolour from prescription_analysis");
							 while($rowiriscolour=mysqli_fetch_array($seliriscolour))
							 {
							?>
							<option><?php echo $rowiriscolour["iriscolour"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						
						<div class = "form-group">
							<label>IRIS Pattern: </label>
							<div class="form-inline">
							<select name="od_irispattern" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selirispattern=mysqli_query($db,"select distinct irispattern from prescription_analysis");
							 while($rowirispattern=mysqli_fetch_array($selirispattern))
							 {
							?>
							<option><?php echo $rowirispattern["irispattern"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 <select name="os_irispattern" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selirispattern=mysqli_query($db,"select distinct irispattern from prescription_analysis");
							 while($rowirispattern=mysqli_fetch_array($selirispattern))
							 {
							?>
							<option><?php echo $rowirispattern["irispattern"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						
						<div class = "form-group">
							<label>Pupil Size: </label>
							<div class="form-inline">
							<select name="od_pupilsize" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selpupilsize=mysqli_query($db,"select distinct pupilsize from prescription_analysis");
							 while($rowpupilsize=mysqli_fetch_array($selpupilsize))
							 {
							?>
							<option><?php echo $rowpupilsize["pupilsize"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 <select name="os_pupilsize" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selpupilsize=mysqli_query($db,"select distinct pupilsize from prescription_analysis");
							 while($rowpupilsize=mysqli_fetch_array($selpupilsize))
							 {
							?>
							<option><?php echo $rowpupilsize["pupilsize"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						
						<div class = "form-group">
							<label>Pupil Shape: </label>
							<div class="form-inline">
							<select name="od_pupilshape" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selpupilshape=mysqli_query($db,"select distinct pupilshape from prescription_analysis");
							 while($rowpupilshape=mysqli_fetch_array($selpupilshape))
							 {
							?>
							<option><?php echo $rowpupilshape["pupilshape"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 <select name="os_pupilshape" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selpupilshape=mysqli_query($db,"select distinct pupilshape from prescription_analysis");
							 while($rowpupilshape=mysqli_fetch_array($selpupilshape))
							 {
							?>
							<option><?php echo $rowpupilshape["pupilshape"];?></option>
							<?php
							 }
							 ?>
							 </select>
							</div> 
						</div>
						
						<div class = "form-group">
							<label>Pupil Reaction: </label>
							<div class="form-inline">
							<select name="od_pupilreaction" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selpupilreaction=mysqli_query($db,"select distinct pupilreaction from prescription_analysis");
							 while($rowpupilreaction=mysqli_fetch_array($selpupilreaction))
							 {
							?>
							<option><?php echo $rowpupilreaction["pupilreaction"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 <select name="os_pupilreaction" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selpupilreaction=mysqli_query($db,"select distinct pupilreaction from prescription_analysis");
							 while($rowpupilreaction=mysqli_fetch_array($selpupilreaction))
							 {
							?>
							<option><?php echo $rowpupilreaction["pupilreaction"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						
						<div class = "form-group">
							<label>Lens Opacity: </label>
							<div class="form-inline">
							<select name="od_lens_opacity" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $sellens_opacity=mysqli_query($db,"select distinct lens from prescription_analysis");
							 while($rowlens=mysqli_fetch_array($sellens_opacity))
							 {
							?>
							<option><?php echo $rowlens["lens"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 <select name="os_lens_opacity" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $sellens_opacity=mysqli_query($db,"select distinct lens from prescription_analysis");
							 while($rowlens=mysqli_fetch_array($sellens_opacity))
							 {
							?>
							<option><?php echo $rowlens["lens"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						<div class = "form-group">
							<label>IOP: </label>
							<div class="form-inline">
							<input class = "form-control" type = "text" name = "od_IOP" placeholder="OD IOP">
							<input class = "form-control" type = "text" name = "os_IOP" placeholder="OS IOP">
							</div>
						</div>
						<div class = "form-group">
							<label>Media: </label>
							<div class="form-inline">
							<select name="od_media" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selmedia=mysqli_query($db,"select distinct media from prescription_analysis");
							 while($rowmedia=mysqli_fetch_array($selmedia))
							 {
							?>
							<option><?php echo $rowmedia["media"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 <select name="os_media" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selmedia=mysqli_query($db,"select distinct media from prescription_analysis");
							 while($rowmedia=mysqli_fetch_array($selmedia))
							 {
							?>
							<option><?php echo $rowmedia["media"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						
						<div class = "form-group">
							<label>Optic Disc: </label>
							<div class="form-inline">
							<select name="od_optic_disc" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $seloptic=mysqli_query($db,"select distinct opticdisc from prescription_analysis");
							 while($rowoptic=mysqli_fetch_array($seloptic))
							 {
							?>
							<option><?php echo $rowoptic["opticdisc"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 <select name="os_optic_disc" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $seloptic=mysqli_query($db,"select distinct opticdisc from prescription_analysis");
							 while($rowoptic=mysqli_fetch_array($seloptic))
							 {
							?>
							<option><?php echo $rowoptic["opticdisc"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						
						<div class = "form-group">
							<label>Disc Size: </label>
							<div class="form-inline">
							<select name="od_disc_size" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $seldiscsize=mysqli_query($db,"select distinct discsize from prescription_analysis");
							 while($rowdiscsize=mysqli_fetch_array($seldiscsize))
							 {
							?>
							<option><?php echo $rowdiscsize["discsize"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 <select name="os_disc_size" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $seldiscsize=mysqli_query($db,"select distinct discsize from prescription_analysis");
							 while($rowdiscsize=mysqli_fetch_array($seldiscsize))
							 {
							?>
							<option><?php echo $rowdiscsize["discsize"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						
						<div class = "form-group">
							<label>Disc Shape: </label>
							<div class="form-inline">
							<select name="od_disc_shape" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $seldiscshape=mysqli_query($db,"select distinct discshape from prescription_analysis");
							 while($rowdiscshape=mysqli_fetch_array($seldiscshape))
							 {
							?>
							<option><?php echo $rowdiscshape["discshape"];?></option>
							<?php
							 }
							 ?>
							 </select>
							<select name="os_disc_shape" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $seldiscshape=mysqli_query($db,"select distinct discshape from prescription_analysis");
							 while($rowdiscshape=mysqli_fetch_array($seldiscshape))
							 {
							?>
							<option><?php echo $rowdiscshape["discshape"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						
						<div class = "form-group">
							<label>Disc Colour: </label>
							<div class="form-inline">
							<select name="od_disc_colour" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $seldisccolour=mysqli_query($db,"select distinct disccolour from prescription_analysis");
							 while($rowdisccolour=mysqli_fetch_array($seldisccolour))
							 {
							?>
							<option><?php echo $rowdisccolour["disccolour"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 <select name="os_disc_colour" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $seldisccolour=mysqli_query($db,"select distinct disccolour from prescription_analysis");
							 while($rowdisccolour=mysqli_fetch_array($seldisccolour))
							 {
							?>
							<option><?php echo $rowdisccolour["disccolour"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						
						<div class = "form-group">
							<label>Disc Margine: </label>
							<div class="form-inline">
							<select name="od_disc_margine" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $seldiscmargine=mysqli_query($db,"select distinct discmargine from prescription_analysis");
							 while($rowdiscmargine=mysqli_fetch_array($seldiscmargine))
							 {
							?>
							<option><?php echo $rowdiscmargine["discmargine"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 <select name="os_disc_margine" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $seldiscmargine=mysqli_query($db,"select distinct discmargine from prescription_analysis");
							 while($rowdiscmargine=mysqli_fetch_array($seldiscmargine))
							 {
							?>
							<option><?php echo $rowdiscmargine["discmargine"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						
						<div class = "form-group">
							<label>CD Ratio: </label>
							<div class="form-inline">
							<select name="od_cd_ratio" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selcdratio=mysqli_query($db,"select distinct cdratio from prescription_analysis");
							 while($rowcdratio=mysqli_fetch_array($selcdratio))
							 {
							?>
							<option><?php echo $rowcdratio["cdratio"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 <select name="os_cd_ratio" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selcdratio=mysqli_query($db,"select distinct cdratio from prescription_analysis");
							 while($rowcdratio=mysqli_fetch_array($selcdratio))
							 {
							?>
							<option><?php echo $rowcdratio["cdratio"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						<div class = "form-group">
							<label>Blood Vessels over Disc: </label>
							<div class="form-inline">
							<select name="od_bv_disc" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selbvdisc=mysqli_query($db,"select distinct bvdisc from prescription_analysis");
							 while($rowbvdisc=mysqli_fetch_array($selbvdisc))
							 {
							?>
							<option><?php echo $rowbvdisc["bvdisc"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 <select name="os_bv_disc" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selbvdisc=mysqli_query($db,"select distinct bvdisc from prescription_analysis");
							 while($rowbvdisc=mysqli_fetch_array($selbvdisc))
							 {
							?>
							<option><?php echo $rowbvdisc["bvdisc"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						<div class = "form-group">
							<label>Blood Vessels over GF </label>
							<div class="form-inline">
							<select name="od_bv_gf" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selbvgf=mysqli_query($db,"select distinct bvgf from prescription_analysis");
							 while($rowbvgf=mysqli_fetch_array($selbvgf))
							 {
							?>
							<option><?php echo $rowbvgf["bvgf"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 <select name="os_bv_gf" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selbvgf=mysqli_query($db,"select distinct bvgf from prescription_analysis");
							 while($rowbvgf=mysqli_fetch_array($selbvgf))
							 {
							?>
							<option><?php echo $rowbvgf["bvgf"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 </div>
						</div>
						
						<div class = "form-group">	
							<label for = "macula">Macula: </label>
							<div class="form-inline">
							<select id="od_maculasel" class="form-control" onchange="pushmaculaod()">
							<option value="">----Select Macula for OD----</option>
							<?php
							 $selmacula=mysqli_query($db,"select distinct macula from prescription_analysis");
							 while($rowmacula=mysqli_fetch_array($selmacula))
							 {
							?>
							<option><?php echo $rowmacula["macula"];?></option>
							<?php
							 }
							 ?>
							 </select><br>
							 <textarea name="od_macula" id="od_maculatxt" placeholder="Macula" rows="5" cols="143"></textarea>
							 
							 <select id="os_maculasel" class="form-control" onchange="pushmaculaos()">
							<option value="">----Select Macula for OS----</option>
							<?php
							 $selmacula=mysqli_query($db,"select distinct macula from prescription_analysis");
							 while($rowmacula=mysqli_fetch_array($selmacula))
							 {
							?>
							<option><?php echo $rowmacula["macula"];?></option>
							<?php
							 }
							 ?>
							 </select><br>
							 <textarea name="os_macula" id="os_maculatxt" placeholder="Macula" rows="5" cols="143"></textarea>
							 </div>
						</div>
						
						<div class = "form-group">	
							<label for = "gf">General Fundus: </label>
							<div class="form-inline">
							<select id="od_gfsel" class="form-control" onchange="pushgfod()">
							<option value="">----Select for OD----</option>
							<?php
							 $selgf=mysqli_query($db,"select distinct gf from prescription_analysis");
							 while($rowgf=mysqli_fetch_array($selgf))
							 {
							?>
							<option><?php echo $rowgf["gf"];?></option>
							<?php
							 }
							 ?>
							 </select><br>
							 <textarea name="od_gf" id="od_gftxt" placeholder="General Fundus" rows="5" cols="143"></textarea>
							 <select id="os_gfsel" class="form-control" onchange="pushgfos()">
							<option value="">----Select for OS----</option>
							<?php
							 $selgf=mysqli_query($db,"select distinct gf from prescription_analysis");
							 while($rowgf=mysqli_fetch_array($selgf))
							 {
							?>
							<option><?php echo $rowgf["gf"];?></option>
							<?php
							 }
							 ?>
							 </select><br>
							 <textarea name="os_gf" id="os_gftxt" placeholder="General Fundus" rows="5" cols="143"></textarea>
							 </div>
						</div>
						
						<div class = "form-group">
							<label>Syringing: </label>
							<div class="form-inline">
							<input class = "form-control" type = "text" name = "od_syringing" placeholder="Syringing for OD">
							<input class = "form-control" type = "text" name = "os_syringing" placeholder="Syringing for OS">
							</div>
						</div>
						
						<div class = "form-group">
							<label>Shirmers Test: </label>
							<div class="form-inline">
							<input class = "form-control" type = "text" name = "od_shirmers_test" placeholder="For OD">
							<input class = "form-control" type = "text" name = "os_shirmers_test" placeholder="For OS">
							</div>
						</div>
						
						<div class = "form-group">
							<label>Gonioscopy: </label>
							<div class="form-inline">
							<input class = "form-control" type = "text" name = "od_gonioscopy" placeholder="For OD">
							<input class = "form-control" type = "text" name = "os_gonioscopy" placeholder="For OS">
							</div>
						</div>
						
						<div class = "form-group">
							<label>Photograph Number: </label>
							<div class="form-inline">
							<input class = "form-control" type = "text" name = "od_phno" placeholder="For OD">
							<input class = "form-control" type = "text" name = "os_phno" placeholder="For OS">
							</div>
						</div>
						
						<div class = "form-group">
							<label>Followup Date: </label>
							<input class = "form-control" type = "date" name = "followup_date">
						</div>
						
						<div class = "form-group">
							<label>Followup Note: </label>
							<textarea name="followup_note" class="form-control" rows="5" cols="143"></textarea>
						</div>
						
						
							<button  class = "btn btn-warning" name = "submit" ><span class = "glyphicon glyphicon-edit"></span> SAVE</button>
							<br />
					</div>
					<?php 
						if(isset($_REQUEST["submit"]))
						{
							$od_unaided=$_POST["od_unaided_va"]." ".$_POST["od_unaided_nva"];
							$od_old=$_POST["od_old_va"]." ".$_POST["od_old_nva"];
							$od_phss=$_POST["od_phss_va"]." ".$_POST["od_phss_nva"];
							$os_unaided=$_POST["os_unaided_va"]." ".$_POST["os_unaided_nva"];
							$os_old=$_POST["os_old_va"]." ".$_POST["os_old_nva"];
							$os_phss=$_POST["os_phss_va"]." ".$_POST["os_phss_nva"];
							$od_sph=$_POST["od_sph"];
							$od_cyl=$_POST["od_cyl"];
							$od_axis=$_POST["od_axis"];
							$od_va=$_POST["od_va"];
							$od_comment=$_POST["od_comment"];
							$od_add=$_POST["od_add"];
							$os_sph=$_POST["os_sph"];
							$os_cyl=$_POST["os_cyl"];
							$os_axis=$_POST["os_axis"];
							$os_va=$_POST["os_va"];
							$os_comment=$_POST["os_comment"];
							$os_add=$_POST["os_add"];
							$ipd=$_POST["ipd"];
							$head_posture=$_POST["head_posture"];
							$od_forehead=$_POST["od_forehead"];
							$od_orbit=$_POST["od_orbit"];
							$od_eye_brows=$_POST["od_eyebrows"];
							$od_eye_lids=$_POST["od_eye_lids"];
							$od_position_eyelids=$_POST["od_eyelid_position"];
							$od_skin_eyelids=$_POST["od_eyelid_skin"];
							$od_margins_eyelids=$_POST["od_eyelid_margine"];
							$od_lacrimal_app=$_POST["od_lacrimal_app"];
							$od_eye_ball=$_POST["od_eye_ball"];
							$od_moments_eyeball=$_POST["od_eyeball_moments"];
							$od_conjunctiva=$_POST["od_conjunctiva"];
							$od_pulpebral_conjunctiva=$_POST["od_pulpebral_conjunctiva"];
							$od_bulbar_conjuctiva=$_POST["od_bulbar_conjunctiva"];
							$od_cornea_size=$_POST["od_cornea_size"];
							$od_cornea_surface=$_POST["od_cornea_surface"];
							$od_transparency=$_POST["od_transparency"];
							$od_stroma=$_POST["od_stroma"];
							$od_endothelium=$_POST["od_endothelium"];
							$od_accontant=$_POST["od_accontant"];
							$od_acdepth=$_POST["od_acdepth"];
							$od_iriscolour=$_POST["od_iriscolour"];
							$od_irispattern=$_POST["od_irispattern"];
							$od_pupilsize=$_POST["od_pupilsize"];
							$od_pupilshape=$_POST["od_pupilshape"];
							$od_pupilreaction=$_POST["od_pupilreaction"];
							$od_lens_opacity=$_POST["od_lens_opacity"];
							$od_iop=$_POST["od_IOP"];
							$od_media=$_POST["od_media"];
							$od_optic_disc=$_POST["od_optic_disc"];
							$od_disc_size=$_POST["od_disc_size"];
							$od_disc_shape=$_POST["od_disc_shape"];
							$od_disc_colour=$_POST["od_disc_colour"];
							$od_disc_margine=$_POST["od_disc_margine"];
							$od_cd_ratio=$_POST["od_cd_ratio"];
							$od_bv_disc=$_POST["od_bv_disc"];
							$od_bv_gf=$_POST["od_bv_gf"];
							$od_macula=$_POST["od_macula"];
							$od_gf=$_POST["od_gf"];
							$od_syringing=$_POST["od_syringing"];
							$od_shirmers_test=$_POST["od_shirmers_test"];
							$od_gonioscopy=$_POST["od_gonioscopy"];
							$od_photograph_num=$_POST["od_phno"];
							
							$os_forehead=$_POST["os_forehead"];
							$os_orbit=$_POST["os_orbit"];
							$os_eye_brows=$_POST["os_eyebrows"];
							$os_eye_lids=$_POST["os_eye_lids"];
							$os_position_eyelids=$_POST["os_eyelid_position"];
							$os_skin_eyelids=$_POST["os_eyelid_skin"];
							$os_margins_eyelids=$_POST["os_eyelid_margine"];
							$os_lacrimal_app=$_POST["os_lacrimal_app"];
							$os_eye_ball=$_POST["os_eye_ball"];
							$os_moments_eyeball=$_POST["os_eyeball_moments"];
							$os_conjunctiva=$_POST["os_conjunctiva"];
							$os_pulpebral_conjunctiva=$_POST["os_pulpebral_conjunctiva"];
							$os_bulbar_conjuctiva=$_POST["os_bulbar_conjunctiva"];
							$os_cornea_size=$_POST["os_cornea_size"];
							$os_cornea_surface=$_POST["os_cornea_surface"];
							$os_transparency=$_POST["os_transparency"];
							$os_stroma=$_POST["os_stroma"];
							$os_endothelium=$_POST["os_endothelium"];
							$os_accontant=$_POST["os_accontant"];
							$os_acdepth=$_POST["os_acdepth"];
							$os_iriscolour=$_POST["os_iriscolour"];
							$os_irispattern=$_POST["os_irispattern"];
							$os_pupilsize=$_POST["os_pupilsize"];
							$os_pupilshape=$_POST["os_pupilshape"];
							$os_pupilreaction=$_POST["os_pupilreaction"];
							$os_lens_opacity=$_POST["os_lens_opacity"];
							$os_iop=$_POST["os_IOP"];
							$os_media=$_POST["os_media"];
							$os_optic_disc=$_POST["os_optic_disc"];
							$os_disc_size=$_POST["os_disc_size"];
							$os_disc_shape=$_POST["os_disc_shape"];
							$os_disc_colour=$_POST["os_disc_colour"];
							$os_disc_margine=$_POST["os_disc_margine"];
							$os_cd_ratio=$_POST["os_cd_ratio"];
							$os_bv_disc=$_POST["os_bv_disc"];
							$os_bv_gf=$_POST["os_bv_gf"];
							$os_macula=$_POST["os_macula"];
							$os_gf=$_POST["os_gf"];
							$os_syringing=$_POST["os_syringing"];
							$os_shirmers_test=$_POST["os_shirmers_test"];
							$os_gonioscopy=$_POST["os_gonioscopy"];
							$os_photograph_num=$_POST["os_phno"];
							
							$followup_date=$_POST["followup_date"];
							$followup_note=$_POST["followup_note"];
							
							$inssql=mysqli_query($db,"INSERT INTO `prescriptions`(`id`, `patient_id`, `patient_name`, `appointment_id`, `co`, `age`, `gender`, `pres_date`, `contact_num`, `address`, `eye`, `diagnosis`, `drug`, `freq`, `duration`, `diagnosis_eye`, `od_unaided`, `od_old_spectacles`, `od_ph_ss`, `os_unaided`, `os_old_spectacles`, `os_ph_ss`, `od_sph`, `od_cyl`, `od_axis`, `od_va`, `od_comment`, `od_add`, `os_sph`, `os_cyl`, `os_axis`, `os_va`, `os_comment`, `os_add`, `ipd`, `head_posture`, `od_forehead`, `od_orbit`, `od_eye_brows`, `od_eye_lids`, `od_position_eyelids`, `od_skin_eyelids`, `od_margins_eyelids`, `od_lacrimal_app`, `od_eye_ball`, `od_moments_eyeball`, `od_conjunctiva`, `od_pulpebral_conjunctiva`, `od_bulbar_conjunctiva`, `od_size_cornea`, `od_surface_cornea`, `od_transparency_cornea`, `od_stroma_cornea`, `od_endothelium_cornea`, `od_ac_contant`, `od_ac_depth`, `od_iris_colour`, `od_iris_pattern`, `od_pupil_size`, `od_pupil_shape`, `od_pupil_reaction`, `od_lens_opacity`, `od_iop`, `od_media`, `od_optic_disc`, `od_optic_disc_size`, `od_optic_disc_shape`, `od_optic_disc_colour`, `od_optic_disc_margine`, `od_cd_ratio`, `od_bv_over_disc`, `od_bv_over_gf`, `od_macula`, `od_gf`, `od_syringing`, `od_shirmers_test`, `od_gonioscopy`, `od_photograph_num`, `advice`, `folowup_date`, `followup_note`, `other_note`, `os_forehead`, `os_orbit`, `os_eye_brows`, `os_eye_lids`, `os_position_eyelids`, `os_skin_eyelids`, `os_margins_eyelids`, `os_lacrimal_app`, `os_eye_ball`, `os_moments_eyeball`, `os_conjunctiva`, `os_pulpebral_conjunctiva`, `os_bulbar_conjunctiva`, `os_size_cornea`, `os_surface_cornea`, `os_transparency_cornea`, `os_stroma_cornea`, `os_endothelium_cornea`, `os_ac_contant`, `os_ac_depth`, `os_iris_colour`, `os_iris_pattern`, `os_pupil_size`, `os_pupil_shape`, `os_pupil_reaction`, `os_lens_opacity`, `os_iop`, `os_media`, `os_optic_disc`, `os_optic_disc_size`, `os_optic_disc_shape`, `os_optic_disc_colour`, `os_optic_disc_margine`, `os_cd_ratio`, `os_bv_over_disc`, `os_bv_over_gf`, `os_macula`, `os_gf`, `os_syringing`, `os_shirmers_test`, `os_gonioscopy`, `os_photograph_num`) VALUES ('','".$_POST['pid']."','".$_POST['name']."','".$_POST['apid']."','".$_POST['co']."','".$_POST['age']."','".$_POST['gender']."','".$_POST['pres_date']."','".$_POST['contact']."','".$_POST['address']."','".$_POST['eye']."','".$_POST['diagnosis']."','".$_POST['drug']."','".$_POST['frequency']."','".$_POST['duration']."','".$_POST['deye']."','$od_unaided','$od_old','$od_phss','$os_unaided','$os_old','$os_phss','$od_sph','$od_cyl','$od_axis','$od_va','$od_comment','$od_add','$os_sph','$os_cyl','$os_axis','$os_va','$os_comment','$os_add','$ipd','$head_posture','$od_forehead','$od_orbit','$od_eye_brows','$od_eye_lids','$od_position_eyelids','$od_skin_eyelids','$od_margins_eyelids','$od_lacrimal_app','$od_eye_ball','$od_moments_eyeball','$od_conjunctiva','$od_pulpebral_conjunctiva','$od_bulbar_conjuctiva','$od_cornea_size','$od_cornea_surface','$od_transparency','$od_stroma','$od_endothelium','$od_accontant','$od_acdepth','$od_iriscolour','$od_irispattern','$od_pupilsize','$od_pupilshape','$od_pupilreaction','$od_lens_opacity','$od_iop','$od_media','$od_optic_disc','$od_disc_size','$od_disc_shape','$od_disc_colour','$od_disc_margine','$od_cd_ratio','$od_bv_disc','$od_bv_gf','$od_macula','$od_gf','$od_syringing','$od_shirmers_test','$od_gonioscopy','$od_photograph_num','".$_POST["advice"]."','$followup_date','$followup_note','','$os_forehead','$os_orbit','$os_eye_brows','$os_eye_lids','$os_position_eyelids','$os_skin_eyelids','$os_margins_eyelids','$os_lacrimal_app','$os_eye_ball','$os_moments_eyeball','$os_conjunctiva','$os_pulpebral_conjunctiva','$os_bulbar_conjuctiva','$os_cornea_size','$os_cornea_surface','$os_transparency','$os_stroma','$os_endothelium','$os_accontant','$os_acdepth','$os_iriscolour','$os_irispattern','$os_pupilsize','$os_pupilshape','$os_pupilreaction','$os_lens_opacity','$os_iop','$os_media','$os_optic_disc','$os_disc_size','$os_disc_shape','$os_disc_colour','$os_disc_margine','$os_cd_ratio','$os_bv_disc','$os_bv_gf','$os_macula','$os_gf','$os_syringing','$os_shirmers_test','$os_gonioscopy','$os_photograph_num')");
							if($inssql)
							{
								$insql=mysqli_query($db,"INSERT INTO `patients_visits`(`id`, `patient_name`, `patient_id`, `appointment_id`, `visit_date`) VALUES ('','".$_POST['name']."','".$_POST['pid']."','".$_POST['apid']."','".$_POST['pres_date']."')");
								echo "<script> alert('Prescription Added Successfully!') </script>";
								echo "<script> window.location.href='home.php' </script>";
							}
							else
							{
								echo mysqli_error($db);
							}
						}
					?>					
					</div>
				</form>
			</div>	
		</div>	
	</div>
	<div id = "footer">
		<label class = "footer-title">&copy; Copyright EyeCare 2022</label>
	</div>
<?php require'script.php' ?>
<script type = "text/javascript">
    $(document).ready(function() {
        function disableBack() { window.history.forward() }

        window.onload = disableBack();
        window.onpageshow = function(evt) { if (evt.persisted) disableBack() }
    });
</script>	
<script>
function pushdiagnosis(){
	var e = document.getElementById("diagnosissel");
	var diagnosisval = e.options[e.selectedIndex].text;
	document.getElementById("diagnosistxt").value += diagnosisval + '\r\n';
}
function pushdrug(){
	var e = document.getElementById("drugsel");
	var drugval = e.options[e.selectedIndex].text;
	document.getElementById("drugtxt").value += drugval + '\r\n';
}
function pushfreq(){
	var e = document.getElementById("freqsel");
	var freqval = e.options[e.selectedIndex].text;
	document.getElementById("freqtxt").value += freqval + '\r\n';
}
function pushdur(){
	var e = document.getElementById("dursel");
	var durval = e.options[e.selectedIndex].text;
	document.getElementById("durtxt").value += durval + '\r\n';
}
function pushdeye(){
	var e = document.getElementById("deyesel");
	var deyeval = e.options[e.selectedIndex].text;
	document.getElementById("deyetxt").value += deyeval + '\r\n';
}
function pushadvice(){
	var e = document.getElementById("advicesel");
	var adviceval = e.options[e.selectedIndex].text;
	document.getElementById("advicetxt").value += adviceval + '\r\n';
}
function pushmaculaod(){
	
	var e = document.getElementById("od_maculasel");
	var maculaval = e.options[e.selectedIndex].text;
	document.getElementById("od_maculatxt").value += maculaval + '\r\n';
}
function pushmaculaos(){
	var e = document.getElementById("os_maculasel");
	var maculaval = e.options[e.selectedIndex].text;
	document.getElementById("os_maculatxt").value += maculaval + '\r\n';
}
function pushgfod(){
	var e = document.getElementById("od_gfsel");
	var gfval = e.options[e.selectedIndex].text;
	document.getElementById("od_gftxt").value += gfval + '\r\n';
}
function pushgfos(){
	var e = document.getElementById("os_gfsel");
	var gfval = e.options[e.selectedIndex].text;
	document.getElementById("os_gftxt").value += gfval + '\r\n';
}
</script>
</body>
</html>