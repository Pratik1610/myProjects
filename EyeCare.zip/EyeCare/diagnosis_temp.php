<!DOCTYPE html>
<?php
    ob_start();
	require_once 'logincheck.php';
	require_once 'authentication.php';
?>
<html lang = "eng">
	<head>
		<title>EyeCare</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "shortcut icon" href = "images/eye-gb51ecb13e_1280.PNG" />
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/customize.css" />
	</head>
<body>
	<div class = "navbar navbar-default navbar-fixed-top">
		<img src = "images/eye-gb51ecb13e_1280.PNG" style = "float:left;" height = "55px" /><label class = "navbar-brand">EyeCare</label>
			<?php
				$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
				$q = $conn->query("SELECT * FROM `user` WHERE `user_id` = '$_SESSION[user_id]'") or die(mysqli_error());
				$f = $q->fetch_array();
			?>
			<ul class = "nav navbar-nav navbar-right">	
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#" style="color:white;">
						<span class = "glyphicon glyphicon-user"></span>
						<?php
							echo $f['firstname']." ".$f["middlename"]." ".$f['lastname'];
							$conn->close();
						?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
					<li>
						<a class = "me" href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
	</div>
		<br />
		<br />
		<br />
		<div class = "panel panel-success">	
		<?php
			$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
			$query = $conn->query("SELECT * FROM `appointments` WHERE `id` = '$_GET[apid]'") or die(mysqli_error());
			$fetch = $query->fetch_array();
			$pid=$fetch["pid"]; // patient id
			$selp=mysqli_query($db,"select * from itr where patient_id='$pid'");
			$rowp=mysqli_fetch_array($selp);
		?>
			<div class = "panel-heading">
				<label>&nbsp;ADD Prescription>> Diagnosis</label>
			</div>
			<div class = "panel-body">
					<div class = "panel panel-default">
					<div class = "panel-heading">
					  <label>Patient Details</label>
					  <p><strong>Patient Name: </strong><?php echo ucwords($fetch["patient_name"]);?> &nbsp; &nbsp; 
				   <strong>Gender: </strong><?php echo ucwords($rowp["gender"]);?> &nbsp; &nbsp; 
				</p>
				<p><strong>Address: </strong><?php 
				if(!empty($rowp["house"]))
				{
					echo $rowp["house"]." ";
					$address=$rowp["house"]." ";
				}
				if(!empty($rowp["street"]))
				{
					echo $rowp["street"]." ";
					$address.=$rowp["street"]." ";
				}
				if(!empty($rowp["locality"]))
				{
					echo $rowp["locality"]." ";
					$address.=$rowp["locality"]." ";
				}
				if(!empty($rowp["city"]))
				{
					echo ",".$rowp["city"]." ";
					$address.=$rowp["city"]." ";
				}
				if(!empty($rowp["state"]))
				{
					echo $rowp["state"]." ";
					$address.=$rowp["state"]." ";
				}
				if(!empty($rowp["pin"]))
				{
					echo $rowp["pin"]." ";
					$address.=$rowp["pin"]." ";
				}
				?> &nbsp; &nbsp; 
				<strong>Age: </strong><?php echo ucwords($rowp["age"]);?><span> Years</span>
				</p>
					</div>
					</div>
					<form id = "form_admin" method = "POST" enctype = "multi-part/form-data" >
					    <ul class="nav nav-tabs">
							<li><a href="prescription_add.php?apid=<?php echo $_GET['apid'];?>">C/o</a></li>
							<li class="active"><a href="diagnosis_temp.php?apid=<?php echo $_GET['apid'];?>">Diagnosis</a></li>
							<li><a href="rx_temp.php?apid=<?php echo $_GET['apid'];?>">Rx</a></li>
							<li><a href="glasses_temp.php?apid=<?php echo $_GET['apid'];?>">Glasses</a></li>
							<li><a href="advice_temp.php?apid=<?php echo $_GET['apid'];?>">Advice</a></li>
							<li><a href="review_temp.php?apid=<?php echo $_GET['apid'];?>">Review</a></li>
							<li><a href="examination_temp.php?apid=<?php echo $_GET['apid'];?>">Examination</a></li>
							<li><a href="followup_temp.php?apid=<?php echo $_GET['apid'];?>">Followup Notes</a></li>
						</ul>
						<br>
						<br>
							<div class="form-inline">
							<input type="hidden" name="apid" value="<?php echo $_GET["apid"];?>">
							<input type="hidden" name="pid" value="<?php echo $pid;?>">
								<select name="eye" id="eye" class="form-control" required>
							<option value="">----Select Eye----</option>
							<?php
							 $seleye=mysqli_query($db,"select distinct eye from prescription_analysis where eye!=''");
							 while($roweye=mysqli_fetch_array($seleye))
							 {
							?>
							<option><?php echo $roweye["eye"];?></option>
							<?php
							 }
							 ?>
							 </select>
							 <select name="diagnosis" class="form-control" required>
							<option value="">----Select Diagnosis----</option>
							<?php
							 $seldiagnosis=mysqli_query($db,"select distinct diagnosis from prescription_analysis where diagnosis!=''");
							 while($rowdiagnosis=mysqli_fetch_array($seldiagnosis))
							 {
							?>
							<option><?php echo $rowdiagnosis["diagnosis"];?></option>
							<?php
							 }
							 ?>
							 </select>
							
							 <input type="submit" name="submit" id="submit" class="btn btn-primary" value="Add">
							</div>
					</form>
					<?php
					  if(isset($_POST["submit"]))
					  {
						  $eye=mysqli_real_escape_string($db,$_POST['eye']);
						  $diagnosis=mysqli_real_escape_string($db,$_POST['diagnosis']);
						  $apid=mysqli_real_escape_string($db,$_POST['apid']); // appointments id
						  $pid=mysqli_real_escape_string($db,$_POST['pid']); // patient id
						  $insdate=date("Y-m-d");
					  $inssql=mysqli_query($db,"insert into diagnosis_temp values('','$pid','$apid','$eye','$diagnosis','$insdate')");
					  if($inssql)
					  {
						  //select duplicate rows
								  $seldup=mysqli_query($db,"select eye, count(eye), diagnosis, count(diagnosis) from diagnosis_temp group by eye, diagnosis having count(eye)>1 and count(diagnosis)>1");
								  if(mysqli_num_rows($seldup)>0)
								  {
						   //delete duplicate rows
								  $delsql=mysqli_query($db,"delete t1 from diagnosis_temp t1 inner join diagnosis_temp t2 where t1.id>t2.id and t1.eye=t2.eye and t1.diagnosis=t2.diagnosis");
								  if($delsql)
								  {
									  echo "<script> alert('Duplicate entry found!') </script>";
								  }
								  }
						  echo "<script> window.location.href='diagnosis_temp.php?apid=$apid' </script>";
					  }
					  }
					?>
			</div>
				<table id = "table" class = "display" width = "100%" cellspacing = "0">
					<thead>
						<tr>
							<th>Eye</th>
							<th>Diagnosis</th>
							<th><center>Action</center></th>
						</tr>
					</thead>
					<tbody>
					<?php
						$query = mysqli_query($db,"SELECT * FROM `diagnosis_temp` where pid='$pid' and apid='".$_GET['apid']."'") or die(mysqli_error());
						while($fetchdg = mysqli_fetch_array($query)){
						$id = $fetchdg['id'];
						$eye=$fetchdg['eye'];
						$diagnosis=$fetchdg['diagnosis'];
					?>
						<tr>
							<td><?php echo $eye;?></td>				
							<td><?php echo $diagnosis;?></td>	
							<td><center>
							<a href = "delete_diagnosis.php?id=<?php echo $id;?>" class = "btn btn-sm btn-danger"><span class = "glyphicon glyphicon-trash"></span> Delete</a>
							</center></td>
						</tr>
					<?php
						}
						$conn->close();
					?>
					</tbody>
					</table>
		</div>	
	<div id = "footer">
		<label class = "footer-title">&copy; Copyright EyeCare 2022</label>
	</div>
<?php require'script.php' ?>
<script type = "text/javascript">
    $(document).ready(function() {
		$("#submit").attr("disabled",true);
        function disableBack() { window.history.forward() }

        window.onload = disableBack();
        window.onpageshow = function(evt) { if (evt.persisted) disableBack() }
	});
</script>
<script type = "text/javascript">
$("#eye").change(function(){
	$("#submit").attr("disabled",false);
})
</script>
</body>
</html>