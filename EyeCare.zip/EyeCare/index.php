<!DOCTYPE html>
<html lang = "eng">
	<head>
		<title>EyeCare</title>
		<meta charset = "utf-8" />
		<link rel = "shortcut icon" href = "images/eye-gb51ecb13e_1280.PNG">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/customize.css" />
	</head>
<body style="background-image: url('images/background.JPG');">
	<div class = "navbar navbar-default navtop">
		<img src = "images/eye-gb51ecb13e_1280.PNG" style = "float:left;" height = "55px" /><label class = "navbar-brand">EyeCare</label>
	</div>
		<div id = "sidelogin">
			<form action = "login.php" enctype = "multipart/form-data" method = "POST" >
				<label class = "lbllogin">Please Login Here...</label>
				<hr /style = "border:1px dotted #000;">
				<div class = "form-group">
					<label for = "username">Username</label>
					<input class = "form-control" type = "text" name = "username"  required = "required"/>
				</div>
				<br />
				<div class = "form-group">
					<label for = "password">Password</label>
					<input class = "form-control" type = "password" name = "password" required = "required" />
				</div>
				<div class = "form-group">
					<label for = "role">Role</label>
					<select name="role" class="form-control" required = "required" />
					 <option value="">---Select Role---</option>
					 <option value="Doctor">Doctor</option>
					 <option value="Receptionist">Receptionist</option>
					 <option value="Admin">Admin</option>
					</select>
				</div>
				<div class = "form-group">
					<button class  = "btn btn-success form-control" type = "submit" name = "login" ><span class = "glyphicon glyphicon-log-in"></span> Login</button>
				</div>
			</form>
		</div>	
		<!--<img src = "images/victorias.jpg" class = "background">-->			
	<div id = "footer">
		<label class = "footer-title">&copy; Copyright EyeCare 2022</label>
	</div>
</body>
<?php
	include("script.php");
?>
</html>