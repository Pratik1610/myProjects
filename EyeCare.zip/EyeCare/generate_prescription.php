<?php
include "authentication.php";
date_default_timezone_set("Asia/Kolkata");
$apid=$_GET["apid"]; // Appointment Id
$pid=$_GET["pid"];  // Patient ID
$cur=date("Y-m-d");
$ref=$_SERVER["HTTP_REFERER"];
// Select data from temporary tables
$sel1=mysqli_query($db,"select * from advice_temp where apid='$apid' and ins_date='$cur'");
$sel2=mysqli_query($db,"select * from co_temp where apid='$apid' and ins_date='$cur'");
$sel3=mysqli_query($db,"select * from diagnosis_temp where apid='$apid' and ins_date='$cur'");
$sel4=mysqli_query($db,"select * from examination_temp where apid='$apid' and ins_date='$cur'");
$sel5=mysqli_query($db,"select * from followup_temp where apid='$apid' and ins_date='$cur'");
$sel6=mysqli_query($db,"select * from glasses_temp where apid='$apid' and ins_date='$cur'");
$sel7=mysqli_query($db,"select * from review_temp where apid='$apid' and ins_date='$cur'");
$sel8=mysqli_query($db,"select * from rx_temp where apid='$apid' and ins_date='$cur'");

// select pateint basic information
$selp=mysqli_query($db,"select * from itr where patient_id='$pid'");
$rowp=mysqli_fetch_array($selp);

// select pateint appointments information
$selap=mysqli_query($db,"select * from appointments where id='$apid'");
$rowap=mysqli_fetch_array($selap);

// fetch data from temprary tables
$fetch1=mysqli_fetch_array($sel1);
$fetch4=mysqli_fetch_array($sel4);
$fetch5=mysqli_fetch_array($sel5);
$fetch6=mysqli_fetch_array($sel6);
$fetch7=mysqli_fetch_array($sel7);

if(mysqli_num_rows($sel1)>0&&mysqli_num_rows($sel2)>0&&mysqli_num_rows($sel3)>0&&mysqli_num_rows($sel4)>0&&mysqli_num_rows($sel5)>0&&mysqli_num_rows($sel6)>0&&mysqli_num_rows($sel7)>0&&mysqli_num_rows($sel8)>0)
{
	$address="";
	if(!empty($rowp["house"]))
	{
	$address.=$rowp["house"];
	}
	elseif(!empty($rowp["street"]))
	{
		$address.=$rowp["street"];
	}
	elseif(!empty($rowp["locality"]))
	{
		$address.=$rowp["locality"];
	}
	elseif(!empty($rowp["city"]))
	{
		$address.=", ".$rowp["city"];
	}
	elseif(!empty($rowp["state"]))
	{
		$address.=$rowp["state"];
	}
		elseif(!empty($rowp["pin"]))
	{
		$address.=$rowp["pin"];
	}
	
	$co="";
	$eye="";
	$diagnosis="";
	$drug="";
	$frequency="";
	$duration="";
	$deye="";
	while($fetch2=mysqli_fetch_array($sel2))
	{
		$co.=mysqli_real_escape_string($db,$fetch2["co"])."  ".mysqli_real_escape_string($db,$fetch2["eye"])."  ".mysqli_real_escape_string($db,$fetch2["duration"])."  ".mysqli_real_escape_string($db,$fetch2["note"])."<br>";
	}
	while($fetch3=mysqli_fetch_array($sel3))
	{
		$eye.=mysqli_real_escape_string($db,$fetch3["eye"])."<br>";
		$diagnosis.=mysqli_real_escape_string($db,$fetch3["diagnosis"])."<br>";
	}
	while($fetch8=mysqli_fetch_array($sel8))
	{
		$drug.=mysqli_real_escape_string($db,$fetch8["drug"])."<br>";
		$frequency.=mysqli_real_escape_string($db,$fetch8["frequency"])."<br>";
		$duration.=mysqli_real_escape_string($db,$fetch8["duration"])."<br>";
		$deye.=mysqli_real_escape_string($db,$fetch8["eye"])."<br>";
	}
	// check whether prescription is already created for the same date of appointment
	$chkpres=mysqli_query($db,"select * from prescriptions where appointment_id='$apid' and pres_date='$cur'");
	if(mysqli_num_rows($chkpres)>0)
	{
		echo "<script> alert('Presscription is already created for this date of appointment!') </script>";
		echo "<script> window.location.href='home.php' </script>";
	}
	else
	{
	$inssql1=mysqli_query($db,"INSERT INTO `prescriptions`(`id`, `patient_id`, `patient_name`, `appointment_id`, `co`, `age`, `gender`, `pres_date`, `contact_num`, `address`, `eye`, `diagnosis`, `drug`, `freq`, `duration`, `diagnosis_eye`, `uppersec`, `od_unaided`, `od_old_spectacles`, `od_ph_ss`, `os_unaided`, `os_old_spectacles`, `os_ph_ss`,`od_pr`, `os_pr`, `od_sph`, `od_cyl`, `od_axis`, `od_va`, `od_comment`, `od_add`,`od_nva`, `os_sph`, `os_cyl`, `os_axis`, `os_va`, `os_comment`, `os_add`, `os_nva`, `ipd`, `head_posture`, `od_forehead`, `od_orbit`, `od_eye_brows`, `od_eye_lids`, `od_position_eyelids`, `od_skin_eyelids`, `od_margins_eyelids`, `od_lacrimal_app`, `od_eye_ball`, `od_moments_eyeball`, `od_conjunctiva`, `od_pulpebral_conjunctiva`, `od_bulbar_conjunctiva`, `od_size_cornea`, `od_surface_cornea`, `od_transparency_cornea`, `od_stroma_cornea`, `od_endothelium_cornea`, `od_ac_contant`, `od_ac_depth`, `od_iris_colour`, `od_iris_pattern`, `od_pupil_size`, `od_pupil_shape`, `od_pupil_reaction`,`od_lens`, `od_lens_opacity`, `od_iop`, `od_media`, `od_optic_disc`, `od_optic_disc_size`, `od_optic_disc_shape`, `od_optic_disc_colour`, `od_optic_disc_margine`, `od_cd_ratio`, `od_bv_over_disc`, `od_bv_over_gf`, `od_macula`, `od_gf`, `od_syringing`, `od_shirmers_test`, `od_gonioscopy`, `od_photograph_num`, `advice`, `folowup_date`, `followup_note`, `other_note`, `os_forehead`, `os_orbit`, `os_eye_brows`, `os_eye_lids`, `os_position_eyelids`, `os_skin_eyelids`, `os_margins_eyelids`, `os_lacrimal_app`, `os_eye_ball`, `os_moments_eyeball`, `os_conjunctiva`, `os_pulpebral_conjunctiva`, `os_bulbar_conjunctiva`, `os_size_cornea`, `os_surface_cornea`, `os_transparency_cornea`, `os_stroma_cornea`, `os_endothelium_cornea`, `os_ac_contant`, `os_ac_depth`, `os_iris_colour`, `os_iris_pattern`, `os_pupil_size`, `os_pupil_shape`, `os_pupil_reaction`,`os_lens`, `os_lens_opacity`, `os_iop`, `os_media`, `os_optic_disc`, `os_optic_disc_size`, `os_optic_disc_shape`, `os_optic_disc_colour`, `os_optic_disc_margine`, `os_cd_ratio`, `os_bv_over_disc`, `os_bv_over_gf`, `os_macula`, `os_gf`, `os_syringing`, `os_shirmers_test`, `os_gonioscopy`, `os_photograph_num`, `review_after`,`od_fundus`, `os_fundus`) VALUES ('','".$rowp["patient_id"]."','".mysqli_real_escape_string($db,$rowap["patient_name"])."','".$rowap['id']."','".mysqli_real_escape_string($db,$co)."','".mysqli_real_escape_string($db,$rowp['age'])."','".mysqli_real_escape_string($db,$rowp['gender'])."','".mysqli_real_escape_string($db,$cur)."','".mysqli_real_escape_string($db,$rowp['contact'])."','".mysqli_real_escape_string($db,$address)."','".mysqli_real_escape_string($db,$eye)."','".mysqli_real_escape_string($db,$diagnosis)."','".mysqli_real_escape_string($db,$drug)."','".mysqli_real_escape_string($db,$frequency)."','".mysqli_real_escape_string($db,$duration)."','".mysqli_real_escape_string($db,$deye)."','".mysqli_real_escape_string($db,$fetch4["uppersec"])."','".mysqli_real_escape_string($db,$fetch4["od_unaided"])."','".mysqli_real_escape_string($db,$fetch4["od_old_spectacles"])."','".mysqli_real_escape_string($db,$fetch4["od_ph_ss"])."','".mysqli_real_escape_string($db,$fetch4["os_unaided"])."','".mysqli_real_escape_string($db,$fetch4["os_old_spectacles"])."','".mysqli_real_escape_string($db,$fetch4["os_ph_ss"])."','".mysqli_real_escape_string($db,$fetch4["od_pr"])."','".mysqli_real_escape_string($db,$fetch4["os_pr"])."','".mysqli_real_escape_string($db,$fetch4["od_sph"])."','".mysqli_real_escape_string($db,$fetch4["od_cyl"])."','".mysqli_real_escape_string($db,$fetch4["od_axis"])."','".mysqli_real_escape_string($db,$fetch4["od_va"])."','".mysqli_real_escape_string($db,$fetch4["od_comment"])."','".mysqli_real_escape_string($db,$fetch4["od_add"])."','".mysqli_real_escape_string($db,$fetch4["od_nva"])."','".mysqli_real_escape_string($db,$fetch4["os_sph"])."','".mysqli_real_escape_string($db,$fetch4["os_cyl"])."','".mysqli_real_escape_string($db,$fetch4["os_axis"])."','".mysqli_real_escape_string($db,$fetch4["os_va"])."','".mysqli_real_escape_string($db,$fetch4["os_comment"])."','".mysqli_real_escape_string($db,$fetch4["os_add"])."','".mysqli_real_escape_string($db,$fetch4["os_nva"])."','".mysqli_real_escape_string($db,$fetch4["ipd"])."','".mysqli_real_escape_string($db,$fetch4["head_posture"])."','".mysqli_real_escape_string($db,$fetch4["od_forehead"])."','".mysqli_real_escape_string($db,$fetch4["od_orbit"])."','".mysqli_real_escape_string($db,$fetch4["od_eye_brows"])."','".mysqli_real_escape_string($db,$fetch4["od_eye_lids"])."','".mysqli_real_escape_string($db,$fetch4["od_position_eyelids"])."','".mysqli_real_escape_string($db,$fetch4["od_skin_eyelids"])."','".mysqli_real_escape_string($db,$fetch4["od_margins_eyelids"])."','".mysqli_real_escape_string($db,$fetch4["od_lacrimal_app"])."','".mysqli_real_escape_string($db,$fetch4["od_eye_ball"])."','".mysqli_real_escape_string($db,$fetch4["od_moments_eyeball"])."','".mysqli_real_escape_string($db,$fetch4["od_conjunctiva"])."','".mysqli_real_escape_string($db,$fetch4["od_pulpebral_conjunctiva"])."','".mysqli_real_escape_string($db,$fetch4["od_bulbar_conjunctiva"])."','".mysqli_real_escape_string($db,$fetch4["od_size_cornea"])."','".mysqli_real_escape_string($db,$fetch4["od_surface_cornea"])."','".mysqli_real_escape_string($db,$fetch4["od_transparency_cornea"])."','".mysqli_real_escape_string($db,$fetch4["od_stroma_cornea"])."','".mysqli_real_escape_string($db,$fetch4["od_endothelium_cornea"])."','".mysqli_real_escape_string($db,$fetch4["od_ac_contant"])."','".mysqli_real_escape_string($db,$fetch4["od_ac_depth"])."','".mysqli_real_escape_string($db,$fetch4["od_iris_colour"])."','".mysqli_real_escape_string($db,$fetch4["od_iris_pattern"])."','".mysqli_real_escape_string($db,$fetch4["od_pupil_size"])."','".mysqli_real_escape_string($db,$fetch4["od_pupil_shape"])."','".mysqli_real_escape_string($db,$fetch4["od_pupil_reaction"])."','".mysqli_real_escape_string($db,$fetch4["od_lens"])."','".mysqli_real_escape_string($db,$fetch4["od_lens_opacity"])."','".mysqli_real_escape_string($db,$fetch4["od_iop"])."','".mysqli_real_escape_string($db,$fetch4["od_media"])."','".mysqli_real_escape_string($db,$fetch4["od_optic_disc"])."','".mysqli_real_escape_string($db,$fetch4["od_optic_disc_size"])."','".mysqli_real_escape_string($db,$fetch4["od_optic_disc_shape"])."','".mysqli_real_escape_string($db,$fetch4["od_optic_disc_colour"])."','".mysqli_real_escape_string($db,$fetch4["od_optic_disc_margine"])."','".mysqli_real_escape_string($db,$fetch4["od_cd_ratio"])."','".mysqli_real_escape_string($db,$fetch4["od_bv_over_disc"])."','".mysqli_real_escape_string($db,$fetch4["od_bv_over_gf"])."','".mysqli_real_escape_string($db,$fetch4["od_macula"])."','".mysqli_real_escape_string($db,$fetch4["od_gf"])."','".mysqli_real_escape_string($db,$fetch4["od_syringing"])."','".mysqli_real_escape_string($db,$fetch4["od_shirmers_test"])."','".mysqli_real_escape_string($db,$fetch4["od_gonioscopy"])."','".mysqli_real_escape_string($db,$fetch4["od_photograph_num"])."','".mysqli_real_escape_string($db,$fetch1["advice"])."','".mysqli_real_escape_string($db,$fetch5["followup_date"])."','".mysqli_real_escape_string($db,$fetch5["followup_note"])."','','".mysqli_real_escape_string($db,$fetch4["os_forehead"])."','".mysqli_real_escape_string($db,$fetch4["os_orbit"])."','".mysqli_real_escape_string($db,$fetch4["os_eye_brows"])."','".mysqli_real_escape_string($db,$fetch4["os_eye_lids"])."','".mysqli_real_escape_string($db,$fetch4["os_position_eyelids"])."','".mysqli_real_escape_string($db,$fetch4["os_skin_eyelids"])."','".mysqli_real_escape_string($db,$fetch4["os_margins_eyelids"])."','".mysqli_real_escape_string($db,$fetch4["os_lacrimal_app"])."','".mysqli_real_escape_string($db,$fetch4["os_eye_ball"])."','".mysqli_real_escape_string($db,$fetch4["os_moments_eyeball"])."','".mysqli_real_escape_string($db,$fetch4["os_conjunctiva"])."','".mysqli_real_escape_string($db,$fetch4["os_pulpebral_conjunctiva"])."','".mysqli_real_escape_string($db,$fetch4["os_bulbar_conjunctiva"])."','".mysqli_real_escape_string($db,$fetch4["os_size_cornea"])."','".mysqli_real_escape_string($db,$fetch4["os_surface_cornea"])."','".mysqli_real_escape_string($db,$fetch4["os_transparency_cornea"])."','".mysqli_real_escape_string($db,$fetch4["os_stroma_cornea"])."','".mysqli_real_escape_string($db,$fetch4["os_endothelium_cornea"])."','".mysqli_real_escape_string($db,$fetch4["os_ac_contant"])."','".mysqli_real_escape_string($db,$fetch4["os_ac_depth"])."','".mysqli_real_escape_string($db,$fetch4["os_iris_colour"])."','".mysqli_real_escape_string($db,$fetch4["os_iris_pattern"])."','".mysqli_real_escape_string($db,$fetch4["os_pupil_size"])."','".mysqli_real_escape_string($db,$fetch4["os_pupil_shape"])."','".mysqli_real_escape_string($db,$fetch4["os_pupil_reaction"])."','".mysqli_real_escape_string($db,$fetch4["os_lens"])."','".mysqli_real_escape_string($db,$fetch4["os_lens_opacity"])."','".mysqli_real_escape_string($db,$fetch4["os_iop"])."','".mysqli_real_escape_string($db,$fetch4["os_media"])."','".mysqli_real_escape_string($db,$fetch4["os_optic_disc"])."','".mysqli_real_escape_string($db,$fetch4["os_optic_disc_size"])."','".mysqli_real_escape_string($db,$fetch4["os_optic_disc_shape"])."','".mysqli_real_escape_string($db,$fetch4["os_optic_disc_colour"])."','".mysqli_real_escape_string($db,$fetch4["os_optic_disc_margine"])."','".mysqli_real_escape_string($db,$fetch4["os_cd_ratio"])."','".mysqli_real_escape_string($db,$fetch4["os_bv_over_disc"])."','".mysqli_real_escape_string($db,$fetch4["os_bv_over_gf"])."','".mysqli_real_escape_string($db,$fetch4["os_macula"])."','".mysqli_real_escape_string($db,$fetch4["os_gf"])."','".mysqli_real_escape_string($db,$fetch4["os_syringing"])."','".mysqli_real_escape_string($db,$fetch4["os_shirmers_test"])."','".mysqli_real_escape_string($db,$fetch4["os_gonioscopy"])."','".mysqli_real_escape_string($db,$fetch4["os_photograph_num"])."','".mysqli_real_escape_string($db,$fetch7["duration"])."','".mysqli_real_escape_string($db,$fetch4["od_fundus"])."','".mysqli_real_escape_string($db,$fetch4["os_fundus"])."')");
	$inssql2=mysqli_query($db,"INSERT INTO `glasses`(`id`, `patient_id`, `patient_name`, `appointment_id`, `re_sph`, `re_cyl`, `re_axis`, `re_va`, `le_sph`, `le_cyl`, `le_axis`, `le_va`, `re_add`, `re_nva`, `le_add`, `le_nva`, `ipd`, `colour`, `focal`, `vd`, `ins_date`) VALUES ('','".mysqli_real_escape_string($db,$rowap["pid"])."','".mysqli_real_escape_string($db,$rowap["patient_name"])."','".mysqli_real_escape_string($db,$rowap["id"])."','".mysqli_real_escape_string($db,$fetch6["re_sph"])."','".mysqli_real_escape_string($db,$fetch6["re_cyl"])."','".mysqli_real_escape_string($db,$fetch6["re_axis"])."','".mysqli_real_escape_string($db,$fetch6["re_va"])."','".mysqli_real_escape_string($db,$fetch6["le_sph"])."','".mysqli_real_escape_string($db,$fetch6["le_cyl"])."','".mysqli_real_escape_string($db,$fetch6["le_axis"])."','".mysqli_real_escape_string($db,$fetch6["le_va"])."','".mysqli_real_escape_string($db,$fetch6["re_add"])."','".mysqli_real_escape_string($db,$fetch6["re_nva"])."','".mysqli_real_escape_string($db,$fetch6["le_add"])."','".mysqli_real_escape_string($db,$fetch6["le_nva"])."','".mysqli_real_escape_string($db,$fetch6["ipd"])."','".mysqli_real_escape_string($db,$fetch6["colour"])."','".mysqli_real_escape_string($db,$fetch6["focal"])."','".mysqli_real_escape_string($db,$fetch6["vd"])."','$cur')");
	$inssql3=mysqli_query($db,"INSERT INTO `patients_visits`(`id`, `patient_name`, `patient_id`, `appointment_id`, `visit_date`) VALUES ('','".mysqli_real_escape_string($db,$rowap["patient_name"])."','".mysqli_real_escape_string($db,$rowap["pid"])."','".mysqli_real_escape_string($db,$rowap["id"])."','".mysqli_real_escape_string($db,$cur)."')");
	}
	// Delete data from temporary tables
	$del1=mysqli_query($db,"delete from advice_temp");
	$del2=mysqli_query($db,"delete from co_temp");
	$del3=mysqli_query($db,"delete from diagnosis_temp");
	$del4=mysqli_query($db,"delete from examination_temp");
	$del5=mysqli_query($db,"delete from followup_temp");
	$del6=mysqli_query($db,"delete from glasses_temp");
	$del7=mysqli_query($db,"delete from review_temp");
	$del8=mysqli_query($db,"delete from rx_temp");
	 echo "<script> alert('Presscription Generated Successfully!') </script>";
	 echo "<script> window.location.href='prescription.php?apid=$apid&pid=$pid' </script>";
}
else
{
	echo "<script> alert('Please complete your prescription. Some fields are missing!') </script>";
	echo "<script> window.location.href='$ref' </script>";
}
?>