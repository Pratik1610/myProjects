<!DOCTYPE html>
<?php
	require_once 'logincheck.php';
	require_once 'authentication.php';
	
	date_default_timezone_set("Asia/Kolkata");
	
	@$pid=$_GET["pid"]; // patient id
	
	
	$query = mysqli_query($db,"SELECT * FROM `itr` WHERE patient_id='$pid'") or die(mysqli_error());
	$fetch = mysqli_fetch_array($query);
	
	@$fname=!empty($fetch["firstname"])?$fetch["firstname"]." ":"";
	@$mname=!empty($fetch["middlename"])?$fetch["middlename"]." ":"";
	@$lname=!empty($fetch["lastname"])?$fetch["lastname"]:"";
	
	$time=date("h:i");
	$newtime=strtotime("+15 minutes",strtotime($time));
?>
<html lang = "eng">
	<head>
		<title>EyeCare</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "shortcut icon" href = "../images/eye-gb51ecb13e_1280.PNG" />
		<link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/customize.css" />
	</head>
<body>
	<div class = "navbar navbar-default navbar-fixed-top">
		<img src = "../images/eye-gb51ecb13e_1280.PNG" style = "float:left;" height = "55px" /><label class = "navbar-brand">EyeCare</label>
			<?php
				$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
				$q = $conn->query("SELECT * FROM `admin` WHERE `admin_id` = '$_SESSION[admin_id]'") or die(mysqli_error());
				$f = $q->fetch_array();
			?>
			<ul class = "nav navbar-right">	
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#">
						<span class = "glyphicon glyphicon-user"></span>
						<?php
							echo $f['firstname']." ".$f['middlename']." ".$f['lastname'];
							$conn->close();
						?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
					<li>
						<a class = "me" href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
	</div>
		<br />
		<br />
		<br />
		<div class = "panel panel-success">	
			<div class = "panel-heading">
				<label>&nbsp;PATIENT INFORMATION / Book an Appointment</label>
				<a style = "float:left; margin-top:-4px;" href = "patient.php" class = "btn btn-info"><span class = "glyphicon glyphicon-hand-left"></span> BACK</a>
			</div>
			<div class = "panel-body">
					<form action="" method="post">
							   <div class="row">
							     <div class="col-lg-6">
									<div class="form-group">
									  <label>Date</label>
									  <input type="date" name="aptdate" class="form-control" value="<?php echo date("Y-m-d");?>" required>
									</div>
									
									<div class="form-group">
									  <label>Patient Name</label>
									 <input type="text" name="pname" class="form-control" placeholder="Patient Name" value="<?php echo ucfirst($fname).ucfirst($mname).ucfirst($lname);?>" readonly>
									 <input type="hidden" name="pid" class="form-control" value="<?php echo $fetch["patient_id"];?>" required>
									</div>
									
								 </div>
								 
								 <div class="col-lg-6">
									<div class="form-group">
									  <label>Time</label>
									  <div class="row">
									   <div class="col-lg-6">
									   <input type="time" name="aptime"  pattern="^([0-1][0-9]|2[0-3]):[0-5][0-9]$" class="form-control" placeholder="hh:mm" value="<?php echo date("h:i",$newtime);?>" required>
									   </div>
									  </div>
									</div>
									</div>
							   </div>
							   <input type="submit" name="submit" class="btn btn-primary" value="Save">
							</form>
							
							<?php
							  if(isset($_POST["submit"]))
							  {
								  $app_date=$_POST['aptdate'];
								  $cur=date("m/d/Y");
								  $curtm=date("h:ia");
								  $aptime=date("h:i A",strtotime($_POST["aptime"]));
								  
								  // check whether the appoinntment booked for same time
								  $chksql=mysqli_query($db,"select time from appointments where time='$aptime' and app_date='$app_date'");
								  if(mysqli_num_rows($chksql)==0)
								  {
									  if(strtotime($app_date)>=strtotime($cur)&&strtotime($curtm)<=strtotime($aptime))
									  {
										  $inssql=mysqli_query($db,"INSERT INTO appointments(`id`,`app_date`,`time`,`patient_name`,`pid`) VALUES('','$app_date','$aptime','".$_POST['pname']."','".$_POST['pid']."')") or die(mysqli_error($db));
										  if($inssql)
										  {
											  echo "<script> alert('Appointment Booked!') </script>";
											  echo "<script> window.location.href='home.php'</script>";
										  }
									  }
									  else
									  {
									  echo "<script> alert('You can not make an appointment for past date or time!') </script>";
									  echo "<script> window.location.href='home.php'</script>";
									  }
								  }
								  else
								  {
									  echo "<script> alert('Appointment slot has already booked!') </script>";
									  echo "<script> window.location.href='home.php'</script>";
								  }
							  }
							?>
			</div>	
		</div>	
	<div id = "footer">
		<label class = "footer-title">&copy; Copyright EyeCare 2022</label>
	</div>
<?php include("script.php"); ?>
<script type = "text/javascript">
    $(document).ready(function() {
        function disableBack() { window.history.forward() }

        window.onload = disableBack();
        window.onpageshow = function(evt) { if (evt.persisted) disableBack() }
    });
</script>	
<script>
function selcategory(){
	var e = document.getElementById("category");
	var catval = e.options[e.selectedIndex].text;
	document.getElementById("title").value = catval;
}
</script>

</body>
</html>