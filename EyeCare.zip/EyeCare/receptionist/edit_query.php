<?php
	$id = $_GET['id'];
	$last = $_GET['lastname'];
	if(ISSET($_POST['edit_patient'])){
		$firstname = $_POST['firstname'];
		$middlename = $_POST['middlename'];
		$lastname = $_POST['lastname'];
		$birthdate = date("m/d/Y",strtotime($_POST['bdate']));
		$bday=date("Y-m-d",strtotime($birthdate));
		$from= new DateTime($bday);
		$to= new DateTime('today');
		$age=$from->diff($to)->y;
		$house = $_POST['house'];
		$street = $_POST['street'];
		$contact = $_POST['contact'];
		$locality = $_POST['locality'];
		$city = $_POST['city'];
		$state = $_POST['state'];
		$gender = $_POST['gender'];
		$pin = $_POST['pin'];
		$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
		$conn->query("UPDATE `itr` SET `firstname` = '$firstname', `middlename` = '$middlename', `lastname` = '$lastname', `birthdate` = '$birthdate', `age` = '$age',`gender` = '$gender', `house`='$house', `street`='$street', `locality`='$locality', `city`='$city', `state`='$state', `pin`='$pin', `contact`='$contact' WHERE `patient_id` = '$id' && `lastname` = '$last'") or die(mysqli_error());
		echo "<script> alert('Edited Successfully!') </script>";
		echo "<script> window.location.href='patient.php' </script>";
	}
	if(ISSET($_POST['edit_admin'])){
			$username = $_POST['username'];
			$password = $_POST['password'];
			$firstname = $_POST['firstname'];
			$middlename = $_POST['middlename'];
			$lastname = $_POST['lastname'];
			$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
			$conn->query("UPDATE `admin` SET `username` = '$username', `password` = '$password', `firstname` = '$firstname', `middlename` = '$middlename', `lastname` = '$lastname' WHERE `admin_id` = '$id'") or die(mysqli_error());
			header("location: admin.php");
		}
	if(ISSET($_POST['edit_user'])){
			$username = $_POST['username'];
			$password = $_POST['password'];
			$firstname = $_POST['firstname'];
			$middlename = $_POST['middlename'];
			$lastname = $_POST['lastname'];
			$section = $_POST['section'];
			$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
			$conn->query("UPDATE `user` SET `username` = '$username', `password` = '$password', `firstname` = '$firstname', `middlename` = '$middlename', `lastname` = '$lastname', `section` = '$section' WHERE `user_id` = '$id'") or die(mysqli_error());
			header("location: user.php");
		}	
