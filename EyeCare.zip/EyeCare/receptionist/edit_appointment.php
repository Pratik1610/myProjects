<!DOCTYPE html>
<?php
	require_once 'logincheck.php';
	require_once 'authentication.php';
	
	date_default_timezone_set("Asia/Kolkata");
	
	@$apid=$_GET["apid"]; // patient id
	
	
	$query = mysqli_query($db,"SELECT * FROM `appointments` WHERE id='$apid'") or die(mysqli_error());
	$fetch = mysqli_fetch_array($query);
	
	
?>
<html lang = "eng">
	<head>
		<title>EyeCare</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "shortcut icon" href = "../images/eye-gb51ecb13e_1280.PNG" />
		<link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/customize.css" />
	</head>
<body>
	<div class = "navbar navbar-default navbar-fixed-top">
		<img src = "../images/eye-gb51ecb13e_1280.PNG" style = "float:left;" height = "55px" /><label class = "navbar-brand">EyeCare</label>
			<?php
				$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
				$q = $conn->query("SELECT * FROM `admin` WHERE `admin_id` = '$_SESSION[admin_id]'") or die(mysqli_error());
				$f = $q->fetch_array();
			?>
			<ul class = "nav navbar-right">	
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#">
						<span class = "glyphicon glyphicon-user"></span>
						<?php
							echo $f['firstname']." ".$f["middlename"]." ".$f['lastname'];
							$conn->close();
						?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
					<li>
						<a class = "me" href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
	</div>
		<br />
		<br />
		<br />
		<div class = "panel panel-success">	
			<div class = "panel-heading">
				<label>&nbsp;PATIENT Appointment
				/ Edit Appointment</label>
				<a style = "float:left; margin-top:-4px;" href = "patient.php" class = "btn btn-info"><span class = "glyphicon glyphicon-hand-left"></span> BACK</a>
			</div>
			<div class = "panel-body">
					<form action="" method="post">
							   <div class="row">
							     <div class="col-lg-6">
									<div class="form-group">
									  <label>Date</label>
									  <input type="date" name="aptdate" class="form-control" value="<?php echo date("Y-m-d",strtotime($fetch["app_date"]));?>" required>
									</div>
									
									<div class="form-group">
									  <label>Patient</label>
									 <input type="text" name="pname" class="form-control" placeholder="Patient Name" value="<?php echo $fetch["patient_name"];?>" readonly>
									 <input type="hidden" name="pid" class="form-control" value="<?php echo $fetch["pid"];?>" required>
									</div>
									
								 </div>
								 
								 <div class="col-lg-6">
									<div class="form-group">
									  <label>Time</label>
									  <?php
									  $tm=explode(" ",$fetch["time"]);
									  ?>
									  <div class="row">
									   <div class="col-lg-6">
									   <input type="time" name="aptime" pattern="^([0-1][0-9]|2[0-3]):[0-5][0-9]$" class="form-control" placeholder="hh:mm" value="<?php echo $tm[0];?>" required>
										</div>
									  </div><br>
									  
									</div>
									</div>
							   </div>
							   <input type="submit" name="submit" class="btn btn-primary" value="Save">
							</form>
							
							<?php
							  if(isset($_POST["submit"]))
							  {
								  $date=date("Y-m-d",strtotime($_POST["aptdate"]));
								  
								  $app_date=date("m/d/Y",strtotime($_POST["aptdate"]));
								  
								  $cur=date("m/d/Y");
								  $curtm=date("h:ia");
								  $aptime=date("h:i A",strtotime($_POST["aptime"]));
								  
								  // check whether the appoinntment booked for same time
								  $chksql=mysqli_query($db,"select time from appointments where time='$aptime' and app_date='$date'");
								  if(mysqli_num_rows($chksql)==0)
								  {
									  if(strtotime($app_date)>=strtotime($cur)&&strtotime($curtm)<=strtotime($aptime))
									 {
									   $updsql=mysqli_query($db,"update appointments set app_date='$date',time='$aptime',patient_name='".$_POST["pname"]."',pid='".$_POST["pid"]."' where id='$apid'") or die(mysqli_error($db));
									  if($updsql)
									  {
										  echo "<script> alert('Appointment Updated!') </script>";
										  echo "<script> window.location.href='home.php'</script>";
									  }
									 }
									 else
									 {
									  echo "<script> alert('You can not make an appointment for past date or time!') </script>";
									  echo "<script> window.location.href='home.php'</script>";
									 }
								  }
								  else
								  {
									  echo "<script> alert('Appointment slot has already booked!') </script>";
									  echo "<script> window.location.href='home.php'</script>";
								  }
							  }
							?>
			</div>	
		</div>	
	<div id = "footer">
		<label class = "footer-title">&copy; Copyright EyeCare 2022</label>
	</div>
<?php include("script.php"); ?>
<script type = "text/javascript">
    $(document).ready(function() {
        function disableBack() { window.history.forward() }

        window.onload = disableBack();
        window.onpageshow = function(evt) { if (evt.persisted) disableBack() }
    });
</script>	
</body>
</html>