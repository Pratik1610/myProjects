<?php
//get all appointments data for current date
$sel1sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='08:00 AM'");
$sel1row=mysqli_fetch_array($sel1sql);

$sel2sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='08:15 AM'");
$sel2row=mysqli_fetch_array($sel2sql);

$sel3sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='08:30 AM'");
$sel3row=mysqli_fetch_array($sel3sql);

$sel4sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='08:45 AM'");
$sel4row=mysqli_fetch_array($sel4sql);

$sel5sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='09:00 AM'");
$sel5row=mysqli_fetch_array($sel1sql);

$sel6sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='09:15 AM'");
$sel6row=mysqli_fetch_array($sel6sql);

$sel6sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='09:30 AM'");
$sel6row=mysqli_fetch_array($sel6sql);

$sel7sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='09:45 AM'");
$sel7row=mysqli_fetch_array($sel7sql);

$sel8sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='10:00 AM'");
$sel8row=mysqli_fetch_array($sel8sql);

$sel9sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='10:15 AM'");
$sel9row=mysqli_fetch_array($sel9sql);

$sel10sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='10:30 AM'");
$sel10row=mysqli_fetch_array($sel10sql);

$sel11sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='10:45 AM'");
$sel11row=mysqli_fetch_array($sel11sql);

$sel12sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='11:00 AM'");
$sel12row=mysqli_fetch_array($sel12sql);

$sel13sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='11:15 AM'");
$sel13row=mysqli_fetch_array($sel13sql);

$sel14sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='11:30 AM'");
$sel14row=mysqli_fetch_array($sel14sql);

$sel15sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='11:45 AM'");
$sel15row=mysqli_fetch_array($sel15sql);

$sel16sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='12:00 PM'");
$sel16row=mysqli_fetch_array($sel16sql);

$sel17sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='12:15 PM'");
$sel17row=mysqli_fetch_array($sel17sql);

$sel18sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='12:30 PM'");
$sel18row=mysqli_fetch_array($sel18sql);

$sel19sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='12:45 PM'");
$sel19row=mysqli_fetch_array($sel19sql);

$sel20sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='01:00 PM'");
$sel20row=mysqli_fetch_array($sel20sql);

$sel21sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='01:15 PM'");
$sel21row=mysqli_fetch_array($sel21sql);

$sel22sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='01:30 PM'");
$sel22row=mysqli_fetch_array($sel22sql);

$sel23sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='01:45 PM'");
$sel23row=mysqli_fetch_array($sel23sql);

$sel24sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='02:00 PM'");
$sel24row=mysqli_fetch_array($sel24sql);

$sel25sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='02:15 PM'");
$sel25row=mysqli_fetch_array($sel25sql);

$sel26sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='02:30 PM'");
$sel26row=mysqli_fetch_array($sel26sql);

$sel27sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='02:45 PM'");
$sel27row=mysqli_fetch_array($sel27sql);

$sel28sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='03:00 PM'");
$sel28row=mysqli_fetch_array($sel28sql);

$sel29sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='03:15 PM'");
$sel29row=mysqli_fetch_array($sel29sql);

$sel30sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='03:30 PM'");
$sel30row=mysqli_fetch_array($sel30sql);

$sel31sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='03:45 PM'");
$sel31row=mysqli_fetch_array($sel31sql);

$sel32sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='04:00 PM'");
$sel32row=mysqli_fetch_array($sel32sql);

$sel33sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='04:15 PM'");
$sel33row=mysqli_fetch_array($sel33sql);

$sel34sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='04:30 PM'");
$sel34row=mysqli_fetch_array($sel34sql);

$sel35sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='04:45 PM'");
$sel35row=mysqli_fetch_array($sel35sql);

$sel36sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='05:00 PM'");
$sel36row=mysqli_fetch_array($sel36sql);

$sel37sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='05:15 PM'");
$sel37row=mysqli_fetch_array($sel37sql);

$sel38sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='05:30 PM'");
$sel38row=mysqli_fetch_array($sel38sql);

$sel39sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='05:45 PM'");
$sel39row=mysqli_fetch_array($sel39sql);

$sel40sql=mysqli_query($db,"select * from appointments where app_date='$cur' and time='06:00 PM'");
$sel40row=mysqli_fetch_array($sel40sql);


//get edit appointment link
$link1=!empty($sel1row["patient_name"])?"edit_appointment.php?apid=".$sel1row["id"]:"#";
$link2=!empty($sel2row["patient_name"])?"edit_appointment.php?apid=".$sel2row["id"]:"#";
$link3=!empty($sel3row["patient_name"])?"edit_appointment.php?apid=".$sel3row["id"]:"#";
$link4=!empty($sel4row["patient_name"])?"edit_appointment.php?apid=".$sel4row["id"]:"#";
$link5=!empty($sel5row["patient_name"])?"edit_appointment.php?apid=".$sel5row["id"]:"#";
$link6=!empty($sel6row["patient_name"])?"edit_appointment.php?apid=".$sel6row["id"]:"#";
$link7=!empty($sel7row["patient_name"])?"edit_appointment.php?apid=".$sel7row["id"]:"#";
$link8=!empty($sel8row["patient_name"])?"edit_appointment.php?apid=".$sel8row["id"]:"#";
$link9=!empty($sel9row["patient_name"])?"edit_appointment.php?apid=".$sel9row["id"]:"#";
$link10=!empty($sel10row["patient_name"])?"edit_appointment.php?apid=".$sel10row["id"]:"#";
$link11=!empty($sel11row["patient_name"])?"edit_appointment.php?apid=".$sel11row["id"]:"#";
$link12=!empty($sel12row["patient_name"])?"edit_appointment.php?apid=".$sel12row["id"]:"#";
$link13=!empty($sel13row["patient_name"])?"edit_appointment.php?apid=".$sel13row["id"]:"#";
$link14=!empty($sel14row["patient_name"])?"edit_appointment.php?apid=".$sel14row["id"]:"#";
$link15=!empty($sel15row["patient_name"])?"edit_appointment.php?apid=".$sel15row["id"]:"#";
$link16=!empty($sel16row["patient_name"])?"edit_appointment.php?apid=".$sel16row["id"]:"#";
$link17=!empty($sel17row["patient_name"])?"edit_appointment.php?apid=".$sel17row["id"]:"#";
$link18=!empty($sel18row["patient_name"])?"edit_appointment.php?apid=".$sel18row["id"]:"#";
$link19=!empty($sel19row["patient_name"])?"edit_appointment.php?apid=".$sel19row["id"]:"#";
$link20=!empty($sel20row["patient_name"])?"edit_appointment.php?apid=".$sel20row["id"]:"#";
$link21=!empty($sel21row["patient_name"])?"edit_appointment.php?apid=".$sel21row["id"]:"#";
$link22=!empty($sel22row["patient_name"])?"edit_appointment.php?apid=".$sel22row["id"]:"#";
$link23=!empty($sel23row["patient_name"])?"edit_appointment.php?apid=".$sel23row["id"]:"#";
$link24=!empty($sel24row["patient_name"])?"edit_appointment.php?apid=".$sel24row["id"]:"#";
$link25=!empty($sel25row["patient_name"])?"edit_appointment.php?apid=".$sel25row["id"]:"#";
$link26=!empty($sel26row["patient_name"])?"edit_appointment.php?apid=".$sel26row["id"]:"#";
$link27=!empty($sel27row["patient_name"])?"edit_appointment.php?apid=".$sel27row["id"]:"#";
$link28=!empty($sel28row["patient_name"])?"edit_appointment.php?apid=".$sel28row["id"]:"#";
$link29=!empty($sel29row["patient_name"])?"edit_appointment.php?apid=".$sel29row["id"]:"#";
$link30=!empty($sel30row["patient_name"])?"edit_appointment.php?apid=".$sel30row["id"]:"#";
$link31=!empty($sel31row["patient_name"])?"edit_appointment.php?apid=".$sel31row["id"]:"#";
$link32=!empty($sel32row["patient_name"])?"edit_appointment.php?apid=".$sel32row["id"]:"#";
$link33=!empty($sel33row["patient_name"])?"edit_appointment.php?apid=".$sel33row["id"]:"#";
$link34=!empty($sel34row["patient_name"])?"edit_appointment.php?apid=".$sel34row["id"]:"#";
$link35=!empty($sel35row["patient_name"])?"edit_appointment.php?apid=".$sel35row["id"]:"#";
$link36=!empty($sel36row["patient_name"])?"edit_appointment.php?apid=".$sel36row["id"]:"#";
$link37=!empty($sel37row["patient_name"])?"edit_appointment.php?apid=".$sel37row["id"]:"#";
$link38=!empty($sel38row["patient_name"])?"edit_appointment.php?apid=".$sel38row["id"]:"#";
$link39=!empty($sel39row["patient_name"])?"edit_appointment.php?apid=".$sel39row["id"]:"#";
$link40=!empty($sel40row["patient_name"])?"edit_appointment.php?apid=".$sel40row["id"]:"#";
?>