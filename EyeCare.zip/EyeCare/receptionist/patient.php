<!DOCTYPE html>
<?php
    ob_start();
	date_default_timezone_set("Asia/Kolkata");
	require_once 'logincheck.php';
?>
<html lang = "eng">
	<head>
		<title>EyeCare</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "shortcut icon" href = "../images/eye-gb51ecb13e_1280.PNG" />
		<link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/customize.css" />
	</head>
<body>
	<div class = "navbar navbar-default navbar-fixed-top">
		<img src = "../images/eye-gb51ecb13e_1280.PNG" style = "float:left;" height = "55px" /><a href="home.php" style="pointer:cursor;"><label class = "navbar-brand">EyeCare</label></a>
			<?php
				$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
				$q = $conn->query("SELECT * FROM `admin` WHERE `admin_id` = '$_SESSION[admin_id]'") or die(mysqli_error());
				$f = $q->fetch_array();
			?>
			<ul class = "nav navbar-nav navbar-right">	
			    <li><a href="home.php" style="color:#fff; font-size:16px;"><span class = "glyphicon glyphicon-hand-left"></span> Back to the dashboard</a></li>
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#" style="color:white;">
						<span class = "glyphicon glyphicon-user"></span>
						<?php
							echo $f['firstname']." ".$f["middlename"]." ".$f['lastname'];
							$conn->close();
						?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
					<li>
						<a class = "me" href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
	</div>
		<br />
		<br />
		<br />
		<div style = "display:none;" id = "add_itr" class = "panel panel-success">	
			<div class = "panel-heading">
				<label>ADD PATIENT INFORMATION</label>
				<button id = "hide_itr" style = "float:right; margin-top:-4px;" class = "btn btn-sm btn-danger"><span class = "glyphicon glyphicon-remove"></span> CLOSE</button>
			</div>
			<div class = "panel-body">
				<form id = "form_dental" method = "POST" enctype = "multipart/form-data">
					<br />
					<br />
					<br />
					<div class = "form-inline">
					  <label for="title">Title</label>
					  <select name="title" class="form-control">
					    <option value = "">--Please select an option--</option>
					    <option>Mr.</option>
					    <option>Mrs</option>
					    <option>Ms</option>
					    <option>Master</option>
					    <option>Dr</option>
					  </select>
					  &nbsp;&nbsp;&nbsp;
						<label for = "firstname">Firstname:</label>
						<input class = "form-control" name = "firstname" type = "text" required = "required">
						&nbsp;&nbsp;&nbsp;
						<label for = "middlename">Middle Name:</label>
						<input class = "form-control" name = "middlename" placeholder = "(Optional)" type = "text" style="background-color:white !important;">
						&nbsp;&nbsp;&nbsp;
						<label for = "lastname">Surname:</label>
						<input class = "form-control" name = "lastname" type = "text" required = "required">
					</div>
					<br />
					<div class = "form-group">
						<label for = "birthdate" style = "float:left;">Birthdate:</label>
						<br style = "clear:both;" />
						<input type="date" class="form-control" name="birthdate" required>
						<br style = "clear:both;"/>
						<br />
						<label>Contact Number:</label>
						<input class = "form-control" name = "contact" type = "text" required="required">
						<br />
						<label for = "gender">Gender:</label>
						<select style = "width:22%;" class = "form-control" name = "gender" required = "required">
							<option value = "">--Please select an option--</option>
							<option value = "Male">Male</option>
							<option value = "Female">Female</option>
						</select>
						<h3>Home Address Details</h3>
						<label>House Name/ Flat Number</label>
						<input class = "form-control" name = "house" type = "text">
						<br />
					    <label>Number and street</label>
						<input class = "form-control" name = "street" type = "text" required>
						<br>
						<label>Locality</label>
						<input class = "form-control" name = "locality" type = "text">
						<br>
						<label>Town/ City</label>
						<input class = "form-control" name = "city" type = "text" required>
						<br>
						<label>State</label>
						<input class = "form-control" name = "state" type = "text" required>
						<br>
						<label>Pin Code</label>
						<input class = "form-control" name = "pin" type = "text" required>
					</div>
					<br />
					<div class = "form-inline">
						<button class = "btn btn-primary" name = "save_patient"><span class = "glyphicon glyphicon-save"></span> SAVE</button>
					</div>
				</form>
			</div>	
		</div>	
		<?php require '../add_patient.php'?>
		<div class = "panel panel-primary">
			<div class = "panel-heading">
				<label>PATIENTS LIST</Label>
			</div>
			<div class = "panel-body">
				<button id = "show_itr" class = "btn btn-info"><span class = "glyphicon glyphicon-plus"></span> ADD PATIENT</button>
				<br />
				<br />
				<table id = "table" class = "display" width = "100%" cellspacing = "0">
					<thead>
						<tr>
							<th>Patient No</th>
							<th>Name</th>
							<th>Birthdate</th>
							<th>Age</th>
							<th>gender</th>
							<th>House</th>
							<th>Street</th>
							<th>Locality</th>
							<th>City</th>
							<th>State</th>
							<th>Pin Code</th>
							<th><center>Action</center></th>
						</tr>
					</thead>
					<tbody>
					<?php
						$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
						$query = $conn->query("SELECT * FROM `itr` ORDER BY `patient_id` DESC") or die(mysqli_error());
						while($fetch = $query->fetch_array()){
						$id = $fetch['patient_id'];
					?>
						<tr>
							<td><?php echo !empty($fetch['birthdate'])?$fetch['patient_id']:"";?></td>
							<td><?php echo $fetch['title']." ".ucwords($fetch['firstname']." ".$fetch['middlename']." ".$fetch['lastname'])?></td>
							<td><?php echo !empty($fetch['birthdate'])?date("d/m/Y",strtotime($fetch['birthdate'])):"";?></td>				
							<td><?php echo $fetch['age']?></td>				
							<td><?php echo $fetch['gender']?></td>				
							<td><?php echo $fetch['house']?></td>
							<td><?php echo $fetch['street']?></td>
							<td><?php echo $fetch['locality']?></td>
							<td><?php echo $fetch['city']?></td>
							<td><?php echo $fetch['state']?></td>
							<td><?php echo $fetch['pin']?></td>
							<td><center>
							<a href = "edit_patient.php?id=<?php echo $fetch['patient_id']?>&lastname=<?php echo $fetch['lastname']?>" class = "btn btn-sm btn-warning"><span class = "glyphicon glyphicon-pencil"></span> Update</a>
							<?php
							if(!empty($fetch["birthdate"]))
							{
							?>
							<a href = "book_appointment.php?pid=<?php echo $fetch["patient_id"];?>" class = "btn btn-sm btn-success"><span class = "glyphicon glyphicon-pencil"></span> Book an Appointment</a>
							<?php
							}
							?>
							</center></td>
						</tr>
					<?php
						}
						$conn->close();
					?>
					</tbody>
					</table>
			</div>
		</div>
	<div id = "footer">
		<label class = "footer-title">&copy; Copyright EyeCare 2022</label>
	</div>
<?php include("script.php"); ?>
<script type = "text/javascript">
    $(document).ready(function() {
        function disableBack() { window.history.forward() }

        window.onload = disableBack();
        window.onpageshow = function(evt) { if (evt.persisted) disableBack() }
    });
</script>	
</body>
</html>