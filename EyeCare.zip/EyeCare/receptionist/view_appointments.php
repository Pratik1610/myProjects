<!DOCTYPE html>
<?php
    ob_start();
	date_default_timezone_set("Asia/Kolkata");
	require_once 'logincheck.php';
?>
<html lang = "eng">
	<head>
		<title>EyeCare</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "shortcut icon" href = "../images/eye-gb51ecb13e_1280.PNG" />
		<link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/customize.css" />
	</head>
<body>
	<div class = "navbar navbar-default navbar-fixed-top">
		<img src = "../images/eye-gb51ecb13e_1280.PNG" style = "float:left;" height = "55px" /><a href="home.php" style="pointer:cursor;"><label class = "navbar-brand">EyeCare</label></a>
			<?php
				$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
				$q = $conn->query("SELECT * FROM `admin` WHERE `admin_id` = '$_SESSION[admin_id]'") or die(mysqli_error());
				$f = $q->fetch_array();
			?>
			<ul class = "nav navbar-nav navbar-right">	
			    <li><a href="home.php" style="color:#fff; font-size:16px;"><span class = "glyphicon glyphicon-hand-left"></span> Back to the dashboard</a></li>
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#" style="color:white;">
						<span class = "glyphicon glyphicon-user"></span>
						<?php
							echo $f['firstname']." ".$f["middlename"]." ".$f['lastname'];
							$conn->close();
						?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
					<li>
						<a class = "me" href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
	</div>
		<br />
		<br />
		<br />
		<div class = "panel panel-primary">
			<div class = "panel-heading">
				<label>APPOINTMENT LIST</Label>
			</div>
			<div class = "panel-body">
				<br />
				<form method="post" action="">
				<div class="form-inline">
				<label>Search By Date:</label>
				<input type="date" name="sdate" class="form-control" value="<?php echo isset($_REQUEST["search"])?date("Y-m-d",strtotime($_POST["sdate"])):date("Y-m-d");?>">
				<input type="submit" name="search" class="btn btn-primary" value="Search">
				</div>
				</form>
				<br>
				<table id = "table" class = "display" width = "100%" cellspacing = "0">
					<thead>
						<tr>
							<th>Patient No</th>
							<th>Name</th>
							<th>Apointment Date</th>
							<th>Appointment Time</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
					<?php
						$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
						
						if(isset($_REQUEST["search"]))
						{
							$sdate=$_POST["sdate"];
						}
						else
						{
							$sdate=date("Y-m-d");
						}
						$query = $conn->query("SELECT * FROM `appointments` WHERE app_date='$sdate' ORDER BY `id` DESC") or die(mysqli_error());
						while($fetch = $query->fetch_array()){
						$id = $fetch['pid'];
					?>
						<tr>
							<td><?php echo $fetch['pid']?></td>
							<td><?php echo ucwords($fetch['patient_name']);?></td>
							<td><?php echo date("d/m/Y",strtotime($fetch['app_date']));?></td>				
							<td><?php echo $fetch['time']?></td>
							<td><center>
							<a href = "edit_appointment.php?apid=<?php echo $fetch["id"];?>" class = "btn btn-sm btn-success"><span class = "glyphicon glyphicon-pencil"></span> Edit</a>
							</center></td>
						</tr>
					<?php
						}
						$conn->close();
					?>
					</tbody>
					</table>
			</div>
		</div>
	<div id = "footer">
		<label class = "footer-title">&copy; Copyright EyeCare 2022</label>
	</div>
<?php include("script.php"); ?>
<script type = "text/javascript">
    $(document).ready(function() {
        function disableBack() { window.history.forward() }

        window.onload = disableBack();
        window.onpageshow = function(evt) { if (evt.persisted) disableBack() }
    });
</script>	
</body>
</html>