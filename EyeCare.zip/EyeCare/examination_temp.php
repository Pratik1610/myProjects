<!DOCTYPE html>
<?php
    ob_start();
	require_once 'logincheck.php';
	require_once 'authentication.php';
	
?>
<html lang = "eng">
	<head>
		<title>EyeCare</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "shortcut icon" href = "images/eye-gb51ecb13e_1280.PNG" />
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/customize.css" />
	</head>
<body>
	<div class = "navbar navbar-default navbar-fixed-top">
		<img src = "images/eye-gb51ecb13e_1280.PNG" style = "float:left;" height = "55px" /><label class = "navbar-brand">EyeCare</label>
			<?php
				$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
				$q = $conn->query("SELECT * FROM `user` WHERE `user_id` = '$_SESSION[user_id]'") or die(mysqli_error());
				$f = $q->fetch_array();
			?>
			<ul class = "nav navbar-nav navbar-right">	
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#" style="color:white;">
						<span class = "glyphicon glyphicon-user"></span>
						<?php
							echo $f['firstname']." ".$f["middlename"]." ".$f['lastname'];
							$conn->close();
						?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
					<li>
						<a class = "me" href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
	</div>
		<br />
		<br />
		<br />
		<div class = "panel panel-success">	
		<?php
			$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
			$query = $conn->query("SELECT * FROM `appointments` WHERE `id` = '$_GET[apid]'") or die(mysqli_error());
			$fetch = $query->fetch_array();
			$pid=$fetch["pid"]; // patient id
			$selp=mysqli_query($db,"select * from itr where patient_id='$pid'");
			$rowp=mysqli_fetch_array($selp);
			
			$selexam = mysqli_query($db,"SELECT * FROM `examination_temp` where pid='$pid' and apid='".$_GET['apid']."'") or die(mysqli_error());
			$fetchexam=mysqli_fetch_array($selexam);
		?>
			<div class = "panel-heading">
				<label>ADD Prescription>> Examination</label>
			</div>
			<div class = "panel-body">
					<div class = "panel panel-default">
					<div class = "panel-heading">
					  <label>Patient Details</label>
					  <p><strong>Patient Name: </strong><?php echo ucwords($fetch["patient_name"]);?> &nbsp; &nbsp; 
				   <strong>Gender: </strong><?php echo ucwords($rowp["gender"]);?> &nbsp; &nbsp; 
				</p>
				<p><strong>Address: </strong><?php 
				if(!empty($rowp["house"]))
				{
					echo $rowp["house"]." ";
					$address=$rowp["house"]." ";
				}
				if(!empty($rowp["street"]))
				{
					echo $rowp["street"]." ";
					$address.=$rowp["street"]." ";
				}
				if(!empty($rowp["locality"]))
				{
					echo $rowp["locality"]." ";
					$address.=$rowp["locality"]." ";
				}
				if(!empty($rowp["city"]))
				{
					echo ",".$rowp["city"]." ";
					$address.=$rowp["city"]." ";
				}
				if(!empty($rowp["state"]))
				{
					echo $rowp["state"]." ";
					$address.=$rowp["state"]." ";
				}
				if(!empty($rowp["pin"]))
				{
					echo $rowp["pin"]." ";
					$address.=$rowp["pin"]." ";
				}
				?> &nbsp; &nbsp; 
				<strong>Age: </strong><?php echo ucwords($rowp["age"]);?><span> Years</span>
				</p>
					</div>
					</div>
					<form id = "form_admin" method = "POST" enctype = "multi-part/form-data" >
					<input type="hidden" name="apid" value="<?php echo $_GET["apid"];?>">
							<input type="hidden" name="pid" value="<?php echo $pid;?>">
					    <ul class="nav nav-tabs">
							<li><a href="prescription_add.php?apid=<?php echo $_GET['apid'];?>">C/o</a></li>
							<li><a href="diagnosis_temp.php?apid=<?php echo $_GET['apid'];?>">Diagnosis</a></li>
							<li><a href="rx_temp.php?apid=<?php echo $_GET['apid'];?>">Rx</a></li>
							<li><a href="glasses_temp.php?apid=<?php echo $_GET['apid'];?>">Glasses</a></li>
							<li><a href="advice_temp.php?apid=<?php echo $_GET['apid'];?>">Advice</a></li>
							<li><a href="review_temp.php?apid=<?php echo $_GET['apid'];?>">Review</a></li>
							<li  class="active"><a href="examination_temp.php?apid=<?php echo $_GET['apid'];?>">Examination</a></li>
							<li><a href="followup_temp.php?apid=<?php echo $_GET['apid'];?>">Followup Notes</a></li>
						</ul>
						<br>
						<br>
						<table  border="2px" width="1300">
						<tbody>
						<tr style="border-width:5px; border-style:double;">
<td colspan="3">EXAMINATION</td>
<td colspan="12">
<select name="uppersec" id="uppersec" class="form-control">
							<?php 
								if(!empty($fetchexam["uppersec"]))
								{
								?>
								<option><?php echo $fetchexam["uppersec"]; ?></option>
								<?php
								  }?>
							<?php
							 $selehead=mysqli_query($db,"select distinct beanteriorcf from prescription_analysis where beanteriorcf!=''");
							 while($rowehead=mysqli_fetch_array($selehead))
							 {
							?>
							<option><?php echo $rowehead["beanteriorcf"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
</tr>
<tr>
<td colspan="3">ANT. SEGMENT</td>
<td colspan="6" class="text-center">OD</td>
<td colspan="6" class="text-center">OS</td>
</tr>
<tr>
<td colspan="3" rowspan="2">Visual Acuity</td>
<td colspan="2" class="text-center">Unaided</td>
<td colspan="2" class="text-center">Old Spectacles</td>
<td colspan="2" class="text-center">PH/ SS</td>
<td colspan="2" class="text-center">Unaided</td>
<td colspan="2" class="text-center">Old Spectacles</td>
<td colspan="2" class="text-center">PH/ SS</td>
</tr>
<tr>
<td>
<select name="od_unaided_va" class="form-control">
							<?php 
							$od_unaided=explode(" ",$fetchexam["od_unaided"]);
								if(!empty($od_unaided[0]))
								{
								?>
								<option><?php echo $od_unaided[0]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select va</option>
							<?php
								  }
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis where va!=''");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="od_unaided_nva" class="form-control">
							<?php 
								if(!empty($od_unaided[1]))
								{
								?>
								<option><?php echo $od_unaided[1]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select nva</option>
							<?php
								  }
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis where nva!=''");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="od_old_va" class="form-control">
							<?php 
							$od_old=explode(" ",$fetchexam["od_old_spectacles"]);
								if(!empty($od_old[0]))
								{
								?>
								<option><?php echo $od_old[0]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select va</option>
							<?php
								  }
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis where va!=''");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="od_old_nva" class="form-control">
							<?php 
								if(!empty($od_old[1]))
								{
								?>
								<option><?php echo $od_old[1]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select nva</option>
							<?php
								  }
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis where nva!=''");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="od_phss_va" class="form-control">
<?php 
							$od_phss=explode(" ",$fetchexam["od_ph_ss"]);
								if(!empty($od_phss[0]))
								{
								?>
								<option><?php echo $od_phss[0]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select va</option>
							<?php
								  }
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis where va!=''");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
 <select name="od_phss_nva" class="form-control">
 <?php 
								if(!empty($od_phss[1]))
								{
								?>
								<option><?php echo $od_phss[1]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select nva</option>
							<?php
								  }
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis where nva!=''");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="os_unaided_va" class="form-control">
<?php 
							$os_unaided=explode(" ",$fetchexam["os_unaided"]);
								if(!empty($od_unaided[0]))
								{
								?>
								<option><?php echo $os_unaided[0]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select va</option>
							<?php
								  }
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis where va!=''");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="os_unaided_nva" class="form-control">
<?php 
								if(!empty($os_unaided[1]))
								{
								?>
								<option><?php echo $os_unaided[1]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select nva</option>
							<?php
								  }
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis where nva!=''");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="os_old_va" class="form-control">
<?php 
							$os_old=explode(" ",$fetchexam["os_old_spectacles"]);
								if(!empty($os_old[0]))
								{
								?>
								<option><?php echo $os_old[0]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select va</option>
							<?php
								  }
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis where va!=''");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="os_old_nva" class="form-control">
<?php 
								if(!empty($os_old[1]))
								{
								?>
								<option><?php echo $os_old[1]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select nva</option>
							<?php
								  }
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis where nva!=''");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="os_phss_va" class="form-control">
<?php 
							$os_phss=explode(" ",$fetchexam["os_ph_ss"]);
								if(!empty($os_phss[0]))
								{
								?>
								<option><?php echo $os_phss[0]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select va</option>
							<?php
								  }
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis where va!=''");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
 <select name="os_phss_nva" class="form-control">
 <?php 
								if(!empty($os_phss[1]))
								{
								?>
								<option><?php echo $os_phss[1]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select nva</option>
							<?php
								  }
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis where nva!=''");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>

</tr>
<tr>
<td colspan="3">Projection of ray</td>
<td colspan="6">
<select name="od_pr" class="form-control">
							<?php 
								if(!empty($fetchexam["od_pr"]))
								{
								?>
								<option><?php echo $fetchexam["od_pr"]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">----Select----</option>
							<?php
								  }
							 $selpr=mysqli_query($db,"select distinct pr from prescription_analysis where pr!=''");
							 while($rowpr=mysqli_fetch_array($selpr))
							 {
							?>
							<option><?php echo $rowpr["pr"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="6"><select name="os_pr" class="form-control">
<?php 
								if(!empty($fetchexam["os_pr"]))
								{
								?>
								<option><?php echo $fetchexam["os_pr"]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">----Select----</option>
							<?php
								  }
							 $selpr=mysqli_query($db,"select distinct pr from prescription_analysis where pr!=''");
							 while($rowpr=mysqli_fetch_array($selpr))
							 {
							?>
							<option><?php echo $rowpr["pr"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
</tr>
<tr>
<td colspan="3">ARK</td>
<td class="text-center">Sph.</td>
<td class="text-center">Cyl.</td>
<td class="text-center">Axis</td>
<td class="text-center">VA</td>
<td class="text-center" colspan="2">Comment</td>
<td class="text-center">Sph.</td>
<td class="text-center">Cyl.</td>
<td class="text-center">Axis</td>
<td class="text-center">VA</td>
<td class="text-center" colspan="2">Comment</td>
</tr>
<tr>
<td rowspan="2" >&nbsp;</td>
<td >IPD</td>
<td>Dist.</td>
<td>
<select name="od_sph" class="form-control">
<?php 
								if(!empty($fetchexam["od_sph"]))
								{
								?>
								<option><?php echo $fetchexam["od_sph"]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select</option>
							<?php
								  }
							 $selglass=mysqli_query($db,"select distinct glass from prescription_analysis where glass!=''");
							 while($rowglass=mysqli_fetch_array($selglass))
							 {
							?>
							<option><?php echo $rowglass["glass"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td><select name="od_cyl" class="form-control">
<?php 
								if(!empty($fetchexam["od_cyl"]))
								{
								?>
								<option><?php echo $fetchexam["od_cyl"]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select</option>
							<?php
								  }
							 $selglass=mysqli_query($db,"select distinct glass from prescription_analysis where glass!=''");
							 while($rowglass=mysqli_fetch_array($selglass))
							 {
							?>
							<option><?php echo $rowglass["glass"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>
<select name="od_axis" class="form-control">
<?php 
								if(!empty($fetchexam["od_axis"]))
								{
								?>
								<option><?php echo $fetchexam["od_axis"]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select</option>
							<?php
								  }
							 $selaxis=mysqli_query($db,"select distinct axis from prescription_analysis where axis!=''");
							 while($rowaxis=mysqli_fetch_array($selaxis))
							 {
							?>
							<option><?php echo $rowaxis["axis"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="od_va" class="form-control">
<?php 
								if(!empty($fetchexam["od_va"]))
								{
								?>
								<option><?php echo $fetchexam["od_va"]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select va</option>
							<?php
								  }
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis where va!=''");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2" rowspan="2"><input class = "form-control" type = "text" name = "od_comment" value="<?php echo !empty($fetchexam["od_comment"])?$fetchexam["od_comment"]:"";?>" ></td>
<td>
<select name="os_sph" class="form-control">
<?php 
								if(!empty($fetchexam["os_sph"]))
								{
								?>
								<option><?php echo $fetchexam["os_sph"]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select</option>
							<?php
								  }
							 $selglass=mysqli_query($db,"select distinct glass from prescription_analysis where glass!=''");
							 while($rowglass=mysqli_fetch_array($selglass))
							 {
							?>
							<option><?php echo $rowglass["glass"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td><select name="os_cyl" class="form-control">
<?php 
								if(!empty($fetchexam["os_cyl"]))
								{
								?>
								<option><?php echo $fetchexam["os_cyl"]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select</option>
							<?php
								  }
							 $selglass=mysqli_query($db,"select distinct glass from prescription_analysis where glass!=''");
							 while($rowglass=mysqli_fetch_array($selglass))
							 {
							?>
							<option><?php echo $rowglass["glass"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>
<select name="os_axis" class="form-control">
<?php 
								if(!empty($fetchexam["os_axis"]))
								{
								?>
								<option><?php echo $fetchexam["os_axis"]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select</option>
							<?php
								  }
							 $selaxis=mysqli_query($db,"select distinct axis from prescription_analysis");
							 while($rowaxis=mysqli_fetch_array($selaxis))
							 {
							?>
							<option><?php echo $rowaxis["axis"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="os_va" class="form-control">
<?php 
								if(!empty($fetchexam["os_va"]))
								{
								?>
								<option><?php echo $fetchexam["os_va"]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select va</option>
							<?php
								  }
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis where va!=''");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2" rowspan="2"><input class = "form-control" type = "text" name = "os_comment" value="<?php echo !empty($fetchexam["os_comment"])?$fetchexam["os_comment"]:"";?>"></td>
</tr>
<tr>
<td>
<select name="ipd" class="form-control">
<?php 
								if(!empty($fetchexam["ipd"]))
								{
								?>
								<option><?php echo $fetchexam["ipd"]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select</option>
							<?php
								  }
							 $selpd=mysqli_query($db,"select distinct pd from prescription_analysis where pd!=''");
							 while($rowpd=mysqli_fetch_array($selpd))
							 {
							?>
							<option><?php echo $rowpd["pd"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>Near</td>
<td>Add</td>
<td colspan="2"><select name="od_add" class="form-control">
<?php 
								if(!empty($fetchexam["od_add"]))
								{
								?>
								<option><?php echo $fetchexam["od_add"]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select</option>
							<?php
								  }
							 $seladd=mysqli_query($db,"select distinct ad from prescription_analysis where ad!=''");
							 while($rowadd=mysqli_fetch_array($seladd))
							 {
							?>
							<option><?php echo $rowadd["ad"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>
<select name="od_nva" class="form-control">
<?php 
								if(!empty($fetchexam["od_nva"]))
								{
								?>
								<option><?php echo $fetchexam["od_nva"]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select nva</option>
							<?php
								  }
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis where nva!=''");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>Add</td>
<td colspan="2">
<select name="os_add" class="form-control">
<?php 
								if(!empty($fetchexam["os_add"]))
								{
								?>
								<option><?php echo $fetchexam["os_add"]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select</option>
							<?php
								  }
							 $seladd=mysqli_query($db,"select distinct ad from prescription_analysis where ad!=''");
							 while($rowadd=mysqli_fetch_array($seladd))
							 {
							?>
							<option><?php echo $rowadd["ad"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="os_nva" class="form-control">
<?php 
								if(!empty($fetchexam["os_nva"]))
								{
								?>
								<option><?php echo $fetchexam["os_nva"]; ?></option>
								<?php
								  }
								  else
								  {
									?>
							<option value="">Select nva</option>
							<?php
								  }
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis where nva!=''");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>

</tr>
<tr>
<td colspan="3">Head posture</td>
<td colspan="12">
<select name="head_posture" class="form-control">
<?php 
								if(!empty($fetchexam["head_posture"]))
								{
								?>
								<option><?php echo $fetchexam["head_posture"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selhead=mysqli_query($db,"select distinct head from prescription_analysis where head!=''");
							 while($rowhead=mysqli_fetch_array($selhead))
							 {
							?>
							<option><?php echo $rowhead["head"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>

</tr>
<tr>
<td colspan="3">Forehead</td>
<td colspan="6">
<select name="od_forehead" class="form-control">
<?php 
								if(!empty($fetchexam["od_forehead"]))
								{
								?>
								<option><?php echo $fetchexam["od_forehead"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selfhead=mysqli_query($db,"select distinct forehead from prescription_analysis where forehead!=''");
							 while($rowfhead=mysqli_fetch_array($selfhead))
							 {
							?>
							<option><?php echo $rowfhead["forehead"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="6">
<select name="os_forehead" class="form-control">
<?php 
								if(!empty($fetchexam["os_forehead"]))
								{
								?>
								<option><?php echo $fetchexam["os_forehead"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selfhead=mysqli_query($db,"select distinct forehead from prescription_analysis  where forehead!=''");
							 while($rowfhead=mysqli_fetch_array($selfhead))
							 {
							?>
							<option><?php echo $rowfhead["forehead"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>

</tr>
<tr>
<td colspan="3">Orbit</td>
<td colspan="6"><input class = "form-control" type = "text" name="od_orbit" value="<?php echo !empty($fetchexam["od_orbit"])?$fetchexam["od_orbit"]:"NAD"; ?>" placeholder="OD Orbit"></td>
<td colspan="6"><input class = "form-control" type = "text" name="os_orbit" value="<?php echo !empty($fetchexam["os_orbit"])?$fetchexam["os_orbit"]:"NAD"; ?>" placeholder="OS Orbit"></td>

</tr>
<tr>
<td colspan="3">Eye brows</td>
<td colspan="6">
<select name="od_eyebrows" class="form-control">
<?php 
								if(!empty($fetchexam["od_eye_brows"]))
								{
								?>
								<option><?php echo $fetchexam["od_eye_brows"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $seleyebrows=mysqli_query($db,"select distinct eyebrows from prescription_analysis  where eyebrows!=''");
							 while($roweyebrows=mysqli_fetch_array($seleyebrows))
							 {
							?>
							<option><?php echo $roweyebrows["eyebrows"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="6">
<select name="os_eyebrows" class="form-control">
<?php 
								if(!empty($fetchexam["os_eye_brows"]))
								{
								?>
								<option><?php echo $fetchexam["os_eye_brows"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $seleyebrows=mysqli_query($db,"select distinct eyebrows from prescription_analysis where eyebrows!=''");
							 while($roweyebrows=mysqli_fetch_array($seleyebrows))
							 {
							?>
							<option><?php echo $roweyebrows["eyebrows"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>

</tr>
<tr>
<td colspan="3">Eye lids</td>
<td colspan="6">
<select name="od_eye_lids" class="form-control">
<?php 
								if(!empty($fetchexam["od_eye_lids"]))
								{
								?>
								<option><?php echo $fetchexam["od_eye_lids"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $sellid=mysqli_query($db,"select distinct lid from prescription_analysis where lid!=''");
							 while($rowlid=mysqli_fetch_array($sellid))
							 {
							?>
							<option><?php echo $rowlid["lid"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="6">
<select name="os_eye_lids" class="form-control">
<?php 
								if(!empty($fetchexam["os_eye_lids"]))
								{
								?>
								<option><?php echo $fetchexam["os_eye_lids"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $sellid=mysqli_query($db,"select distinct lid from prescription_analysis where lid!=''");
							 while($rowlid=mysqli_fetch_array($sellid))
							 {
							?>
							<option><?php echo $rowlid["lid"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>

</tr>
<tr>
<td >&nbsp;</td>
<td colspan="2" >Position</td>
<td colspan="6"><select name="od_eyelid_position" class="form-control">
<?php 
								if(!empty($fetchexam["od_position_eyelids"]))
								{
								?>
								<option><?php echo $fetchexam["od_position_eyelids"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $sellidpos=mysqli_query($db,"select distinct lidposition from prescription_analysis where lidposition!=''");
							 while($rowlidpos=mysqli_fetch_array($sellidpos))
							 {
							?>
							<option><?php echo $rowlidpos["lidposition"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6">
<select name="os_eyelid_position" class="form-control">
<?php 
								if(!empty($fetchexam["os_position_eyelids"]))
								{
								?>
								<option><?php echo $fetchexam["os_position_eyelids"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $sellidpos=mysqli_query($db,"select distinct lidposition from prescription_analysis where lidposition!=''");
							 while($rowlidpos=mysqli_fetch_array($sellidpos))
							 {
							?>
							<option><?php echo $rowlidpos["lidposition"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>

</tr>
<tr>
<td >&nbsp;</td>
<td colspan="2" >Skin</td>
<td colspan="6">
<select name="od_eyelid_skin" class="form-control">
<?php 
								if(!empty($fetchexam["od_skin_eyelids"]))
								{
								?>
								<option><?php echo $fetchexam["od_skin_eyelids"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $sellidskin=mysqli_query($db,"select distinct lidskin from prescription_analysis where lidskin!=''");
							 while($rowlidskin=mysqli_fetch_array($sellidskin))
							 {
							?>
							<option><?php echo $rowlidskin["lidskin"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="6">
<select name="os_eyelid_skin" class="form-control">
<?php 
								if(!empty($fetchexam["os_skin_eyelids"]))
								{
								?>
								<option><?php echo $fetchexam["os_skin_eyelids"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $sellidskin=mysqli_query($db,"select distinct lidskin from prescription_analysis where lidskin!=''");
							 while($rowlidskin=mysqli_fetch_array($sellidskin))
							 {
							?>
							<option><?php echo $rowlidskin["lidskin"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>

</tr>
<tr>
<td >&nbsp;</td>
<td colspan="2" >Margins</td>
<td colspan="6"><select name="od_eyelid_margine" class="form-control">
<?php 
								if(!empty($fetchexam["od_margins_eyelids"]))
								{
								?>
								<option><?php echo $fetchexam["od_margins_eyelids"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $sellidmargine=mysqli_query($db,"select distinct lidmargine from prescription_analysis where lidmargine!=''");
							 while($rowlidmargine=mysqli_fetch_array($sellidmargine))
							 {
							?>
							<option><?php echo $rowlidmargine["lidmargine"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_eyelid_margine" class="form-control">
<?php 
								if(!empty($fetchexam["os_margins_eyelids"]))
								{
								?>
								<option><?php echo $fetchexam["os_margins_eyelids"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $sellidmargine=mysqli_query($db,"select distinct lidmargine from prescription_analysis where lidmargine!=''");
							 while($rowlidmargine=mysqli_fetch_array($sellidmargine))
							 {
							?>
							<option><?php echo $rowlidmargine["lidmargine"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td colspan="3">Lacrimal app.</td>
<td colspan="6"><input class = "form-control" type = "text" name = "od_lacrimal_app" value="<?php echo !empty($fetchexam["od_lacrimal_app"])?$fetchexam["od_lacrimal_app"]:"NAD"; ?>" placeholder="OD Lacrimal App"></td>
<td colspan="6"><input class = "form-control" type = "text" name = "os_lacrimal_app" value="<?php echo !empty($fetchexam["os_lacrimal_app"])?$fetchexam["os_lacrimal_app"]:"NAD";?>" placeholder="OS Lacrimal App"></td>

</tr>
<tr>
<td colspan="3">Eye ball</td>
<td colspan="6"><select name="od_eye_ball" class="form-control">
<?php 
								if(!empty($fetchexam["od_eye_ball"]))
								{
								?>
								<option><?php echo $fetchexam["od_eye_ball"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $seleyeball=mysqli_query($db,"select distinct eyeball from prescription_analysis where eyeball!=''");
							 while($roweyeball=mysqli_fetch_array($seleyeball))
							 {
							?>
							<option><?php echo $roweyeball["eyeball"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_eye_ball" class="form-control">
<?php 
								if(!empty($fetchexam["os_eye_ball"]))
								{
								?>
								<option><?php echo $fetchexam["os_eye_ball"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $seleyeball=mysqli_query($db,"select distinct eyeball from prescription_analysis where eyeball!=''");
							 while($roweyeball=mysqli_fetch_array($seleyeball))
							 {
							?>
							<option><?php echo $roweyeball["eyeball"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td >&nbsp;</td>
<td colspan="2" >Moments</td>
<td colspan="6"><select name="od_eyeball_moments" class="form-control">
<?php 
								if(!empty($fetchexam["od_moments_eyeball"]))
								{
								?>
								<option><?php echo $fetchexam["od_moments_eyeball"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selmoment=mysqli_query($db,"select distinct moments from prescription_analysis where moments!=''");
							 while($rowmoment=mysqli_fetch_array($selmoment))
							 {
							?>
							<option><?php echo $rowmoment["moments"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_eyeball_moments" class="form-control">
<?php 
								if(!empty($fetchexam["os_moments_eyeball"]))
								{
								?>
								<option><?php echo $fetchexam["os_moments_eyeball"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selmoment=mysqli_query($db,"select distinct moments from prescription_analysis where moments!=''");
							 while($rowmoment=mysqli_fetch_array($selmoment))
							 {
							?>
							<option><?php echo $rowmoment["moments"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td colspan="3">Conjunctiva</td>
<td colspan="6">
<select name="od_conjunctiva" class="form-control">
<?php 
								if(!empty($fetchexam["od_conjunctiva"]))
								{
								?>
								<option><?php echo $fetchexam["od_conjunctiva"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selconjunctiva=mysqli_query($db,"select distinct conjunctiva from prescription_analysis where conjunctiva!=''");
							 while($rowconjunctiva=mysqli_fetch_array($selconjunctiva))
							 {
							?>
							<option><?php echo $rowconjunctiva["conjunctiva"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="6">
 <select name="os_conjunctiva" class="form-control">
 <?php 
								if(!empty($fetchexam["os_conjunctiva"]))
								{
								?>
								<option><?php echo $fetchexam["os_conjunctiva"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selconjunctiva=mysqli_query($db,"select distinct conjunctiva from prescription_analysis where conjunctiva!=''");
							 while($rowconjunctiva=mysqli_fetch_array($selconjunctiva))
							 {
							?>
							<option><?php echo $rowconjunctiva["conjunctiva"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>

</tr>
<tr>
<td rowspan="2" >&nbsp;</td>
<td colspan="2" >Palpebral</td>
<td colspan="6"><select name="od_pulpebral_conjunctiva" class="form-control">
<?php 
								if(!empty($fetchexam["od_pulpebral_conjunctiva"]))
								{
								?>
								<option><?php echo $fetchexam["od_pulpebral_conjunctiva"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selpulp=mysqli_query($db,"select distinct conjunctiva from prescription_analysis where conjunctiva!=''");
							 while($rowpulp=mysqli_fetch_array($selpulp))
							 {
							?>
							<option><?php echo $rowpulp["conjunctiva"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_pulpebral_conjunctiva" class="form-control">
<?php 
								if(!empty($fetchexam["os_pulpebral_conjunctiva"]))
								{
								?>
								<option><?php echo $fetchexam["os_pulpebral_conjunctiva"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selpulp=mysqli_query($db,"select distinct conjunctiva from prescription_analysis where conjunctiva!=''");
							 while($rowpulp=mysqli_fetch_array($selpulp))
							 {
							?>
							<option><?php echo $rowpulp["conjunctiva"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td colspan="2">Bulbar</td>
<td colspan="6"><select name="od_bulbar_conjunctiva" class="form-control">
<?php 
								if(!empty($fetchexam["od_bulbar_conjunctiva"]))
								{
								?>
								<option><?php echo $fetchexam["od_bulbar_conjunctiva"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selbulbar=mysqli_query($db,"select distinct conjunctiva from prescription_analysis where conjunctiva!=''");
							 while($rowbulbar=mysqli_fetch_array($selbulbar))
							 {
							?>
							<option><?php echo $rowbulbar["conjunctiva"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_bulbar_conjunctiva" class="form-control">
<?php 
								if(!empty($fetchexam["os_bulbar_conjunctiva"]))
								{
								?>
								<option><?php echo $fetchexam["os_bulbar_conjunctiva"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selbulbar=mysqli_query($db,"select distinct conjunctiva from prescription_analysis where conjunctiva!=''");
							 while($rowbulbar=mysqli_fetch_array($selbulbar))
							 {
							?>
							<option><?php echo $rowbulbar["conjunctiva"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td colspan="3">Sclera</td>
<td colspan="6">&nbsp;</td>
<td colspan="6">&nbsp;</td>

</tr>
<tr>
<td colspan="3">Cornea</td>
<td colspan="6">&nbsp;</td>
<td colspan="6">&nbsp;</td>

</tr>
<tr>
<td rowspan="5">&nbsp;</td>
<td colspan="2">Size</td>
<td colspan="6">
<select name="od_cornea_size" class="form-control">
<?php 
								if(!empty($fetchexam["od_size_cornea"]))
								{
								?>
								<option><?php echo $fetchexam["od_size_cornea"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selcsize=mysqli_query($db,"select distinct corneasize from prescription_analysis where corneasize!=''");
							 while($rowcsize=mysqli_fetch_array($selcsize))
							 {
							?>
							<option><?php echo $rowcsize["corneasize"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="6">
<select name="os_cornea_size" class="form-control">
<?php 
								if(!empty($fetchexam["os_size_cornea"]))
								{
								?>
								<option><?php echo $fetchexam["os_size_cornea"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selcsize=mysqli_query($db,"select distinct corneasize from prescription_analysis where corneasize!=''");
							 while($rowcsize=mysqli_fetch_array($selcsize))
							 {
							?>
							<option><?php echo $rowcsize["corneasize"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>

</tr>
<tr>
<td colspan="2">Surface</td>
<td colspan="6"><select name="od_cornea_surface" class="form-control">
<?php 
								if(!empty($fetchexam["od_surface_cornea"]))
								{
								?>
								<option><?php echo $fetchexam["od_surface_cornea"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selcsurface=mysqli_query($db,"select distinct corneasurface from prescription_analysis where corneasurface!=''");
							 while($rowcsurface=mysqli_fetch_array($selcsurface))
							 {
							?>
							<option><?php echo $rowcsurface["corneasurface"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_cornea_surface" class="form-control">
<?php 
								if(!empty($fetchexam["os_surface_cornea"]))
								{
								?>
								<option><?php echo $fetchexam["os_surface_cornea"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selcsurface=mysqli_query($db,"select distinct corneasurface from prescription_analysis where corneasurface!=''");
							 while($rowcsurface=mysqli_fetch_array($selcsurface))
							 {
							?>
							<option><?php echo $rowcsurface["corneasurface"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td colspan="2">Tansparancy</td>
<td colspan="6"><select name="od_transparency" class="form-control">
<?php 
								if(!empty($fetchexam["od_transparency_cornea"]))
								{
								?>
								<option><?php echo $fetchexam["od_transparency_cornea"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $seltransparency=mysqli_query($db,"select distinct transparency from prescription_analysis where transparency!=''");
							 while($rowtransparency=mysqli_fetch_array($seltransparency))
							 {
							?>
							<option><?php echo $rowtransparency["transparency"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"> <select name="os_transparency" class="form-control">
<?php 
								if(!empty($fetchexam["os_transparency_cornea"]))
								{
								?>
								<option><?php echo $fetchexam["os_transparency_cornea"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $seltransparency=mysqli_query($db,"select distinct transparency from prescription_analysis where transparency!=''");
							 while($rowtransparency=mysqli_fetch_array($seltransparency))
							 {
							?>
							<option><?php echo $rowtransparency["transparency"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td colspan="2">Stroma</td>
<td colspan="6"><select name="od_stroma" class="form-control">
<?php 
								if(!empty($fetchexam["od_stroma_cornea"]))
								{
								?>
								<option><?php echo $fetchexam["od_stroma_cornea"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selstroma=mysqli_query($db,"select distinct stroma from prescription_analysis where stroma!=''");
							 while($rowstroma=mysqli_fetch_array($selstroma))
							 {
							?>
							<option><?php echo $rowstroma["stroma"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"> <select name="os_stroma" class="form-control">
<?php 
								if(!empty($fetchexam["os_stroma_cornea"]))
								{
								?>
								<option><?php echo $fetchexam["os_stroma_cornea"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selstroma=mysqli_query($db,"select distinct stroma from prescription_analysis where stroma!=''");
							 while($rowstroma=mysqli_fetch_array($selstroma))
							 {
							?>
							<option><?php echo $rowstroma["stroma"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td colspan="2">Endothelium</td>
<td colspan="6"><select name="od_endothelium" class="form-control">
<?php 
								if(!empty($fetchexam["od_endothelium_cornea"]))
								{
								?>
								<option><?php echo $fetchexam["od_endothelium_cornea"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selendoth=mysqli_query($db,"select distinct endoth from prescription_analysis where endoth!=''");
							 while($rowendoth=mysqli_fetch_array($selendoth))
							 {
							?>
							<option><?php echo $rowendoth["endoth"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_endothelium" class="form-control">
<?php 
								if(!empty($fetchexam["os_endothelium_cornea"]))
								{
								?>
								<option><?php echo $fetchexam["os_endothelium_cornea"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selendoth=mysqli_query($db,"select distinct endoth from prescription_analysis where endoth!=''");
							 while($rowendoth=mysqli_fetch_array($selendoth))
							 {
							?>
							<option><?php echo $rowendoth["endoth"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td colspan="3">AC</td>
<td colspan="6">&nbsp;</td>
<td colspan="6">&nbsp;</td>

</tr>
<tr>
<td rowspan="2">&nbsp;</td>
<td colspan="2">Contant</td>
<td colspan="6">	<select name="od_accontant" class="form-control">
<?php 
								if(!empty($fetchexam["od_ac_contant"]))
								{
								?>
								<option><?php echo $fetchexam["od_ac_contant"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selaccontant=mysqli_query($db,"select distinct accontant from prescription_analysis where accontant!=''");
							 while($rowaccontant=mysqli_fetch_array($selaccontant))
							 {
							?>
							<option><?php echo $rowaccontant["accontant"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_accontant" class="form-control">
<?php 
								if(!empty($fetchexam["os_ac_contant"]))
								{
								?>
								<option><?php echo $fetchexam["os_ac_contant"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selaccontant=mysqli_query($db,"select distinct accontant from prescription_analysis where accontant!=''");
							 while($rowaccontant=mysqli_fetch_array($selaccontant))
							 {
							?>
							<option><?php echo $rowaccontant["accontant"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td colspan="2">Depth</td>
<td colspan="6">
<select name="od_acdepth" class="form-control">
<?php 
								if(!empty($fetchexam["od_ac_depth"]))
								{
								?>
								<option><?php echo $fetchexam["od_ac_depth"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selacdepth=mysqli_query($db,"select distinct acdepth from prescription_analysis where acdepth!=''");
							 while($rowacdepth=mysqli_fetch_array($selacdepth))
							 {
							?>
							<option><?php echo $rowacdepth["acdepth"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="6">
<select name="os_acdepth" class="form-control">
<?php 
								if(!empty($fetchexam["os_ac_depth"]))
								{
								?>
								<option><?php echo $fetchexam["os_ac_depth"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selacdepth=mysqli_query($db,"select distinct acdepth from prescription_analysis where acdepth!=''");
							 while($rowacdepth=mysqli_fetch_array($selacdepth))
							 {
							?>
							<option><?php echo $rowacdepth["acdepth"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>

</tr>
<tr>
<td colspan="3">Iris</td>
<td colspan="6">&nbsp;</td>
<td colspan="6">&nbsp;</td>

</tr>
<tr>
<td rowspan="2">&nbsp;</td>
<td colspan="2">Colour</td>
<td colspan="6"><select name="od_iriscolour" class="form-control">
<?php 
								if(!empty($fetchexam["od_iris_colour"]))
								{
								?>
								<option><?php echo $fetchexam["od_iris_colour"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $seliriscolour=mysqli_query($db,"select distinct iriscolour from prescription_analysis where iriscolour!=''");
							 while($rowiriscolour=mysqli_fetch_array($seliriscolour))
							 {
							?>
							<option><?php echo $rowiriscolour["iriscolour"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_iriscolour" class="form-control">
<?php 
								if(!empty($fetchexam["os_iris_colour"]))
								{
								?>
								<option><?php echo $fetchexam["os_iris_colour"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $seliriscolour=mysqli_query($db,"select distinct iriscolour from prescription_analysis where iriscolour!=''");
							 while($rowiriscolour=mysqli_fetch_array($seliriscolour))
							 {
							?>
							<option><?php echo $rowiriscolour["iriscolour"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td colspan="2">Pattern</td>
<td colspan="6"><select name="od_irispattern" class="form-control">
<?php 
								if(!empty($fetchexam["od_iris_pattern"]))
								{
								?>
								<option><?php echo $fetchexam["od_iris_pattern"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selirispattern=mysqli_query($db,"select distinct irispattern from prescription_analysis where irispattern!=''");
							 while($rowirispattern=mysqli_fetch_array($selirispattern))
							 {
							?>
							<option><?php echo $rowirispattern["irispattern"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_irispattern" class="form-control">
<?php 
								if(!empty($fetchexam["os_iris_pattern"]))
								{
								?>
								<option><?php echo $fetchexam["os_iris_pattern"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selirispattern=mysqli_query($db,"select distinct irispattern from prescription_analysis where irispattern!=''");
							 while($rowirispattern=mysqli_fetch_array($selirispattern))
							 {
							?>
							<option><?php echo $rowirispattern["irispattern"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td colspan="3">Pulpil</td>
<td colspan="6">&nbsp;</td>
<td colspan="6">&nbsp;</td>

</tr>
<tr>
<td rowspan="3">&nbsp;</td>
<td colspan="2">Size</td>
<td colspan="6">
<select name="od_pupilsize" class="form-control">
<?php 
								if(!empty($fetchexam["od_pupil_size"]))
								{
								?>
								<option><?php echo $fetchexam["od_pupil_size"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selpupilsize=mysqli_query($db,"select distinct pupilsize from prescription_analysis where pupilsize!=''");
							 while($rowpupilsize=mysqli_fetch_array($selpupilsize))
							 {
							?>
							<option><?php echo $rowpupilsize["pupilsize"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="6"><select name="os_pupilsize" class="form-control">
<?php 
								if(!empty($fetchexam["os_pupil_size"]))
								{
								?>
								<option><?php echo $fetchexam["os_pupil_size"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selpupilsize=mysqli_query($db,"select distinct pupilsize from prescription_analysis where pupilsize!=''");
							 while($rowpupilsize=mysqli_fetch_array($selpupilsize))
							 {
							?>
							<option><?php echo $rowpupilsize["pupilsize"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td colspan="2">Shape</td>
<td colspan="6"><select name="od_pupilshape" class="form-control">
<?php 
								if(!empty($fetchexam["od_pupil_shape"]))
								{
								?>
								<option><?php echo $fetchexam["od_pupil_shape"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selpupilshape=mysqli_query($db,"select distinct pupilshape from prescription_analysis where pupilshape!=''");
							 while($rowpupilshape=mysqli_fetch_array($selpupilshape))
							 {
							?>
							<option><?php echo $rowpupilshape["pupilshape"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"> <select name="os_pupilshape" class="form-control">
<?php 
								if(!empty($fetchexam["os_pupil_shape"]))
								{
								?>
								<option><?php echo $fetchexam["os_pupil_shape"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selpupilshape=mysqli_query($db,"select distinct pupilshape from prescription_analysis where pupilshape!=''");
							 while($rowpupilshape=mysqli_fetch_array($selpupilshape))
							 {
							?>
							<option><?php echo $rowpupilshape["pupilshape"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td colspan="2">Reaction</td>
<td colspan="6"><select name="od_pupilreaction" class="form-control">
<?php 
								if(!empty($fetchexam["od_pupil_reaction"]))
								{
								?>
								<option><?php echo $fetchexam["od_pupil_reaction"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selpupilreaction=mysqli_query($db,"select distinct pupilreaction from prescription_analysis where pupilreaction!=''");
							 while($rowpupilreaction=mysqli_fetch_array($selpupilreaction))
							 {
							?>
							<option><?php echo $rowpupilreaction["pupilreaction"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_pupilreaction" class="form-control">
<?php 
								if(!empty($fetchexam["os_pupil_reaction"]))
								{
								?>
								<option><?php echo $fetchexam["os_pupil_reaction"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selpupilreaction=mysqli_query($db,"select distinct pupilreaction from prescription_analysis where pupilreaction!=''");
							 while($rowpupilreaction=mysqli_fetch_array($selpupilreaction))
							 {
							?>
							<option><?php echo $rowpupilreaction["pupilreaction"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td colspan="3">Lens</td>
<td colspan="6"><select name="od_lens" class="form-control">
<?php 
								if(!empty($fetchexam["od_lens"]))
								{
								?>
								<option><?php echo $fetchexam["od_lens"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $sellens=mysqli_query($db,"select distinct lens from prescription_analysis where lens!=''");
							 while($rowlens=mysqli_fetch_array($sellens))
							 {
							?>
							<option><?php echo $rowlens["lens"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_lens" class="form-control">
<?php 
								if(!empty($fetchexam["os_lens"]))
								{
								?>
								<option><?php echo $fetchexam["os_lens"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $sellens=mysqli_query($db,"select distinct lens from prescription_analysis where lens!=''");
							 while($rowlens=mysqli_fetch_array($sellens))
							 {
							?>
							<option><?php echo $rowlens["lens"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td>&nbsp;</td>
<td colspan="2">Opacity</td>
<td colspan="6"><select name="od_lens_opacity" class="form-control">
<?php 
								if(!empty($fetchexam["od_lens_opacity"]))
								{
								?>
								<option><?php echo $fetchexam["od_lens_opacity"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $sellens_opacity=mysqli_query($db,"select distinct lens from prescription_analysis where lens!=''");
							 while($rowlens=mysqli_fetch_array($sellens_opacity))
							 {
							?>
							<option><?php echo $rowlens["lens"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_lens_opacity" class="form-control">
<?php 
								if(!empty($fetchexam["os_lens_opacity"]))
								{
								?>
								<option><?php echo $fetchexam["os_lens_opacity"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $sellens_opacity=mysqli_query($db,"select distinct lens from prescription_analysis where lens!=''");
							 while($rowlens=mysqli_fetch_array($sellens_opacity))
							 {
							?>
							<option><?php echo $rowlens["lens"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td colspan="3">IOP</td>
<td colspan="6"><input class = "form-control" type = "text" name = "od_IOP" value="<?php echo !empty($fetchexam["od_iop"])?$fetchexam["od_iop"]:"NAD"; ?>" placeholder="OD IOP"></td>
<td colspan="6"><input class = "form-control" type = "text" name = "os_IOP" value="<?php echo !empty($fetchexam["os_iop"])?$fetchexam["os_iop"]:"NAD";?>" placeholder="OS IOP"></td>

</tr>
<tr>
<td colspan="2">Fundus</td>
<td>Direct</td>
<td colspan="6">
<select name="od_fundus" class="form-control">
<?php 
								if(!empty($fetchexam["od_fundus"]))
								{
								?>
								<option><?php echo $fetchexam["od_fundus"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selfundus=mysqli_query($db,"select distinct fundus from prescription_analysis where lens!=''");
							 while($rowfundus=mysqli_fetch_array($selfundus))
							 {
							?>
							<option><?php echo $rowfundus["fundus"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="6">
<select name="os_fundus" class="form-control">
<?php 
								if(!empty($fetchexam["os_fundus"]))
								{
								?>
								<option><?php echo $fetchexam["os_fundus"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selfundus=mysqli_query($db,"select distinct fundus from prescription_analysis where lens!=''");
							 while($rowfundus=mysqli_fetch_array($selfundus))
							 {
							?>
							<option><?php echo $rowfundus["fundus"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>

</tr>
<tr>
<td colspan="3">Media</td>
<td colspan="6"><select name="od_media" class="form-control">
<?php 
								if(!empty($fetchexam["od_media"]))
								{
								?>
								<option><?php echo $fetchexam["od_media"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selmedia=mysqli_query($db,"select distinct media from prescription_analysis where media!=''");
							 while($rowmedia=mysqli_fetch_array($selmedia))
							 {
							?>
							<option><?php echo $rowmedia["media"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_media" class="form-control">
<?php 
								if(!empty($fetchexam["os_media"]))
								{
								?>
								<option><?php echo $fetchexam["os_media"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selmedia=mysqli_query($db,"select distinct media from prescription_analysis where media!=''");
							 while($rowmedia=mysqli_fetch_array($selmedia))
							 {
							?>
							<option><?php echo $rowmedia["media"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td colspan="3">Optic Disc</td>
<td colspan="6"><select name="od_optic_disc" class="form-control">
<?php 
								if(!empty($fetchexam["od_optic_disc"]))
								{
								?>
								<option><?php echo $fetchexam["os_optic_disc"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $seloptic=mysqli_query($db,"select distinct opticdisc from prescription_analysis where opticdisc!=''");
							 while($rowoptic=mysqli_fetch_array($seloptic))
							 {
							?>
							<option><?php echo $rowoptic["opticdisc"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_optic_disc" class="form-control">
<?php 
								if(!empty($fetchexam["os_optic_disc"]))
								{
								?>
								<option><?php echo $fetchexam["os_optic_disc"]; ?></option>
								<?php
								  }
									?>

							<?php
							 $seloptic=mysqli_query($db,"select distinct opticdisc from prescription_analysis where opticdisc!=''");
							 while($rowoptic=mysqli_fetch_array($seloptic))
							 {
							?>
							<option><?php echo $rowoptic["opticdisc"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td>&nbsp;</td>
<td colspan="2">Size</td>
<td colspan="6"><select name="od_disc_size" class="form-control">
<?php 
								if(!empty($fetchexam["od_optic_disc_size"]))
								{
								?>
								<option><?php echo $fetchexam["od_optic_disc_size"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $seldiscsize=mysqli_query($db,"select distinct discsize from prescription_analysis where discsize!=''");
							 while($rowdiscsize=mysqli_fetch_array($seldiscsize))
							 {
							?>
							<option><?php echo $rowdiscsize["discsize"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_disc_size" class="form-control">
<?php 
								if(!empty($fetchexam["os_optic_disc_size"]))
								{
								?>
								<option><?php echo $fetchexam["os_optic_disc_size"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $seldiscsize=mysqli_query($db,"select distinct discsize from prescription_analysis where discsize!=''");
							 while($rowdiscsize=mysqli_fetch_array($seldiscsize))
							 {
							?>
							<option><?php echo $rowdiscsize["discsize"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td>&nbsp;</td>
<td colspan="2">Shape</td>
<td colspan="6"><select name="od_disc_shape" class="form-control">
<?php 
								if(!empty($fetchexam["od_optic_disc_shape"]))
								{
								?>
								<option><?php echo $fetchexam["od_optic_disc_shape"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $seldiscshape=mysqli_query($db,"select distinct discshape from prescription_analysis where discshape!=''");
							 while($rowdiscshape=mysqli_fetch_array($seldiscshape))
							 {
							?>
							<option><?php echo $rowdiscshape["discshape"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_disc_shape" class="form-control">
<?php 
								if(!empty($fetchexam["os_optic_disc_shape"]))
								{
								?>
								<option><?php echo $fetchexam["os_optic_disc_shape"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $seldiscshape=mysqli_query($db,"select distinct discshape from prescription_analysis where discshape!=''");
							 while($rowdiscshape=mysqli_fetch_array($seldiscshape))
							 {
							?>
							<option><?php echo $rowdiscshape["discshape"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td>&nbsp;</td>
<td colspan="2">Colour</td>
<td colspan="6"><select name="od_disc_colour" class="form-control">
<?php 
								if(!empty($fetchexam["od_optic_disc_colour"]))
								{
								?>
								<option><?php echo $fetchexam["od_optic_disc_colour"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $seldisccolour=mysqli_query($db,"select distinct disccolour from prescription_analysis where disccolour!=''");
							 while($rowdisccolour=mysqli_fetch_array($seldisccolour))
							 {
							?>
							<option><?php echo $rowdisccolour["disccolour"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_disc_colour" class="form-control">
<?php 
								if(!empty($fetchexam["os_optic_disc_colour"]))
								{
								?>
								<option><?php echo $fetchexam["os_optic_disc_colour"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $seldisccolour=mysqli_query($db,"select distinct disccolour from prescription_analysis where disccolour!=''");
							 while($rowdisccolour=mysqli_fetch_array($seldisccolour))
							 {
							?>
							<option><?php echo $rowdisccolour["disccolour"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td>&nbsp;</td>
<td colspan="2">Margine</td>
<td colspan="6"><select name="od_disc_margine" class="form-control">
<?php 
								if(!empty($fetchexam["od_optic_disc_margine"]))
								{
								?>
								<option><?php echo $fetchexam["od_optic_disc_margine"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $seldiscmargine=mysqli_query($db,"select distinct discmargine from prescription_analysis where discmargine!=''");
							 while($rowdiscmargine=mysqli_fetch_array($seldiscmargine))
							 {
							?>
							<option><?php echo $rowdiscmargine["discmargine"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_disc_margine" class="form-control">
<?php 
								if(!empty($fetchexam["os_optic_disc_margine"]))
								{
								?>
								<option><?php echo $fetchexam["os_optic_disc_margine"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $seldiscmargine=mysqli_query($db,"select distinct discmargine from prescription_analysis where discmargine!=''");
							 while($rowdiscmargine=mysqli_fetch_array($seldiscmargine))
							 {
							?>
							<option><?php echo $rowdiscmargine["discmargine"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td colspan="3">C:D ratio</td>
<td colspan="6"><select name="od_cd_ratio" class="form-control">
<?php 
								if(!empty($fetchexam["od_cd_ratio"]))
								{
								?>
								<option><?php echo $fetchexam["od_cd_ratio"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selcdratio=mysqli_query($db,"select distinct cdratio from prescription_analysis where cdratio!=''");
							 while($rowcdratio=mysqli_fetch_array($selcdratio))
							 {
							?>
							<option><?php echo $rowcdratio["cdratio"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_cd_ratio" class="form-control">
<?php 
								if(!empty($fetchexam["os_cd_ratio"]))
								{
								?>
								<option><?php echo $fetchexam["os_cd_ratio"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selcdratio=mysqli_query($db,"select distinct cdratio from prescription_analysis where cdratio!=''");
							 while($rowcdratio=mysqli_fetch_array($selcdratio))
							 {
							?>
							<option><?php echo $rowcdratio["cdratio"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td colspan="3">Blood vessels</td>
<td colspan="6">&nbsp;</td>
<td colspan="6">&nbsp;</td>

</tr>
<tr>
<td>&nbsp;</td>
<td colspan="2">Disc</td>
<td colspan="6"><select name="od_bv_disc" class="form-control">
<?php 
								if(!empty($fetchexam["od_bv_over_disc"]))
								{
								?>
								<option><?php echo $fetchexam["od_bv_over_disc"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selbvdisc=mysqli_query($db,"select distinct bvdisc from prescription_analysis where bvdisc!=''");
							 while($rowbvdisc=mysqli_fetch_array($selbvdisc))
							 {
							?>
							<option><?php echo $rowbvdisc["bvdisc"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_bv_disc" class="form-control">
<?php 
								if(!empty($fetchexam["os_bv_over_disc"]))
								{
								?>
								<option><?php echo $fetchexam["os_bv_over_disc"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selbvdisc=mysqli_query($db,"select distinct bvdisc from prescription_analysis where bvdisc!=''");
							 while($rowbvdisc=mysqli_fetch_array($selbvdisc))
							 {
							?>
							<option><?php echo $rowbvdisc["bvdisc"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td>&nbsp;</td>
<td colspan="2">GF</td>
<td colspan="6"><select name="od_bv_gf" class="form-control">
<?php 
								if(!empty($fetchexam["od_bv_over_gf"]))
								{
								?>
								<option><?php echo $fetchexam["od_bv_over_gf"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selbvgf=mysqli_query($db,"select distinct bvgf from prescription_analysis where bvgf!=''");
							 while($rowbvgf=mysqli_fetch_array($selbvgf))
							 {
							?>
							<option><?php echo $rowbvgf["bvgf"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"> <select name="os_bv_gf" class="form-control">
<?php 
								if(!empty($fetchexam["os_bv_over_gf"]))
								{
								?>
								<option><?php echo $fetchexam["os_bv_over_gf"]; ?></option>
								<?php
								  }
									?>
							<?php
							 $selbvgf=mysqli_query($db,"select distinct bvgf from prescription_analysis where bvgf!=''");
							 while($rowbvgf=mysqli_fetch_array($selbvgf))
							 {
							?>
							<option><?php echo $rowbvgf["bvgf"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td>&nbsp;</td>
<td colspan="2">&nbsp;</td>
<td colspan="6">&nbsp;</td>
<td colspan="6">&nbsp;</td>

</tr>
<tr>
<td colspan="3">Macula</td>
<td colspan="6"><select id="od_maculasel" class="form-control" onchange="pushmacula_od()">
							<option value="">----Select----</option>
							<?php
							 $selmacula=mysqli_query($db,"select distinct macula from prescription_analysis where macula!=''");
							 while($rowmacula=mysqli_fetch_array($selmacula))
							 {
							?>
							<option><?php echo $rowmacula["macula"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select id="os_maculasel" class="form-control" onchange="pushmacula_os()">
							<option value="">----Select----</option>
							<?php
							 $selmacula=mysqli_query($db,"select distinct macula from prescription_analysis where macula!=''");
							 while($rowmacula=mysqli_fetch_array($selmacula))
							 {
							?>
							<option><?php echo $rowmacula["macula"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td colspan="3">&nbsp;</td>
<td colspan="6"><textarea name="od_macula" id="maculatxt_od" class="form-control" rows="10" cols="3" readonly><?php echo !empty($fetchexam["od_macula"])?$fetchexam["od_macula"]:"";?></textarea></td>
<td colspan="6"><textarea name="os_macula" id="maculatxt_os" class="form-control" rows="10" cols="3" readonly><?php echo !empty($fetchexam["os_macula"])?$fetchexam["os_macula"]:"";?></textarea></td>

</tr>
<tr>
<td colspan="3">General fundus</td>
<td colspan="6"><select id="od_gfsel" class="form-control" onchange="pushgf_od()">
							<option value="">----Select----</option>
							<?php
							 $selgf=mysqli_query($db,"select distinct gf from prescription_analysis where gf!=''");
							 while($rowgf=mysqli_fetch_array($selgf))
							 {
							?>
							<option><?php echo $rowgf["gf"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select id="os_gfsel" class="form-control" onchange="pushgf_os()">
							<option value="">----Select----</option>
							<?php
							 $selgf=mysqli_query($db,"select distinct gf from prescription_analysis where gf!=''");
							 while($rowgf=mysqli_fetch_array($selgf))
							 {
							?>
							<option><?php echo $rowgf["gf"];?></option>
							<?php
							 }
							 ?>
							 </select></td>

</tr>
<tr>
<td colspan="3">&nbsp;</td>
<td colspan="6"><textarea name="od_gf" id="gftxt_od" class="form-control" rows="10" cols="10" readonly><?php echo !empty($fetchexam["od_gf"])?$fetchexam["od_gf"]:"";?></textarea></td>
<td colspan="6"><textarea name="os_gf" id="gftxt_os" class="form-control" rows="10" cols="10" readonly><?php echo !empty($fetchexam["os_gf"])?$fetchexam["os_gf"]:"";?></textarea></td>

</tr>
<tr>
<td colspan="3">Special tests</td>
<td colspan="6">&nbsp;</td>
<td colspan="6">&nbsp;</td>

</tr>
<tr>
<td colspan="3">Syringing</td>
<td colspan="6"><input class = "form-control" type = "text" name = "od_syringing" value="<?php echo !empty($fetchexam["od_syringing"])?$fetchexam["od_syringing"]:"NAD";?>" placeholder="Syringing for OD"></td>
<td colspan="6"><input class = "form-control" type = "text" name = "os_syringing" value="<?php echo !empty($fetchexam["os_syringing"])?$fetchexam["os_syringing"]:"NAD";?>" placeholder="Syringing for OS"></td>

</tr>
<tr>
<td colspan="3">Shirmers test</td>
<td colspan="6"><input class = "form-control" type = "text"  name = "od_shirmers_test" value="<?php echo !empty($fetchexam["od_shirmers_test"])?$fetchexam["od_shirmers_test"]:"NAD";?>" placeholder="For OD"></td>
<td colspan="6"><input class = "form-control" type = "text" name = "os_shirmers_test" value="<?php echo !empty($fetchexam["os_shirmers_test"])?$fetchexam["os_shirmers_test"]:"NAD";?>" placeholder="For OS"></td>

</tr>
<tr>
<td colspan="3">Gonioscopy</td>
<td colspan="6"><input class = "form-control" type = "text" name = "od_gonioscopy" value="<?php echo !empty($fetchexam["od_gonioscopy"])?$fetchexam["od_gonioscopy"]:"NAD";?>" placeholder="For OD"></td>
<td colspan="6"><input class = "form-control" type = "text" name = "os_gonioscopy" value="<?php echo !empty($fetchexam["os_gonioscopy"])?$fetchexam["os_gonioscopy"]:"NAD";?>" placeholder="For OS"></td>

</tr>
<tr>
<td colspan="3">Photograph No.</td>
<td colspan="6"><input class = "form-control" type = "text" name = "od_phno" value="<?php echo !empty($fetchexam["od_photograph_num"])?$fetchexam["od_photograph_num"]:"";?>"></td>
<td colspan="6"><input class = "form-control" type = "text" name = "os_phno" value="<?php echo !empty($fetchexam["os_photograph_num"])?$fetchexam["os_photograph_num"]:"";?>"></td>

</tr>
						</tbody>
						</table>
						<br>
						<br>
						<?php 
						   if(mysqli_num_rows($selexam)==0)
						   {
						?>
						<input type="submit" name="submit" id="submit" class="btn btn-primary" value="Add">
						<?php 
						   }
						   else
						   {
						   ?>
						   <button  class = "btn btn-warning" name = "edit" id="edit" ><span class = "glyphicon glyphicon-edit"></span> SAVE</button>
						   <?php
						   }
						   ?>
					</form>
					<?php
					  if(isset($_POST["submit"]))
					  {
						  
						  	$od_unaided=mysqli_real_escape_string($db,$_POST["od_unaided_va"])." ".mysqli_real_escape_string($db,$_POST["od_unaided_nva"]);
							$od_old=mysqli_real_escape_string($db,$_POST["od_old_va"])." ".mysqli_real_escape_string($db,$_POST["od_old_nva"]);
							$od_phss=mysqli_real_escape_string($db,$_POST["od_phss_va"])." ".mysqli_real_escape_string($db,$_POST["od_phss_nva"]);
							$os_unaided=mysqli_real_escape_string($db,$_POST["os_unaided_va"])." ".mysqli_real_escape_string($db,$_POST["os_unaided_nva"]);
							$os_old=mysqli_real_escape_string($db,$_POST["os_old_va"])." ".mysqli_real_escape_string($db,$_POST["os_old_nva"]);
							$os_phss=mysqli_real_escape_string($db,$_POST["os_phss_va"])." ".mysqli_real_escape_string($db,$_POST["os_phss_nva"]);
							$od_pr=mysqli_real_escape_string($db,$_POST["od_pr"]);
							$os_pr=mysqli_real_escape_string($db,$_POST["os_pr"]);
							$uppersec=mysqli_real_escape_string($db,$_POST["uppersec"]);
							$od_sph=mysqli_real_escape_string($db,$_POST["od_sph"]);
							$od_cyl=mysqli_real_escape_string($db,$_POST["od_cyl"]);
							$od_axis=mysqli_real_escape_string($db,$_POST["od_axis"]);
							$od_va=mysqli_real_escape_string($db,$_POST["od_va"]);
							$od_comment=mysqli_real_escape_string($db,$_POST["od_comment"]);
							$od_add=mysqli_real_escape_string($db,$_POST["od_add"]);
							$od_nva=mysqli_real_escape_string($db,$_POST["od_nva"]);
							$os_sph=mysqli_real_escape_string($db,$_POST["os_sph"]);
							$os_cyl=mysqli_real_escape_string($db,$_POST["os_cyl"]);
							$os_axis=mysqli_real_escape_string($db,$_POST["os_axis"]);
							$os_va=mysqli_real_escape_string($db,$_POST["os_va"]);
							$os_comment=mysqli_real_escape_string($db,$_POST["os_comment"]);
							$os_add=mysqli_real_escape_string($db,$_POST["os_add"]);
							$os_nva=mysqli_real_escape_string($db,$_POST["os_nva"]);
							$ipd=mysqli_real_escape_string($db,$_POST["ipd"]);
							$head_posture=mysqli_real_escape_string($db,$_POST["head_posture"]);
							$od_forehead=mysqli_real_escape_string($db,$_POST["od_forehead"]);
							$od_orbit=mysqli_real_escape_string($db,$_POST["od_orbit"]);
							$od_eye_brows=mysqli_real_escape_string($db,$_POST["od_eyebrows"]);
							$od_eye_lids=mysqli_real_escape_string($db,$_POST["od_eye_lids"]);
							$od_position_eyelids=mysqli_real_escape_string($db,$_POST["od_eyelid_position"]);
							$od_skin_eyelids=mysqli_real_escape_string($db,$_POST["od_eyelid_skin"]);
							$od_margins_eyelids=mysqli_real_escape_string($db,$_POST["od_eyelid_margine"]);
							$od_lacrimal_app=mysqli_real_escape_string($db,$_POST["od_lacrimal_app"]);
							$od_eye_ball=mysqli_real_escape_string($db,$_POST["od_eye_ball"]);
							$od_moments_eyeball=mysqli_real_escape_string($db,$_POST["od_eyeball_moments"]);
							$od_conjunctiva=mysqli_real_escape_string($db,$_POST["od_conjunctiva"]);
							$od_pulpebral_conjunctiva=mysqli_real_escape_string($db,$_POST["od_pulpebral_conjunctiva"]);
							$od_bulbar_conjuctiva=mysqli_real_escape_string($db,$_POST["od_bulbar_conjunctiva"]);
							$od_cornea_size=mysqli_real_escape_string($db,$_POST["od_cornea_size"]);
							$od_cornea_surface=mysqli_real_escape_string($db,$_POST["od_cornea_surface"]);
							$od_transparency=mysqli_real_escape_string($db,$_POST["od_transparency"]);
							$od_stroma=mysqli_real_escape_string($db,$_POST["od_stroma"]);
							$od_endothelium=mysqli_real_escape_string($db,$_POST["od_endothelium"]);
							$od_accontant=mysqli_real_escape_string($db,$_POST["od_accontant"]);
							$od_acdepth=mysqli_real_escape_string($db,$_POST["od_acdepth"]);
							$od_iriscolour=mysqli_real_escape_string($db,$_POST["od_iriscolour"]);
							$od_irispattern=mysqli_real_escape_string($db,$_POST["od_irispattern"]);
							$od_pupilsize=mysqli_real_escape_string($db,$_POST["od_pupilsize"]);
							$od_pupilshape=mysqli_real_escape_string($db,$_POST["od_pupilshape"]);
							$od_pupilreaction=mysqli_real_escape_string($db,$_POST["od_pupilreaction"]);
							$od_lens=mysqli_real_escape_string($db,$_POST["od_lens"]);
							$od_lens_opacity=mysqli_real_escape_string($db,$_POST["od_lens_opacity"]);
							$od_iop=mysqli_real_escape_string($db,$_POST["od_IOP"]);
							$od_media=mysqli_real_escape_string($db,$_POST["od_media"]);
							$od_optic_disc=mysqli_real_escape_string($db,$_POST["od_optic_disc"]);
							$od_disc_size=mysqli_real_escape_string($db,$_POST["od_disc_size"]);
							$od_disc_shape=mysqli_real_escape_string($db,$_POST["od_disc_shape"]);
							$od_disc_colour=mysqli_real_escape_string($db,$_POST["od_disc_colour"]);
							$od_disc_margine=mysqli_real_escape_string($db,$_POST["od_disc_margine"]);
							$od_cd_ratio=mysqli_real_escape_string($db,$_POST["od_cd_ratio"]);
							$od_bv_disc=mysqli_real_escape_string($db,$_POST["od_bv_disc"]);
							$od_bv_gf=mysqli_real_escape_string($db,$_POST["od_bv_gf"]);
							$od_macula=mysqli_real_escape_string($db,$_POST["od_macula"]);
							$od_gf=mysqli_real_escape_string($db,$_POST["od_gf"]);
							$od_syringing=mysqli_real_escape_string($db,$_POST["od_syringing"]);
							$od_shirmers_test=mysqli_real_escape_string($db,$_POST["od_shirmers_test"]);
							$od_gonioscopy=mysqli_real_escape_string($db,$_POST["od_gonioscopy"]);
							$od_photograph_num=mysqli_real_escape_string($db,$_POST["od_phno"]);
							
							$os_forehead=mysqli_real_escape_string($db,$_POST["os_forehead"]);
							$os_orbit=mysqli_real_escape_string($db,$_POST["os_orbit"]);
							$os_eye_brows=mysqli_real_escape_string($db,$_POST["os_eyebrows"]);
							$os_eye_lids=mysqli_real_escape_string($db,$_POST["os_eye_lids"]);
							$os_position_eyelids=mysqli_real_escape_string($db,$_POST["os_eyelid_position"]);
							$os_skin_eyelids=mysqli_real_escape_string($db,$_POST["os_eyelid_skin"]);
							$os_margins_eyelids=mysqli_real_escape_string($db,$_POST["os_eyelid_margine"]);
							$os_lacrimal_app=mysqli_real_escape_string($db,$_POST["os_lacrimal_app"]);
							$os_eye_ball=mysqli_real_escape_string($db,$_POST["os_eye_ball"]);
							$os_moments_eyeball=mysqli_real_escape_string($db,$_POST["os_eyeball_moments"]);
							$os_conjunctiva=mysqli_real_escape_string($db,$_POST["os_conjunctiva"]);
							$os_pulpebral_conjunctiva=mysqli_real_escape_string($db,$_POST["os_pulpebral_conjunctiva"]);
							$os_bulbar_conjuctiva=mysqli_real_escape_string($db,$_POST["os_bulbar_conjunctiva"]);
							$os_cornea_size=mysqli_real_escape_string($db,$_POST["os_cornea_size"]);
							$os_cornea_surface=mysqli_real_escape_string($db,$_POST["os_cornea_surface"]);
							$os_transparency=mysqli_real_escape_string($db,$_POST["os_transparency"]);
							$os_stroma=mysqli_real_escape_string($db,$_POST["os_stroma"]);
							$os_endothelium=mysqli_real_escape_string($db,$_POST["os_endothelium"]);
							$os_accontant=mysqli_real_escape_string($db,$_POST["os_accontant"]);
							$os_acdepth=mysqli_real_escape_string($db,$_POST["os_acdepth"]);
							$os_iriscolour=mysqli_real_escape_string($db,$_POST["os_iriscolour"]);
							$os_irispattern=mysqli_real_escape_string($db,$_POST["os_irispattern"]);
							$os_pupilsize=mysqli_real_escape_string($db,$_POST["os_pupilsize"]);
							$os_pupilshape=mysqli_real_escape_string($db,$_POST["os_pupilshape"]);
							$os_pupilreaction=mysqli_real_escape_string($db,$_POST["os_pupilreaction"]);
							$os_lens=mysqli_real_escape_string($db,$_POST["os_lens"]);
							$os_lens_opacity=mysqli_real_escape_string($db,$_POST["os_lens_opacity"]);
							$os_iop=mysqli_real_escape_string($db,$_POST["os_IOP"]);
							$os_media=mysqli_real_escape_string($db,$_POST["os_media"]);
							$os_optic_disc=mysqli_real_escape_string($db,$_POST["os_optic_disc"]);
							$os_disc_size=mysqli_real_escape_string($db,$_POST["os_disc_size"]);
							$os_disc_shape=mysqli_real_escape_string($db,$_POST["os_disc_shape"]);
							$os_disc_colour=mysqli_real_escape_string($db,$_POST["os_disc_colour"]);
							$os_disc_margine=mysqli_real_escape_string($db,$_POST["os_disc_margine"]);
							$os_cd_ratio=mysqli_real_escape_string($db,$_POST["os_cd_ratio"]);
							$os_bv_disc=mysqli_real_escape_string($db,$_POST["os_bv_disc"]);
							$os_bv_gf=mysqli_real_escape_string($db,$_POST["os_bv_gf"]);
							$os_macula=mysqli_real_escape_string($db,$_POST["os_macula"]);
							$os_gf=mysqli_real_escape_string($db,$_POST["os_gf"]);
							$os_syringing=mysqli_real_escape_string($db,$_POST["os_syringing"]);
							$os_shirmers_test=mysqli_real_escape_string($db,$_POST["os_shirmers_test"]);
							$os_gonioscopy=mysqli_real_escape_string($db,$_POST["os_gonioscopy"]);
							$os_photograph_num=mysqli_real_escape_string($db,$_POST["os_phno"]);
							$od_fundus=mysqli_real_escape_string($db,$_POST["od_fundus"]);
							$os_fundus=mysqli_real_escape_string($db,$_POST["os_fundus"]);
							
						  $apid=mysqli_real_escape_string($db,$_POST['apid']); // appointments id
						  $pid=mysqli_real_escape_string($db,$_POST['pid']); // patient id
						  $insdate=date("Y-m-d");
					  $inssql=mysqli_query($db,"INSERT INTO `examination_temp` VALUES('','".$_POST['pid']."','".$_POST['apid']."','$uppersec','$od_unaided','$od_old','$od_phss','$os_unaided','$os_old','$os_phss','$od_pr','$os_pr','$od_sph','$od_cyl','$od_axis','$od_va','$od_comment','$od_add','$od_nva','$os_sph','$os_cyl','$os_axis','$os_va','$os_comment','$os_add','$os_nva','$ipd','$head_posture','$od_forehead','$od_orbit','$od_eye_brows','$od_eye_lids','$od_position_eyelids','$od_skin_eyelids','$od_margins_eyelids','$od_lacrimal_app','$od_eye_ball','$od_moments_eyeball','$od_conjunctiva','$od_pulpebral_conjunctiva','$od_bulbar_conjuctiva','$od_cornea_size','$od_cornea_surface','$od_transparency','$od_stroma','$od_endothelium','$od_accontant','$od_acdepth','$od_iriscolour','$od_irispattern','$od_pupilsize','$od_pupilshape','$od_pupilreaction','$od_lens','$od_lens_opacity','$od_iop','$od_media','$od_optic_disc','$od_disc_size','$od_disc_shape','$od_disc_colour','$od_disc_margine','$od_cd_ratio','$od_bv_disc','$od_bv_gf','$od_macula','$od_gf','$od_syringing','$od_shirmers_test','$od_gonioscopy','$od_photograph_num','$os_forehead','$os_orbit','$os_eye_brows','$os_eye_lids','$os_position_eyelids','$os_skin_eyelids','$os_margins_eyelids','$os_lacrimal_app','$os_eye_ball','$os_moments_eyeball','$os_conjunctiva','$os_pulpebral_conjunctiva','$os_bulbar_conjuctiva','$os_cornea_size','$os_cornea_surface','$os_transparency','$os_stroma','$os_endothelium','$os_accontant','$os_acdepth','$os_iriscolour','$os_irispattern','$os_pupilsize','$os_pupilshape','$os_pupilreaction','$os_lens','$os_lens_opacity','$os_iop','$os_media','$os_optic_disc','$os_disc_size','$os_disc_shape','$os_disc_colour','$os_disc_margine','$os_cd_ratio','$os_bv_disc','$os_bv_gf','$os_macula','$os_gf','$os_syringing','$os_shirmers_test','$os_gonioscopy','$os_photograph_num','$insdate','$od_fundus','$os_fundus')");
					  
					  if($inssql)
					  {
						  
						  echo "<script> window.location.href='examination_temp.php?apid=$apid' </script>";
					  }
					  }
					  elseif(isset($_POST["edit"]))
					  {
						  $od_unaided=mysqli_real_escape_string($db,$_POST["od_unaided_va"])." ".mysqli_real_escape_string($db,$_POST["od_unaided_nva"]);
							$od_old=mysqli_real_escape_string($db,$_POST["od_old_va"])." ".mysqli_real_escape_string($db,$_POST["od_old_nva"]);
							$od_phss=mysqli_real_escape_string($db,$_POST["od_phss_va"])." ".mysqli_real_escape_string($db,$_POST["od_phss_nva"]);
							$os_unaided=mysqli_real_escape_string($db,$_POST["os_unaided_va"])." ".mysqli_real_escape_string($db,$_POST["os_unaided_nva"]);
							$os_old=mysqli_real_escape_string($db,$_POST["os_old_va"])." ".mysqli_real_escape_string($db,$_POST["os_old_nva"]);
							$os_phss=mysqli_real_escape_string($db,$_POST["os_phss_va"])." ".mysqli_real_escape_string($db,$_POST["os_phss_nva"]);
							$od_pr=mysqli_real_escape_string($db,$_POST["od_pr"]);
							$os_pr=mysqli_real_escape_string($db,$_POST["os_pr"]);
							$uppersec=mysqli_real_escape_string($db,$_POST["uppersec"]);
							$od_sph=mysqli_real_escape_string($db,$_POST["od_sph"]);
							$od_cyl=mysqli_real_escape_string($db,$_POST["od_cyl"]);
							$od_axis=mysqli_real_escape_string($db,$_POST["od_axis"]);
							$od_va=mysqli_real_escape_string($db,$_POST["od_va"]);
							$od_comment=mysqli_real_escape_string($db,$_POST["od_comment"]);
							$od_add=mysqli_real_escape_string($db,$_POST["od_add"]);
							$od_nva=mysqli_real_escape_string($db,$_POST["od_nva"]);
							$os_sph=mysqli_real_escape_string($db,$_POST["os_sph"]);
							$os_cyl=mysqli_real_escape_string($db,$_POST["os_cyl"]);
							$os_axis=mysqli_real_escape_string($db,$_POST["os_axis"]);
							$os_va=mysqli_real_escape_string($db,$_POST["os_va"]);
							$os_comment=mysqli_real_escape_string($db,$_POST["os_comment"]);
							$os_add=mysqli_real_escape_string($db,$_POST["os_add"]);
							$os_nva=mysqli_real_escape_string($db,$_POST["os_nva"]);
							$ipd=mysqli_real_escape_string($db,$_POST["ipd"]);
							$head_posture=mysqli_real_escape_string($db,$_POST["head_posture"]);
							$od_forehead=mysqli_real_escape_string($db,$_POST["od_forehead"]);
							$od_orbit=mysqli_real_escape_string($db,$_POST["od_orbit"]);
							$od_eye_brows=mysqli_real_escape_string($db,$_POST["od_eyebrows"]);
							$od_eye_lids=mysqli_real_escape_string($db,$_POST["od_eye_lids"]);
							$od_position_eyelids=mysqli_real_escape_string($db,$_POST["od_eyelid_position"]);
							$od_skin_eyelids=mysqli_real_escape_string($db,$_POST["od_eyelid_skin"]);
							$od_margins_eyelids=mysqli_real_escape_string($db,$_POST["od_eyelid_margine"]);
							$od_lacrimal_app=mysqli_real_escape_string($db,$_POST["od_lacrimal_app"]);
							$od_eye_ball=mysqli_real_escape_string($db,$_POST["od_eye_ball"]);
							$od_moments_eyeball=mysqli_real_escape_string($db,$_POST["od_eyeball_moments"]);
							$od_conjunctiva=mysqli_real_escape_string($db,$_POST["od_conjunctiva"]);
							$od_pulpebral_conjunctiva=mysqli_real_escape_string($db,$_POST["od_pulpebral_conjunctiva"]);
							$od_bulbar_conjuctiva=mysqli_real_escape_string($db,$_POST["od_bulbar_conjunctiva"]);
							$od_cornea_size=mysqli_real_escape_string($db,$_POST["od_cornea_size"]);
							$od_cornea_surface=mysqli_real_escape_string($db,$_POST["od_cornea_surface"]);
							$od_transparency=mysqli_real_escape_string($db,$_POST["od_transparency"]);
							$od_stroma=mysqli_real_escape_string($db,$_POST["od_stroma"]);
							$od_endothelium=mysqli_real_escape_string($db,$_POST["od_endothelium"]);
							$od_accontant=mysqli_real_escape_string($db,$_POST["od_accontant"]);
							$od_acdepth=mysqli_real_escape_string($db,$_POST["od_acdepth"]);
							$od_iriscolour=mysqli_real_escape_string($db,$_POST["od_iriscolour"]);
							$od_irispattern=mysqli_real_escape_string($db,$_POST["od_irispattern"]);
							$od_pupilsize=mysqli_real_escape_string($db,$_POST["od_pupilsize"]);
							$od_pupilshape=mysqli_real_escape_string($db,$_POST["od_pupilshape"]);
							$od_pupilreaction=mysqli_real_escape_string($db,$_POST["od_pupilreaction"]);
							$od_lens_opacity=mysqli_real_escape_string($db,$_POST["od_lens_opacity"]);
							$od_lens=mysqli_real_escape_string($db,$_POST["od_lens"]);
							$od_iop=mysqli_real_escape_string($db,$_POST["od_IOP"]);
							$od_media=mysqli_real_escape_string($db,$_POST["od_media"]);
							$od_optic_disc=mysqli_real_escape_string($db,$_POST["od_optic_disc"]);
							$od_disc_size=mysqli_real_escape_string($db,$_POST["od_disc_size"]);
							$od_disc_shape=mysqli_real_escape_string($db,$_POST["od_disc_shape"]);
							$od_disc_colour=mysqli_real_escape_string($db,$_POST["od_disc_colour"]);
							$od_disc_margine=mysqli_real_escape_string($db,$_POST["od_disc_margine"]);
							$od_cd_ratio=mysqli_real_escape_string($db,$_POST["od_cd_ratio"]);
							$od_bv_disc=mysqli_real_escape_string($db,$_POST["od_bv_disc"]);
							$od_bv_gf=mysqli_real_escape_string($db,$_POST["od_bv_gf"]);
							$od_macula=mysqli_real_escape_string($db,$_POST["od_macula"]);
							$od_gf=mysqli_real_escape_string($db,$_POST["od_gf"]);
							$od_syringing=mysqli_real_escape_string($db,$_POST["od_syringing"]);
							$od_shirmers_test=mysqli_real_escape_string($db,$_POST["od_shirmers_test"]);
							$od_gonioscopy=mysqli_real_escape_string($db,$_POST["od_gonioscopy"]);
							$od_photograph_num=mysqli_real_escape_string($db,$_POST["od_phno"]);
							
							$os_forehead=mysqli_real_escape_string($db,$_POST["os_forehead"]);
							$os_orbit=mysqli_real_escape_string($db,$_POST["os_orbit"]);
							$os_eye_brows=mysqli_real_escape_string($db,$_POST["os_eyebrows"]);
							$os_eye_lids=mysqli_real_escape_string($db,$_POST["os_eye_lids"]);
							$os_position_eyelids=mysqli_real_escape_string($db,$_POST["os_eyelid_position"]);
							$os_skin_eyelids=mysqli_real_escape_string($db,$_POST["os_eyelid_skin"]);
							$os_margins_eyelids=mysqli_real_escape_string($db,$_POST["os_eyelid_margine"]);
							$os_lacrimal_app=mysqli_real_escape_string($db,$_POST["os_lacrimal_app"]);
							$os_eye_ball=mysqli_real_escape_string($db,$_POST["os_eye_ball"]);
							$os_moments_eyeball=mysqli_real_escape_string($db,$_POST["os_eyeball_moments"]);
							$os_conjunctiva=mysqli_real_escape_string($db,$_POST["os_conjunctiva"]);
							$os_pulpebral_conjunctiva=mysqli_real_escape_string($db,$_POST["os_pulpebral_conjunctiva"]);
							$os_bulbar_conjuctiva=mysqli_real_escape_string($db,$_POST["os_bulbar_conjunctiva"]);
							$os_cornea_size=mysqli_real_escape_string($db,$_POST["os_cornea_size"]);
							$os_cornea_surface=mysqli_real_escape_string($db,$_POST["os_cornea_surface"]);
							$os_transparency=mysqli_real_escape_string($db,$_POST["os_transparency"]);
							$os_stroma=mysqli_real_escape_string($db,$_POST["os_stroma"]);
							$os_endothelium=mysqli_real_escape_string($db,$_POST["os_endothelium"]);
							$os_accontant=mysqli_real_escape_string($db,$_POST["os_accontant"]);
							$os_acdepth=mysqli_real_escape_string($db,$_POST["os_acdepth"]);
							$os_iriscolour=mysqli_real_escape_string($db,$_POST["os_iriscolour"]);
							$os_irispattern=mysqli_real_escape_string($db,$_POST["os_irispattern"]);
							$os_pupilsize=mysqli_real_escape_string($db,$_POST["os_pupilsize"]);
							$os_pupilshape=mysqli_real_escape_string($db,$_POST["os_pupilshape"]);
							$os_pupilreaction=mysqli_real_escape_string($db,$_POST["os_pupilreaction"]);
							$os_lens=mysqli_real_escape_string($db,$_POST["os_lens"]);
							$os_lens_opacity=mysqli_real_escape_string($db,$_POST["os_lens_opacity"]);
							$os_iop=mysqli_real_escape_string($db,$_POST["os_IOP"]);
							$os_media=mysqli_real_escape_string($db,$_POST["os_media"]);
							$os_optic_disc=mysqli_real_escape_string($db,$_POST["os_optic_disc"]);
							$os_disc_size=mysqli_real_escape_string($db,$_POST["os_disc_size"]);
							$os_disc_shape=mysqli_real_escape_string($db,$_POST["os_disc_shape"]);
							$os_disc_colour=mysqli_real_escape_string($db,$_POST["os_disc_colour"]);
							$os_disc_margine=mysqli_real_escape_string($db,$_POST["os_disc_margine"]);
							$os_cd_ratio=mysqli_real_escape_string($db,$_POST["os_cd_ratio"]);
							$os_bv_disc=mysqli_real_escape_string($db,$_POST["os_bv_disc"]);
							$os_bv_gf=mysqli_real_escape_string($db,$_POST["os_bv_gf"]);
							$os_macula=mysqli_real_escape_string($db,$_POST["os_macula"]);
							$os_gf=mysqli_real_escape_string($db,$_POST["os_gf"]);
							$os_syringing=mysqli_real_escape_string($db,$_POST["os_syringing"]);
							$os_shirmers_test=mysqli_real_escape_string($db,$_POST["os_shirmers_test"]);
							$os_gonioscopy=mysqli_real_escape_string($db,$_POST["os_gonioscopy"]);
							$os_photograph_num=mysqli_real_escape_string($db,$_POST["os_phno"]);
							
						  $apid=mysqli_real_escape_string($db,$_POST['apid']); // appointments id
						  $pid=mysqli_real_escape_string($db,$_POST['pid']); // patient id
						  $insdate=date("Y-m-d");
						  $od_fundus=mysqli_real_escape_string($db,$_POST["od_fundus"]);
						  $os_fundus=mysqli_real_escape_string($db,$_POST["os_fundus"]);
						  $updsql=mysqli_query($db,"UPDATE `examination_temp` SET `uppersec`='$uppersec',`od_unaided`='$od_unaided',`od_old_spectacles`='$od_old',`od_ph_ss`='$od_phss',`os_unaided`='$os_unaided',`os_old_spectacles`='$os_old
						  ',`os_ph_ss`='$os_phss',`od_pr`='$od_pr',`os_pr`='$os_pr',`od_sph`='$od_sph',`od_cyl`='$od_cyl',`od_axis`='$od_axis',`od_va`='$od_va',`od_comment`='$od_comment',`od_add`='$od_add',`od_nva`='$od_nva',`os_sph`='$os_sph',`os_cyl`='$os_cyl',`os_axis`='$os_axis',`os_va`='$os_va',`os_comment`='$os_comment',`os_add`='$os_add',`os_nva`='$os_nva',`ipd`='$ipd',`head_posture`='$head_posture',`od_forehead`='$od_forehead',`od_orbit`='$od_orbit',`od_eye_brows`='$od_eye_brows',`od_eye_lids`='$od_eye_ball',`od_position_eyelids`='$od_position_eyelids',`od_skin_eyelids`='$od_skin_eyelids',`od_margins_eyelids`='$od_margins_eyelids',`od_lacrimal_app`='$od_lacrimal_app',`od_eye_ball`='$od_eye_ball',`od_moments_eyeball`='$od_moments_eyeball',`od_conjunctiva`='$od_conjunctiva',`od_pulpebral_conjunctiva`='$od_pulpebral_conjunctiva',`od_bulbar_conjunctiva`='$od_bulbar_conjuctiva',`od_size_cornea`='$od_cornea_size',`od_surface_cornea`='$od_cornea_surface',`od_transparency_cornea`='$od_transparency',`od_stroma_cornea`='$od_stroma',`od_endothelium_cornea`='$od_endothelium',`od_ac_contant`='$od_accontant',`od_ac_depth`='$od_acdepth',`od_iris_colour`='$od_iriscolour',`od_iris_pattern`='$od_irispattern',`od_pupil_size`='$od_pupilsize',`od_pupil_shape`='$od_pupilshape',`od_pupil_reaction`='$od_pupilreaction',`od_lens`='$od_lens',`od_lens_opacity`='$od_lens_opacity',`od_iop`='$od_iop',`od_media`='$od_media',`od_optic_disc`='$od_optic_disc',`od_optic_disc_size`='$od_disc_size',`od_optic_disc_shape`='$od_disc_shape',`od_optic_disc_colour`='$od_disc_colour',`od_optic_disc_margine`='$od_disc_margine',`od_cd_ratio`='$od_cd_ratio',`od_bv_over_disc`='$od_bv_disc',`od_bv_over_gf`='$od_bv_gf',`od_macula`='$od_macula',`od_gf`='$od_gf',`od_syringing`='$od_syringing',`od_shirmers_test`='$od_shirmers_test',`od_gonioscopy`='$od_gonioscopy',`od_photograph_num`='$od_photograph_num
						  ',`os_forehead`='$os_forehead',`os_orbit`='$os_orbit',`os_eye_brows`='$os_eye_brows',`os_eye_lids`='$os_eye_ball',`os_position_eyelids`='$os_position_eyelids',`os_skin_eyelids`='$os_skin_eyelids',`os_margins_eyelids`='$os_margins_eyelids',`os_lacrimal_app`='$os_lacrimal_app',`os_eye_ball`='$os_eye_ball',`os_moments_eyeball`='$os_moments_eyeball',`os_conjunctiva`='$os_conjunctiva',`os_pulpebral_conjunctiva`='$os_pulpebral_conjunctiva',`os_bulbar_conjunctiva`='$os_bulbar_conjuctiva',`os_size_cornea`='$os_cornea_size',`os_surface_cornea`='$os_cornea_surface',`os_transparency_cornea`='$os_transparency',`os_stroma_cornea`='$os_stroma',`os_endothelium_cornea`='$os_endothelium',`os_ac_contant`='$os_accontant',`os_ac_depth`='$os_acdepth',`os_iris_colour`='$os_iriscolour',`os_iris_pattern`='$os_irispattern',`os_pupil_size`='$os_pupilsize',`os_pupil_shape`='$os_pupilshape',`os_pupil_reaction`='$os_pupilreaction',`os_lens`='$os_lens',`os_lens_opacity`='$os_lens_opacity',`os_iop`='$os_iop',`os_media`='$os_media',`os_optic_disc`='$os_optic_disc',`os_optic_disc_size`='$os_disc_size',`os_optic_disc_shape`='$os_disc_shape',`os_optic_disc_colour`='$os_disc_colour',`os_optic_disc_margine`='$os_disc_margine',`os_cd_ratio`='$os_cd_ratio',`os_bv_over_disc`='$os_bv_disc',`os_bv_over_gf`='$os_bv_gf',`os_macula`='$os_macula',`os_gf`='$os_gf',`os_syringing`='$os_syringing',`os_shirmers_test`='$os_shirmers_test',`os_gonioscopy`='$os_gonioscopy',`os_photograph_num`='$os_photograph_num
						  ',`ins_date`='$insdate', `od_fundus`='$od_fundus', `os_fundus`='$os_fundus' WHERE pid='$pid' AND apid='$apid'");

						  if($updsql)
						  {
							  echo "<script> alert('Saved Successfully!') </script>";
							  echo "<script> window.location.href='examination_temp.php?apid=$apid' </script>";
						  }
					  }
					?>
			</div>
		</div>	
	<div id = "footer">
		<label class = "footer-title">&copy; Copyright EyeCare 2022</label>
	</div>
<?php require'script.php' ?>
<script type = "text/javascript">
    /*$(document).ready(function() {
		$("#submit").attr("disabled",true);
        function disableBack() { window.history.forward() }

        window.onload = disableBack();
        window.onpageshow = function(evt) { if (evt.persisted) disableBack() }
	});*/s
</script>
<script type = "text/javascript">
$("#uppersec").change(function(){
	$("#submit").attr("disabled",false);
})
</script>
<script type="text/javascript">
function pushmacula_od(){
	var e = document.getElementById("od_maculasel");
	var val = e.options[e.selectedIndex].text;
	var txt=document.getElementById("maculatxt_od").value;
	var n = txt.indexOf(val);
	if(n<0)
	{	
	document.getElementById("maculatxt_od").value += val + '\r\n';
	}
}
function pushmacula_os(){
	var e = document.getElementById("os_maculasel");
	var val = e.options[e.selectedIndex].text;
	var txt=document.getElementById("maculatxt_os").value;
	var n = txt.indexOf(val);
	if(n<0)
	{	
	document.getElementById("maculatxt_os").value += val + '\r\n';
	}
}
function pushgf_od(){
	var e = document.getElementById("od_gfsel");
	var val = e.options[e.selectedIndex].text;
	var txt=document.getElementById("gftxt_od").value;
	var n = txt.indexOf(val);
	if(n<0)
	{	
	document.getElementById("gftxt_od").value += val + '\r\n';
	}
}
function pushgf_os(){
	var e = document.getElementById("os_gfsel");
	var val = e.options[e.selectedIndex].text;
	var txt=document.getElementById("gftxt_os").value;
	var n = txt.indexOf(val);
	if(n<0)
	{	
	document.getElementById("gftxt_os").value += val + '\r\n';
	}
}
</script>
</body>
</html>