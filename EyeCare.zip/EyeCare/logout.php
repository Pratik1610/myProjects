<?php
	session_start();
	include "authentication.php";
	unset($_SESSION['user_id']);
	$del1=mysqli_query($db,"delete from advice_temp");
	$del2=mysqli_query($db,"delete from co_temp");
	$del3=mysqli_query($db,"delete from diagnosis_temp");
	$del4=mysqli_query($db,"delete from examination_temp");
	$del5=mysqli_query($db,"delete from followup_temp");
	$del6=mysqli_query($db,"delete from glasses_temp");
	$del7=mysqli_query($db,"delete from review_temp");
	$del8=mysqli_query($db,"delete from rx_temp");
	header("location:index.php");
?>