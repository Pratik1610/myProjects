var pmba_banner = window.location.href.split('?')[1];
$( document ).ready(function() {
	//pmba banner start
		var spl_banner = getUrlParameter('spl-banner');
		 if( spl_banner ){
				pmba_banner = 'spl-banner';
			}
			if( $('a#'+pmba_banner).length > 0 ){
				$('a#'+pmba_banner).get(0).click();
			}
	//pmba banner stop
	if( $('select#country_dropdown').length > 0 ){
		$('select#country_dropdown').select2({
			dropdownAutoWidth : true,
			allowClear: true,
			formatNoMatches: function(term){			
				return 'No country found';
			}
		}).on("change", function(e) {
			var parts = e.val.split('#');
			
			$('form #show_country_phone').html('+'+parts[0]);
			$('#s2id_country_dropdown .select2-chosen').html(parts[1]);
			$('form input[name="country_id"]').val(parts[2]);
		}).on("select2-close", function() {
			$('#s2id_country_dropdown.select2-container').removeClass('select2-container-active');
		/*}).on("select2-open", function() {
			var width = $('#modal_signup .multi_modal_right').width();
			$('#select2-drop').width(width);
		}).on("select2-loaded", function(e) {
			var width = $('#modal_signup .multi_modal_right').width();
			$('#select2-drop').width(width);
			*/
		});
		$('#s2id_country_dropdown .select2-chosen').html(country_code);
	}
	$('.modal#login').on('hidden.bs.modal',function(){
		$('.modal#login input#modal_param').val('no');
		document.getElementById("signin_modal").reset();
		$('.modal#login #signin_modal #messages').html('');
		document.getElementById("signup").reset();
		$('.modal#login #signup #signup_error').html('');
		document.getElementById("forget_password").reset();
		$('.modal#login #forget_password #invalid_id').html('');
		
		$('.modal#login [id^=modal_]').each(function(){
			if( !$(this).hasClass('hide') ) $(this).addClass('hide');
		});
		if( $('.modal#login #modal_forget').hasClass('hide') ) $('.modal#login #modal_forget').removeClass('hide');
		if( !$('.modal#login #forg_proc').hasClass('hide') )$('.modal#login #forg_proc').addClass('hide');
		$('.first_name_error').html('');
		$('.phone_error').html('');
		$('.email_error').html('');
		$('.pass_error').html('');
	});
	/*$(document).on("click","#first_name", function(){             
    	$('.first_name_error').html('Fill First Name');
	});*/
	$(document).on("click","#phn_no", function(){
	$('.first_name_error').html('');  
		if($('#first_name').val() == '' ){          
	    	$('.first_name_error').html('Please Enter First Name');
	    }
	});
	$(document).on("click","#email", function(){   
	$('.phone_error').html('');          
    	if($('#phn_no').val() == '' ){          
	    	$('.phone_error').html('Please Enter Phone Number');
	    }
	});
	$(document).on("click","#pass", function(){
	$('.email_error').html('');  
	$('.pass_error').html('');           
    	if($('#email').val() == '' ){          
	    	$('.email_error').html('Please Enter Email Address');
	    }
	});
		var frmR = $('#signup');
		var frm = $('#contactForm1');
		var frmP = $('#forget_password');
		var frmfeed = $('#feedback');
		frm.on('submit',function () {
			$.ajax({
				type: frm.attr('method'),
				url: url+frm.attr('action'),
				data: frm.serialize(),
				cache : false,
				success: function (responseText) {
					var obj = jQuery.parseJSON(responseText);
					if(obj.status == "Login_failed"){
						$('#message').html(obj.response);
					}else if(obj.status == "Success"){
						window.location.href = url+'home';
					}
				}
			});
			/*} else {
				$('#message').html('Email / password cannot be blank');
			}*/
			return false;
		});
		$('#signin_modal').on('submit',function(){
			var user_name = $('#username_m').val();
			var password = $('#password_m').val();
			var extra_banner = $('.modal#login input#modal_param').val();

			if( (user_name != '') && (password != '') ){
				if(extra_banner == 'spl-banner'){
					noty({
						layout: 'topCenter',
						modal: true,
						type:'information',
						text: 'Please wait....Our Support Team Will Contact You',
					});
				}else{
					noty({
						layout: 'topCenter',
						modal: true,
						type:'information',
						text: 'Please wait....',
					});
				}
				$.ajax({
					type: 'post',
					url: url+'verifylogin',
					cache : false,
					data: {'username': user_name,'password':password,'extra_param':$('.modal#login input#modal_param').val()},
					dataType: 'json',
					success: function (obj) {
						if(obj.status == "Login_failed"){
							$.noty.closeAll();
							$('#messages').html(obj.response);
						}else if(obj.status == "Success"){
							$.noty.closeAll();
							//_gaq.push(['_trackEvent', 'submit', 'login', 'user']); // For Analytics
							ga('send', 'event', 'submit', 'login', 'user'); // For Universal Analytics
							if( $.trim(obj.redirect_url) != '' ){
								window.location.href = $.trim(obj.redirect_url);
							} else {
								if( obj.extra_param == 'no' ){
									location.reload();
								}else if( obj.extra_param != 'no' ) {
									var loc = window.location.href;
									if(loc.indexOf("?") > -1 ){
										window.location.href = loc.split('#')[0] + "&"+obj.extra_param;
									} else {
										window.location.href = loc.split('#')[0] + "?"+obj.extra_param;
									}
								}
							}							
						}						
					}
				});
			} else {
				$('#messages').html('Email / password cannot be blank');
			}
			return false;
		});
		frmR.submit(function (ev) {	
			$(this).find('button[type="submit"]').attr('disabled',true);
			var send_ajax_request = 0;
			var email = $('#email').val();
			var pwd = $('#pass').val();
			var c_pwd = $('#password_confirmation').val();
			var extra_param=$('.modal#login input#modal_param').val();
			$('.first_name_error').html('');
			$('.email_error').html('');
			$('.pass_error').html('');
			if ($('#first_name').val() == ''){
				$('.first_name_error').html('Please Enter First Name');
			}else if(email == ''){
				$('.email_error').html('Please Enter Email Address');
			}else if(pwd == ''){
				$('.pass_error').html('Please Enter password');
			}
			//if( ($('#first_name').val() == '') || ($('#last_name').val() == '') || (email == '' ) || (pwd == '') ){
				//$('#signup_error').removeClass('hide').html('All fields are compulsory');
				//frmR.find('button[type="submit"]').attr('disabled',false);
			//} else if(pwd == c_pwd){
			//} 
			else {
				send_ajax_request = 1;
				if( extra_param == 'spl-banner') {
						noty({
						layout: 'topCenter',
						modal: true,
						type:'information',
						text: 'Please wait....Our Team Will Get in Touch With You',
					});	
				}else{
					noty({
						layout: 'topCenter',
						modal: true,
						type:'information',
						text: 'Please wait....',
					});
				}
				$.ajax({
					type: frmR.attr('method'),
					url: frmR.attr('action'),
					data: frmR.serialize()+'&extra_param='+$('.modal#login input#modal_param').val(),
					cache : false,
					dataType: 'json',
					success: function (responseText) {
						if(responseText.status == 'success'){
							var extra_url = '';
							extra_url = window.location.href.replace(url,'');

							if(extra_url == 'home') extra_url = '';

							if( responseText.message=='no' ){
								if( extra_url != '' ) extra_url = '/'+extra_url;
								window.location.href = url+'user_registered'+extra_url;
							} else if( responseText.message != 'no' ) {
								
								var loc = window.location.href;
								if(loc.indexOf("?") > -1 ){
									window.location.href = url+"user_registered/"+extra_url+'&'+responseText.message;
								} else {
									window.location.href = url+"user_registered/"+extra_url+'?'+responseText.message;
								}

							}
						}else{
							$.noty.closeAll();
							$('#signup_error').removeClass('hide').html(responseText.message);
							frmR.find('button[type="submit"]').attr('disabled',false);
						}
					}
				});
			/*}else{
				if(pwd != c_pwd ){
					$('#signup_error').removeClass('hide').html('Your password does not match');
					frmR.find('button[type="submit"]').attr('disabled',false);
				}*/
			}
			ev.preventDefault();
		});
		frmP.submit(function (ev) {
			$('.modal#login #modal_forget').addClass('hide');
			$('.modal#login #forg_proc').removeClass('hide');
			setTimeout(function(){
				$.ajax({
					type: frmP.attr('method'),
					url: frmP.attr('action'),
					data: frmP.serialize(),
					cache: false,
					async: true,
					success: function (responseText) {
						$('.modal#login #forg_proc').addClass('hide');
						if(responseText == 'success'){
							$("form#forget_password #username").val("");
							$('.modal#login #invalid_id').html('');
							$('.modal#login').modal('hide');
							noty({layout: 'topCenter',type:'success',text: 'Email is sent to reset your password.',timeout: default_timeout});
						} else {
							$('.modal#login #modal_forget').removeClass('hide');
							$('.modal#login #invalid_id').html("Please enter your valid emailid.");
						}
					}
				});
			},100);
			return false;
		});
		frmfeed.submit(function (ev) {
			$(".Feedback_display").toggle("slide");
			$.ajax({
				type: frmfeed.attr('method'),
				url: frmfeed.attr('action'),
				data: frmfeed.serialize(),
				cache : false,
				success: function (responseText) {
					if(responseText == 'success'){						
						$(".feedback_email").val("");
						$(".feedback_content").val("");
					}
				}
			});
			ev.preventDefault();
		});
		$('#aima_form').on('submit',function(){
			var name = $('#name').val();
			var emailid = $('#emailid').val();
			if( (name != '') && (emailid != '') ){
				noty({
					layout: 'topCenter',
					modal: true,
					type:'information',
					text: 'Please wait....',
				});
				$.ajax({
					type: 'post',
					url: url+'verifylogin/insert_aima',
					cache : false,
					data: {'name': name,'emailid':emailid},
					dataType: 'json',
					success: function (obj) {
						if(obj.success){
							$.noty.closeAll();
							$("#aima").modal("hide");
							//window.location.href = url+'apnadata/aima/AIMA_PGDM_2.0.pdf';
						window.open(
  							//url+'apnadata/aima/AIMA_PGDM_2.0.pdf',
  							'https://pgcourses.aima.in/pgdm-v2.php',
  							'_blank' // <- This is what makes it open in a new window.
						);

						}
												
					}
				});
			} else {
				$('#messages').html('Name / Email Address cannot be blank');
			}
			return false;
		});

		$('#nmims_form').on('submit',function(){
			var name = $('#nmims_name').val();
			var emailid = $('#nmims_emailid').val();
			var phone = $('#nmims_phone').val();
			if( (name != '') && (emailid != '') ){
				noty({
					layout: 'topCenter',
					modal: true,
					type:'information',
					text: 'Please wait....',
				});
				$.ajax({
					type: 'post',
					url: url+'verifylogin/insert_nmims',
					cache : false,
					data: {'name': name,'emailid':emailid,'phone':phone},
					dataType: 'json',
					success: function (obj) {
						if(obj.success){
							$.noty.closeAll();
							$("#nmims").modal("hide");
							//window.location.href = url+'apnadata/aima/AIMA_PGDM_2.0.pdf';
						window.open(
  							//url+'apnadata/aima/AIMA_PGDM_2.0.pdf',
  							'http://www.knowledgepark.co.in/',
  							'_blank' // <- This is what makes it open in a new window.
						);

						}
												
					}
				});
			} else {
				$('#messages').html('Name / Email Address cannot be blank');
			}
			return false;
		});
});
function multi_modal(param,extra_param){
	if (typeof extra_param === "undefined" || extra_param === null) {
		if( typeof $('.modal#login input#modal_param').val() === "undefined" )
			extra_param = 'no';
		else
			extra_param = $('.modal#login input#modal_param').val();
	}	
	$('.modal#login [id^=modal_]').each(function(){
		if( param == $(this).attr('id').split('_')[1] ){
			$(this).removeClass('hide');
		} else {
			if( !$(this).hasClass('hide') ) $(this).addClass('hide');
		}
	});
	if( (extra_param != 'no') && (extra_param != '') ){
		if( $('input[name="duration_option"]').length > 0 ) $('.modal#login input#modal_param').val($('input[name="duration_option"]:checked').val());
		else $('.modal#login input#modal_param').val(extra_param);
	} else {
		$('.modal#login input#modal_param').val(extra_param);
	}

	$('.modal#login').modal('show');
}
function select_country(selected){
	var code = selected.data('code');
	var phone_code = selected.data('phone-code');
	$('#show_country_phone').html('+9'+phone_code);
}