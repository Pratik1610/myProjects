$("#all_course_homesearch").click(function(){
$("#all_course_search").val("");
$("#sncontent").html("");
})

$("#all_course_search").click(function(){
$("#all_course_homesearch").val("");
$("#scontent").html("");
})