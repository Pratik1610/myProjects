<?php
	session_start();
	if(ISSET($_POST['login'])){
		$username = $_POST['username'];
		$password = $_POST['password'];
		$role = $_POST['role'];
		$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
		if($role=="Doctor")
		{
		$query = $conn->query("SELECT * FROM `user` WHERE `username` = '$username' && `password` = '$password'") or die(mysqli_error());
		$fetch = $query->fetch_array();
		$valid = $query->num_rows;
			if($valid > 0){
				$_SESSION['user_id'] = $fetch['user_id'];
				echo "<script>window.location = 'home.php'</script>";
			}else{
				echo "<script>alert('Account Does Not Exist!')</script>";
				echo "<script>window.location = 'index.php'</script>";
			}
			
		}
		elseif($role=="Receptionist")
		{
			echo "<script>window.location = 'receptionist/login.php?username=$username&password=$password';</script>";
		}
		elseif($role=="Admin")
		{
			echo "<script>window.location = 'admin/login.php?username=$username&password=$password';</script>";
		}				
		
		}
		$conn->close();
		?>
	