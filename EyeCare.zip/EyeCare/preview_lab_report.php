<!DOCTYPE html>
<?php
 @$timezone=$_SESSION["timezone"];

 @date_default_timezone_set("$timezone");
	require_once 'logincheck.php';
	require_once 'authentication.php';
	$date = date("Y", strtotime("+ 8 HOURS"));
	$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
	
	$pid=$_GET["pid"];
	$refs=$_SERVER["HTTP_REFERER"];
?>
<html lang = "eng">
	<head>
		<title>EyeCare</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!--<link rel = "shortcut icon" href = "../images/eye-gb51ecb13e_1280.PNG" />-->
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/customize.css" />
		<?php require 'script.php'?>
		 <style>
    .invoice-box {
        max-width: 800px;
        margin: auto;
        padding: 30px;
        border: 1px solid #eee;
        box-shadow: 0 0 10px rgba(0, 0, 0, .15);
        font-size: 16px;
        line-height: 24px;
        font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
        color: #555;
    }
    
    .invoice-box table {
        width: 100%;
        line-height: inherit;
        text-align: left;
    }
    
    .invoice-box table td {
        padding: 5px;
        vertical-align: top;
		
    }
    
    .invoice-box table tr td:nth-child(2) {
        text-align: right;
    }
    
    .invoice-box table tr.top table td {
        padding-bottom: 20px;
    }
    
    .invoice-box table tr.top table td.title {
        font-size: 45px;
        line-height: 45px;
        color: #333;
    }
    
    .invoice-box table tr.information table td {
        padding-bottom: 40px;
    }
    
    .invoice-box table tr.heading td {
        background: #eee;
        border-bottom: 1px solid #ddd;
        font-weight: bold;
    }
    
    .invoice-box table tr.details td {
        padding-bottom: 20px;
    }
    
    .invoice-box table tr.item td{
        border-bottom: 1px solid #eee;
    }
    
    .invoice-box table tr.item.last td {
        border-bottom: none;
    }
    
    .invoice-box table tr.total td:nth-child(2) {
        border-top: 2px solid #eee;
        font-weight: bold;
    }
    
    @media only screen and (max-width: 600px) {
        .invoice-box table tr.top table td {
            width: 100%;
            display: block;
            text-align: center;
        }
        
        .invoice-box table tr.information table td {
            width: 100%;
            display: block;
            text-align: center;
        }
    }
    
    /** RTL **/
    .rtl {
        direction: rtl;
        font-family: Tahoma, 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
    }
    
    .rtl table {
        text-align: right;
    }
    
    .rtl table tr td:nth-child(2) {
        text-align: left;
    }
	#doPrint{
		padding:5px;
		background:#1e38b7;
		color:white;
		border:1px solid black;
		cursor:pointer;
	}
    </style>
	</head>
<body>
	<div class = "navbar navbar-default navbar-fixed-top">
		<img src = "images/eye-gb51ecb13e_1280.PNG" style = "float:left;" height = "55px" /><label class = "navbar-brand">EyeCare</label>
		<?php 
			$q = $conn->query("SELECT * FROM `user` WHERE `user_id` = $_SESSION[user_id]") or die(mysqli_error());
			$f = $q->fetch_array();
		?>
			<ul class = "nav navbar-nav navbar-right">	
			    <li><a href="home.php" style="color:#fff; font-size:16px;"><span class = "glyphicon glyphicon-hand-left"></span> Back to the dashboard</a></li>
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#" style="color:white;">
						<span class = "glyphicon glyphicon-user"></span>
						<?php 
							echo $f['firstname']." ".$f["middlename"]." ".$f['lastname'];
						?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
					<li>
						<a class = "me" href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
	</div>
		<br />
		<br />
		<br />
		<div class = "well">
		<div class="panel-heading panel-success">
		<h2 class="text-center">Lab Report : <?php echo date("d-m-Y",strtotime($_GET["redate"]));?></h2>
		   <button id="doPrint"><span class = "glyphicon glyphicon-print"></span> Click here to print</button>
		   <a href="<?php echo $refs;?>" class="btn btn-info"><span class = "glyphicon glyphicon-hand-left"></span> &nbsp;Back</a>
		   
		</div>
			<div id="chartContainer" style="width: 100%; height: 700px; overflow-y:scroll; background:white;">
			   	<?php 
					$sellab=mysqli_query($db,"select * from lab_report where patient_id='$pid' and report_date='".$_GET["redate"]."' order by id desc limit 1");
					$fetchlab=mysqli_fetch_array($sellab);
				?>
			<p style="text-align: center;"><span style="color: #ff0000;"><strong>Clinic name with address</strong></span></p>
			<table width="384">
			<tbody>
			<tr>
			<td colspan="3" width="192">LAB REPORTS</td>
			<td width="64">Date-</td>
			<td colspan="2" width="128"><?php echo date("d/m/Y",strtotime($fetchlab["report_date"]));?></td>
			</tr>
			<tr>
			<td>&nbsp;</td>
			<td width="64">Hb-</td>
			<td width="64"><?php echo $fetchlab["HB"];?></td>
			<td width="64">TLC-</td>
			<td width="64"><?php echo $fetchlab["tlc"];?></td>
			<td>&nbsp;</td>
			</tr>
			<tr>
			<td>&nbsp;</td>
			<td width="64">N-</td>
			<td><?php echo $fetchlab["N"];?></td>
			<td width="64">E-</td>
			<td><?php echo $fetchlab["E"];?></td>
			<td>&nbsp;</td>
			</tr>
			<tr>
			<td>&nbsp;</td>
			<td width="64">M-</td>
			<td width="64"><?php echo $fetchlab["M"];?></td>
			<td width="64">B-</td>
			<td width="64"><?php echo $fetchlab["B"];?></td>
			<td>&nbsp;</td>
			</tr>
			<tr>
			<td>&nbsp;</td>
			<td width="64">Sug F-</td>
			<td width="64"><?php echo $fetchlab["sug_f"];?></td>
			<td width="64">PP-</td>
			<td width="64"><?php echo $fetchlab["PP"];?></td>
			<td>&nbsp;</td>
			</tr>
			<tr>
			<td>&nbsp;</td>
			<td width="64">ESR</td>
			<td width="64"><?php echo $fetchlab["ESR"];?></td>
			<td width="64">RA</td>
			<td width="64"><?php echo $fetchlab["RA"];?></td>
			<td>&nbsp;</td>
			</tr>
			<tr>
			<td>&nbsp;</td>
			<td width="64">Culture-</td>
			<td colspan="3" width="192"><?php echo $fetchlab["culture"];?></td>
			<td>&nbsp;</td>
			</tr>
			<tr>
			<td>&nbsp;</td>
			<td width="64">X ray-</td>
			<td colspan="3" width="192"><?php echo $fetchlab["x_ray"];?></td>
			<td>&nbsp;</td>
			</tr>
			<tr>
			<td>&nbsp;</td>
			<td width="64">USG</td>
			<td colspan="3" width="192"><?php echo $fetchlab["USG"];?></td>
			<td>&nbsp;</td>
			</tr>
			<tr>
			<td>&nbsp;</td>
			<td>Others</td>
			<td colspan="3" width="192"><?php echo $fetchlab["others"];?></td>
			<td>&nbsp;</td>
			</tr>
			</tbody>
			</table>
		<p><strong>&nbsp;</strong></p>
			</div> 
		</div>
	<div id = "footer" style="margin-top:200px !important;">
		<label class = "footer-title">&copy; Copyright EyeCare 2022</label>
	</div>
	<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.12.1.min.js"></script>
<script type="text/javascript" src="js/popper.min.js"></script>
<script type="text/javascript" src="js/bootstrap-v4.3.1.min.js"></script>
<script type="text/javascript" src="js/jquery.form.js"></script>
<script type="text/javascript" src="js/jquery.timeago.js"></script>
<script type="text/javascript" src="js/jstz.min.js"></script>
<script type="text/javascript" src="js/script.js?v=80.0"></script>
<script type="text/javascript" src="js/jquery.autosize.min.js"></script>
<script type="text/javascript" src="js/jquery.noty.packaged.min.js"></script>
<script type="text/javascript" src="js/star-rating.min.js"></script>
<script type="text/javascript" src="js/jquery.timeago.js"></script>
<script type="text/javascript" src="js/chat.js?v=80.0"></script>
<script type="text/javascript" src="js/select2.js?v=80.0"></script>
<script type="text/javascript" src="js/login_old.js?v=80.0"></script>

	
	<script>
		document.getElementById("doPrint").addEventListener("click", function() {
     var printContents = document.getElementById('chartContainer').innerHTML;
     var originalContents = document.body.innerHTML;
     document.body.innerHTML = printContents;
     window.print();
     document.body.innerHTML = originalContents;
});
	</script>
</body>
</html>