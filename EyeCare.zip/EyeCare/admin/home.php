<!DOCTYPE html>
<?php
 @$timezone=$_SESSION["timezone"];

 @date_default_timezone_set("Asia/Kolakata");
	require_once 'logincheck.php';
	require_once 'authentication.php';
	$date = date("Y", strtotime("+ 8 HOURS"));
	$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
	
	$cur=date('m/d/Y');
?>
<html lang = "eng">
	<head>
		<title>EyeCare</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!--<link rel = "shortcut icon" href = "../images/eye-gb51ecb13e_1280.PNG" />-->
		<link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/customize.css" />
		<link rel="stylesheet" href="../receptionist/dist/css/AdminLTE.min.css">
		 <link rel="stylesheet" href="../receptionist/bower_components/font-awesome/css/font-awesome.min.css">
		  <!-- Ionicons -->
		  <link rel="stylesheet" href="../receptionist/bower_components/Ionicons/css/ionicons.min.css">
		  <!-- jvectormap -->
		  <link rel="stylesheet" href="../receptionist/bower_components/jvectormap/jquery-jvectormap.css">
		<?php require 'script.php'?>
		<style>
		  .dot {
			  height: 25px;
			  width: 25px;
			  background-color: rgb(34,139,34);
			  border-radius: 50%;
			  display: inline-block;
			}
		</style>
	</head>
<body>
	<div class = "navbar navbar-default navbar-fixed-top">
		<img src = "../images/eye-gb51ecb13e_1280.PNG" style = "float:left;" height = "55px" /><label class = "navbar-brand">EyeCare</label>
		<?php 
			$q = $conn->query("SELECT * FROM `admin` WHERE `admin_id` = $_SESSION[admin_id]") or die(mysqli_error());
			$f = $q->fetch_array();
		?>
			<ul class = "nav navbar-right">	
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#">
						<span class = "glyphicon glyphicon-user"></span>
						<?php 
							echo $f['firstname']." ".$f['middlename']." ".$f['lastname'];
						?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
					<li>
						<a class = "me" href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
	</div>
	<br>
	<br>
	<br>
	<br>
				<div class="row">
					<div class="col-lg-12">
					  <div class="info-box">
						<span class="info-box-icon bg-aqua"><i class="fa fa-pencil" aria-hidden="true"></i></span>

						<div class="info-box-content">
						  <span class="info-box-text">Doctor Account</span>
						  <span class="info-box-number"><small><a href="user.php">Click Here</a></small></span>
						</div>
						<!-- /.info-box-content -->
					  </div>
					  <!-- /.info-box -->
					</div>

					<!-- fix for small devices only -->
					<div class="clearfix visible-sm-block"></div>

					<!-- /.col -->
					<!-- /.col -->
					<div class="col-lg-12">
					  <div class="info-box">
						<span class="info-box-icon bg-aqua"><i class="fa fa-pencil" aria-hidden="true"></i></span>

						<div class="info-box-content">
						  <span class="info-box-text">Receptionist Account</span>
						  <span class="info-box-number"><small><a href="admin.php">Click Here</a></small></span>
						</div>
						<!-- /.info-box-content -->
					  </div>
					  <!-- /.info-box -->
					  
					  
					</div>
					<!-- /.col -->
					
					<!-- fix for small devices only -->
					<div class="clearfix visible-sm-block"></div>

					<!-- /.col -->
					<!-- /.col -->
					<!--<div class="col-lg-12">
					  <div class="info-box">
						<span class="info-box-icon bg-yellow"><i class="fa fa-folder" aria-hidden="true"></i></span>

						<div class="info-box-content">
						  <span class="info-box-text">Import Prescription</span>
						  <span class="info-box-number"><small><a href="upload_prescription.php">Click Here</a></small></span>
						</div>-->
						<!-- /.info-box-content -->
					  <!--</div>-->
					  <!-- /.info-box -->
					  
					  
					<!--</div>-->
					<!-- /.col -->
				  </div>
	<div id = "footer" style="margin-top:200px !important;">
		<label class = "footer-title">&copy; Copyright EyeCare 2022</label>
	</div>
	<script type="text/javascript" src="../js/jquery.js"></script>
<script type="text/javascript" src="../js/jquery-ui-1.12.1.min.js"></script>
<script type="text/javascript" src="../js/popper.min.js"></script>
<script type="text/javascript" src="../js/bootstrap-v4.3.1.min.js"></script>
<script type="text/javascript" src="../js/jquery.form.js"></script>
<script type="text/javascript" src="../js/jquery.timeago.js"></script>
<script type="text/javascript" src="../js/jstz.min.js"></script>
<script type="text/javascript" src="../js/script.js?v=80.0"></script>
<script type="text/javascript" src="../js/jquery.autosize.min.js"></script>
<script type="text/javascript" src="../js/jquery.noty.packaged.min.js"></script>
<script type="text/javascript" src="../js/star-rating.min.js"></script>
<script type="text/javascript" src="../js/jquery.timeago.js"></script>
<script type="text/javascript" src="../js/chat.js?v=80.0"></script>
<script type="text/javascript" src="../js/select2.js?v=80.0"></script>
<script type="text/javascript" src="../js/login_old.js?v=80.0"></script>
</body>
</html>