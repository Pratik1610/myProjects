  <footer class="main-footer">
    <div class="pull-right hidden-xs">
    </div>
    <strong>All Rights
    Reserved.</strong>
  </footer>