<!DOCTYPE html>
<?php
    ob_start();
	require_once 'logincheck.php';
?>
<html lang = "eng">
	<head>
		<title>EyeCare</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "shortcut icon" href = "../images/eye-gb51ecb13e_1280.PNG" />
		<link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/customize.css" />
	</head>
<body>
	<div class = "navbar navbar-default navbar-fixed-top">
		<img src = "../images/eye-gb51ecb13e_1280.PNG" style = "float:left;" height = "55px" /><label class = "navbar-brand">EyeCare</label>
			<?php
				$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
				$q = $conn->query("SELECT * FROM `admin` WHERE `admin_id` = '$_SESSION[admin_id]'") or die(mysqli_error());
				$f = $q->fetch_array();
			?>
			<ul class = "nav navbar-nav navbar-right">	
			    <li><a href="home.php" style="color:#fff; font-size:16px;"><span class = "glyphicon glyphicon-hand-left"></span> Back to the dashboard</a></li>
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#" style="color:#fff;">
						<span class = "glyphicon glyphicon-user"></span>
						<?php
							echo $f['firstname']." ".$f['lastname'];
							$conn->close();
						?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
					<li>
						<a class = "me" href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
	</div>
		<br />
		<br />
		<br />
		<div class = "panel panel-success">	
			<div class = "panel-heading">
				<label>Import Prescription</label>
			</div>
			<div class = "panel-body">
				<form action=""  method = "POST" enctype = "multipart/form-data" >
					<div class = "panel panel-default" style = "width:60%; margin:auto;">
					<div class = "panel-heading">
					   <label>Browse Excel files:</label>
					</div>
					<div class = "panel-body">
						<div class = "form-group">
							<input class = "form-control" name = "doc_prescription" type = "file" required = "required">
						</div>
							<button  class = "btn btn-primary" name = "save_doc" ><span class = "glyphicon glyphicon-cloud"></span> Upload</button>
							<br />
					</div>			
					</div>
				</form>
				<?php 
							if(isset($_REQUEST["save_doc"]))
							{
								$target_dir = "temp_docs/";
								$target_file = $target_dir . basename($_FILES["doc_prescription"]["name"]);
								$filename=$_FILES["doc_prescription"]["name"];
								$ext = pathinfo($filename, PATHINFO_EXTENSION);
								if($ext!=='xlsx'&&$ext!=='csv')
								{
								echo "<script> alert('Please select excel file(i.e. csv or xlsx) to upload!') </script>";
								}
								else
								{
									if(move_uploaded_file($_FILES["doc_prescription"]["tmp_name"], $target_file))
									{
										// import excel file to the database
											require_once "../Classes/PHPExcel.php";
											require_once "authentication.php";
											$path="$target_file";
											$reader= PHPExcel_IOFactory::createReaderForFile($path);
											$excel_Obj = $reader->load($path);

											//Get the last sheet in excel
											//$worksheet=$excel_Obj->getActiveSheet();
											
											// count the total worksheets
											$sheetCount = $excel_Obj->getSheetCount();
											
											for($i=0;$i<$sheetCount;$i++)
											{
											//Get the first sheet in excel
											$worksheet=$excel_Obj->getSheet($i);
											$title=$worksheet->getCell('A1')->getValue();
											$name=$worksheet->getCell('B1')->getValue();
											$nameexp=explode(" ",$name);
											if(count($nameexp)==1)
											{
												@$firstname=$nameexp[0];
												@$middlename="";
												@$lastname="";
											}
											elseif(count($nameexp)==2)
											{
												@$firstname=$nameexp[0];
												@$lastname=$nameexp[1];
												@$middlename="";
											}
											elseif(count($nameexp)==3)
											{
												@$firstname=$nameexp[0];
												@$middlename=$nameexp[1];
												@$lastname=$nameexp[2];
											}
											$co=$worksheet->getCell('A3')->getValue()." ".$worksheet->getCell('D3')->getValue()." ".$worksheet->getCell('E3')->getValue()." ".$worksheet->getCell('F3')->getValue();
											$co.="<br>".$worksheet->getCell('A4')->getValue()." ".$worksheet->getCell('D4')->getValue()." ".$worksheet->getCell('E4')->getValue()." ".$worksheet->getCell('F4')->getValue();
											$co.="<br>".$worksheet->getCell('A5')->getValue()." ".$worksheet->getCell('D5')->getValue()." ".$worksheet->getCell('E5')->getValue()." ".$worksheet->getCell('F5')->getValue();
											$age=$worksheet->getCell('G1')->getValue();
											preg_match_all('!\d+!', $age, $matches); // extract only digits from a given string
											$age = implode(' ', $matches[0]);
											$gender=$worksheet->getCell('H1')->getValue();
											// Getting date value from excel
											$cell = $worksheet->getCell('I1');
											$pres_date= $cell->getValue();
											if(PHPExcel_Shared_Date::isDateTime($cell)) {
												 $pres_date = date($format = "Y-m-d", PHPExcel_Shared_Date::ExcelToPHP($pres_date)); 
											}
											$contact=$worksheet->getCell('N1')->getValue();
											$address=$worksheet->getCell('M2')->getValue()." ".$worksheet->getCell('L3')->getValue()." ".$worksheet->getCell('L4')->getValue()." ".$worksheet->getCell('L5')->getValue()." ".$worksheet->getCell('L6')->getValue();
											$eye=$worksheet->getCell('A8')->getValue()."<br>".$worksheet->getCell('A9')->getValue()."<br>".$worksheet->getCell('F8')->getValue()."<br>".$worksheet->getCell('F9')->getValue();
											$diagnosis=$worksheet->getCell('B8')->getValue()."<br>".$worksheet->getCell('B9')->getValue()."<br>".$worksheet->getCell('G8')->getValue()."<br>".$worksheet->getCell('G9')->getValue();
											$drug=$worksheet->getCell('C11')->getValue()."<br>".$worksheet->getCell('C12')->getValue()."<br>".$worksheet->getCell('C13')->getValue()."<br>".$worksheet->getCell('C14')->getValue()."<br>".$worksheet->getCell('C15')->getValue()."<br>".$worksheet->getCell('C16')->getValue()."<br>".$worksheet->getCell('C17')->getValue()."<br>".$worksheet->getCell('C18')->getValue()."<br>".$worksheet->getCell('C19')->getValue()."<br>".$worksheet->getCell('C20')->getValue()."<br>".$worksheet->getCell('C21')->getValue()."<br>".$worksheet->getCell('C22')->getValue();
											$frequency=$worksheet->getCell('F11')->getValue()."<br>".$worksheet->getCell('F12')->getValue()."<br>".$worksheet->getCell('F13')->getValue()."<br>".$worksheet->getCell('F14')->getValue()."<br>".$worksheet->getCell('F15')->getValue()."<br>".$worksheet->getCell('F16')->getValue()."<br>".$worksheet->getCell('F17')->getValue()."<br>".$worksheet->getCell('F18')->getValue()."<br>".$worksheet->getCell('F19')->getValue()."<br>".$worksheet->getCell('F20')->getValue()."<br>".$worksheet->getCell('F21')->getValue()."<br>".$worksheet->getCell('F22')->getValue();
											$duration=$worksheet->getCell('H11')->getValue()."<br>".$worksheet->getCell('H12')->getValue()."<br>".$worksheet->getCell('H13')->getValue()."<br>".$worksheet->getCell('H14')->getValue()."<br>".$worksheet->getCell('H15')->getValue()."<br>".$worksheet->getCell('H16')->getValue()."<br>".$worksheet->getCell('H17')->getValue()."<br>".$worksheet->getCell('H18')->getValue()."<br>".$worksheet->getCell('H19')->getValue()."<br>".$worksheet->getCell('H20')->getValue()."<br>".$worksheet->getCell('H21')->getValue()."<br>".$worksheet->getCell('H22')->getValue();
											$deye=$worksheet->getCell('I11')->getValue()."<br>".$worksheet->getCell('I12')->getValue()."<br>".$worksheet->getCell('I13')->getValue()."<br>".$worksheet->getCell('I14')->getValue()."<br>".$worksheet->getCell('I15')->getValue()."<br>".$worksheet->getCell('I16')->getValue()."<br>".$worksheet->getCell('I17')->getValue()."<br>".$worksheet->getCell('I18')->getValue()."<br>".$worksheet->getCell('I19')->getValue()."<br>".$worksheet->getCell('I20')->getValue()."<br>".$worksheet->getCell('I21')->getValue()."<br>".$worksheet->getCell('I22')->getValue();
											$followup_date=$worksheet->getCell('K8')->getValue()."<br>".$worksheet->getCell('K9')->getValue()."<br>".$worksheet->getCell('K10')->getValue()."<br>".$worksheet->getCell('K11')->getValue()."<br>".$worksheet->getCell('K12')->getValue()."<br>".$worksheet->getCell('K13')->getValue()."<br>".$worksheet->getCell('K14')->getValue()."<br>".$worksheet->getCell('K15')->getValue()."<br>".$worksheet->getCell('K16')->getValue()."<br>".$worksheet->getCell('K17')->getValue()."<br>".$worksheet->getCell('K18')->getValue()."<br>".$worksheet->getCell('K19')->getValue()."<br>".$worksheet->getCell('K20')->getValue()."<br>".$worksheet->getCell('K21')->getValue()."<br>".$worksheet->getCell('K22')->getValue();
											$followup_note=$worksheet->getCell('M8')->getValue()."<br>".$worksheet->getCell('M9')->getValue()."<br>".$worksheet->getCell('M10')->getValue()."<br>".$worksheet->getCell('M11')->getValue()."<br>".$worksheet->getCell('M12')->getValue()."<br>".$worksheet->getCell('M13')->getValue()."<br>".$worksheet->getCell('M14')->getValue()."<br>".$worksheet->getCell('M15')->getValue()."<br>".$worksheet->getCell('M16')->getValue()."<br>".$worksheet->getCell('M17')->getValue()."<br>".$worksheet->getCell('M18')->getValue()."<br>".$worksheet->getCell('M19')->getValue()."<br>".$worksheet->getCell('M20')->getValue()."<br>".$worksheet->getCell('M21')->getValue()."<br>".$worksheet->getCell('M22')->getValue();
											$re_sph=$worksheet->getCell('C26')->getValue();
											$re_cyl=$worksheet->getCell('D26')->getValue();
											$re_axis=$worksheet->getCell('E26')->getValue();
											$re_va=$worksheet->getCell('F26')->getValue();
											$le_sph=$worksheet->getCell('G26')->getValue();
											$le_cyl=$worksheet->getCell('H26')->getValue();
											$le_axis=$worksheet->getCell('I26')->getValue();
											$le_va=$worksheet->getCell('J26')->getValue();
											$re_add=$worksheet->getCell('D27')->getValue();
											$re_nva=$worksheet->getCell('F27')->getValue();
											$le_add=$worksheet->getCell('H27')->getValue();
											$le_nva=$worksheet->getCell('J27')->getValue();
											$colour=$worksheet->getCell('B28')->getValue();
											$focal=$worksheet->getCell('D28')->getValue();
											$pd=$worksheet->getCell('I28')->getValue();
											$vd=$worksheet->getCell('J28')->getValue();
											$advice=$worksheet->getCell('B31')->getValue()."<br>".$worksheet->getCell('B32')->getValue()."<br>".$worksheet->getCell('B33')->getValue()."<br>".$worksheet->getCell('B34')->getValue()."<br>".$worksheet->getCell('B35')->getValue()."<br>".$worksheet->getCell('B36')->getValue()."<br>".$worksheet->getCell('F31')->getValue()."<br>".$worksheet->getCell('F32')->getValue()."<br>".$worksheet->getCell('F33')->getValue()."<br>".$worksheet->getCell('F34')->getValue()."<br>".$worksheet->getCell('F35')->getValue()."<br>".$worksheet->getCell('F36')->getValue();
											$review_after=$worksheet->getCell('C37')->getValue();
											$lab_date=$worksheet->getCell('O29')->getValue();
											$hb=$worksheet->getCell('M30')->getValue();
											$n=$worksheet->getCell('M31')->getValue();
											$m=$worksheet->getCell('M32')->getValue();
											$sug_f=$worksheet->getCell('M33')->getValue();
											$esr=$worksheet->getCell('M34')->getValue();
											$culture=$worksheet->getCell('M35')->getValue();
											$xray=$worksheet->getCell('M36')->getValue();
											$usg=$worksheet->getCell('M37')->getValue();
											$others=$worksheet->getCell('M38')->getValue();
											$tlc=$worksheet->getCell('O30')->getValue();
											$e=$worksheet->getCell('O31')->getValue();
											$b=$worksheet->getCell('O32')->getValue();
											$pp=$worksheet->getCell('O33')->getValue();
											$ra=$worksheet->getCell('O34')->getValue();
											$uppersec=$worksheet->getCell('D39')->getValue();
											$od_unaided=$worksheet->getCell('D42')->getValue()." ".$worksheet->getCell('E42')->getValue();
											$od_old=$worksheet->getCell('F42')->getValue()." ".$worksheet->getCell('G42')->getValue();
											$od_phss=$worksheet->getCell('H42')->getValue()." ".$worksheet->getCell('I42')->getValue();
											$os_unaided=$worksheet->getCell('J42')->getValue()." ".$worksheet->getCell('K42')->getValue();
											$os_old=$worksheet->getCell('L42')->getValue()." ".$worksheet->getCell('M42')->getValue();
											$os_phss=$worksheet->getCell('N42')->getValue()." ".$worksheet->getCell('O42')->getValue();
											$od_pr=$worksheet->getCell('D43')->getValue();
											$os_pr=$worksheet->getCell('J43')->getValue();
											$ipd=$worksheet->getCell('B46')->getValue();
											$od_sph=$worksheet->getCell('D45')->getValue();
											$od_cyl=$worksheet->getCell('E45')->getValue();
											$od_axis=$worksheet->getCell('F45')->getValue();
											$od_va=$worksheet->getCell('G45')->getValue();
											$od_comment=$worksheet->getCell('H45')->getValue();
											$os_sph=$worksheet->getCell('J45')->getValue();
											$os_cyl=$worksheet->getCell('K45')->getValue();
											$os_axis=$worksheet->getCell('L45')->getValue();
											$os_va=$worksheet->getCell('M45')->getValue();
											$os_comment=$worksheet->getCell('N45')->getValue();
											$od_add=$worksheet->getCell('E46')->getValue();
											$od_nva=$worksheet->getCell('G46')->getValue();
											$os_add=$worksheet->getCell('E46')->getValue();
											$os_nva=$worksheet->getCell('M46')->getValue();
											$head_posture=$worksheet->getCell('D47')->getValue();
											$od_forehead=$worksheet->getCell('D48')->getValue();
											$os_forehead=$worksheet->getCell('J48')->getValue();
											$od_orbit=$worksheet->getCell('D49')->getValue();
											$os_orbit=$worksheet->getCell('J49')->getValue();
											$od_eye_brows=$worksheet->getCell('D50')->getValue();
											$os_eye_brows=$worksheet->getCell('J50')->getValue();
											$od_eye_lids=$worksheet->getCell('D51')->getValue();
											$os_eye_lids=$worksheet->getCell('J51')->getValue();
											$od_eye_lids_position=$worksheet->getCell('D52')->getValue();
											$os_eye_lids_position=$worksheet->getCell('J52')->getValue();
											$od_eye_lids_skin=$worksheet->getCell('D53')->getValue();
											$os_eye_lids_skin=$worksheet->getCell('J53')->getValue();
											$od_eye_lids_margins=$worksheet->getCell('D54')->getValue();
											$os_eye_lids_margins=$worksheet->getCell('J54')->getValue();
											$od_lacrimal_app=$worksheet->getCell('D55')->getValue();
											$os_lacrimal_app=$worksheet->getCell('J55')->getValue();
											$od_eye_ball=$worksheet->getCell('D56')->getValue();
											$os_eye_ball=$worksheet->getCell('J56')->getValue();
											$od_eye_ball_moments=$worksheet->getCell('D57')->getValue();
											$os_eye_ball_moments=$worksheet->getCell('J57')->getValue();
											$od_conjunctiva=$worksheet->getCell('D58')->getValue();
											$os_conjunctiva=$worksheet->getCell('J58')->getValue();
											$od_pulpebral_conjunctiva=$worksheet->getCell('D59')->getValue();
											$os_pulpebral_conjunctiva=$worksheet->getCell('J59')->getValue();
											$od_bulbar_conjunctiva=$worksheet->getCell('D60')->getValue();
											$os_bulbar_conjunctiva=$worksheet->getCell('J60')->getValue();
											$od_cornea_size=$worksheet->getCell('D63')->getValue();
											$os_cornea_size=$worksheet->getCell('J63')->getValue();
											$od_cornea_surface=$worksheet->getCell('D64')->getValue();
											$os_cornea_surface=$worksheet->getCell('J64')->getValue();
											$od_cornea_transparency=$worksheet->getCell('D65')->getValue();
											$os_cornea_transparency=$worksheet->getCell('J65')->getValue();
											$od_cornea_stroma=$worksheet->getCell('D66')->getValue();
											$os_cornea_stroma=$worksheet->getCell('J66')->getValue();
											$od_cornea_endothelium=$worksheet->getCell('D67')->getValue();
											$os_cornea_endothelium=$worksheet->getCell('J67')->getValue();
											$od_ac_contant=$worksheet->getCell('D69')->getValue();
											$os_ac_contant=$worksheet->getCell('J69')->getValue();
											$od_ac_depth=$worksheet->getCell('D70')->getValue();
											$os_ac_depth=$worksheet->getCell('J70')->getValue();
											$od_iris_colour=$worksheet->getCell('D72')->getValue();
											$os_iris_colour=$worksheet->getCell('J72')->getValue();
											$od_iris_pattern=$worksheet->getCell('D73')->getValue();
											$os_iris_pattern=$worksheet->getCell('J73')->getValue();
											$od_pupil_size=$worksheet->getCell('D75')->getValue();
											$os_pupil_size=$worksheet->getCell('J75')->getValue();
											$od_pupil_shape=$worksheet->getCell('D76')->getValue();
											$os_pupil_shape=$worksheet->getCell('J76')->getValue();
											$od_pupil_reaction=$worksheet->getCell('D77')->getValue();
											$os_pupil_reaction=$worksheet->getCell('J77')->getValue();
											$od_lens=$worksheet->getCell('D78')->getValue();
											$os_lens=$worksheet->getCell('J78')->getValue();
											$od_lens_opacity=$worksheet->getCell('D79')->getValue();
											$os_lens_opacity=$worksheet->getCell('J79')->getValue();
											$od_iop=$worksheet->getCell('D80')->getValue();
											$os_iop=$worksheet->getCell('J80')->getValue();
											$od_media=$worksheet->getCell('D82')->getValue();
											$os_media=$worksheet->getCell('J82')->getValue();
											$od_optic_disc=$worksheet->getCell('D83')->getValue();
											$os_optic_disc=$worksheet->getCell('J83')->getValue();
											$od_optic_disc_size=$worksheet->getCell('D84')->getValue();
											$os_optic_disc_size=$worksheet->getCell('J84')->getValue();
											$od_optic_disc_shape=$worksheet->getCell('D85')->getValue();
											$os_optic_disc_shape=$worksheet->getCell('J85')->getValue();
											$od_optic_disc_colour=$worksheet->getCell('D86')->getValue();
											$os_optic_disc_colour=$worksheet->getCell('J86')->getValue();
											$od_optic_disc_margine=$worksheet->getCell('D87')->getValue();
											$os_optic_disc_margine=$worksheet->getCell('J87')->getValue();
											$od_cd_ratio=$worksheet->getCell('D88')->getValue();
											$os_cd_ratio=$worksheet->getCell('J88')->getValue();
											$od_bv_disc=$worksheet->getCell('D90')->getValue();
											$os_bv_disc=$worksheet->getCell('J90')->getValue();
											$od_bv_gf=$worksheet->getCell('D91')->getValue()."<br>".$worksheet->getCell('D92')->getValue();
											$os_bv_gf=$worksheet->getCell('J91')->getValue()."<br>".$worksheet->getCell('J92')->getValue();
											$od_macula=$worksheet->getCell('D93')->getValue()."<br>".$worksheet->getCell('D94')->getValue()."<br>".$worksheet->getCell('D95')->getValue();
											$os_macula=$worksheet->getCell('J93')->getValue()."<br>".$worksheet->getCell('J94')->getValue()."<br>".$worksheet->getCell('J95')->getValue();
											$od_gf=$worksheet->getCell('D96')->getValue()."<br>".$worksheet->getCell('D97')->getValue()."<br>".$worksheet->getCell('D98')->getValue();
											$os_gf=$worksheet->getCell('J96')->getValue()."<br>".$worksheet->getCell('J97')->getValue()."<br>".$worksheet->getCell('J98')->getValue();
											$od_syringing=$worksheet->getCell('D100')->getValue();
											$os_syringing=$worksheet->getCell('J100')->getValue();
											$od_shirmers_test=$worksheet->getCell('D101')->getValue();
											$os_shirmers_test=$worksheet->getCell('J101')->getValue();
											$od_gonioscopy=$worksheet->getCell('D102')->getValue()."<br>".$worksheet->getCell('D103')->getValue()."<br>".$worksheet->getCell('D104')->getValue()."<br>";
											$os_gonioscopy=$worksheet->getCell('J102')->getValue()."<br>".$worksheet->getCell('J103')->getValue()."<br>".$worksheet->getCell('J104')->getValue()."<br>";
											$od_photograph_num=$worksheet->getCell('D105')->getValue();
											$os_photograph_num=$worksheet->getCell('J105')->getValue();
											
											// check whether patient is old or new
											$chkpat=mysqli_query($db,"select * from itr where firstname='$firstname' and middlename='$middlename' and lastname='$lastname' and contact='$contact'");
											$patrow=mysqli_fetch_array($chkpat);
											if(mysqli_num_rows($chkpat)==0)
											{
											$inssql3=mysqli_query($db,"INSERT INTO itr VALUES('','$title','".@$firstname."','".@$middlename."','".@$lastname."','','$age','$gender','','','','','','','$contact')");
											$insid=mysqli_insert_id($db);
											}
											else
											{
												$insid=$patrow["patient_id"];
											}
											$inssql4=mysqli_query($db,"INSERT INTO patients_visits VALUES('','$name','$insid','','$pres_date')");
											$inssql1=mysqli_query($db,"INSERT INTO `prescriptions`(`id`, `patient_id`, `patient_name`, `appointment_id`, `co`, `age`, `gender`, `pres_date`, `contact_num`, `address`, `eye`, `diagnosis`, `drug`, `freq`, `duration`, `diagnosis_eye`, `uppersec`, `od_unaided`, `od_old_spectacles`, `od_ph_ss`, `os_unaided`, `os_old_spectacles`, `os_ph_ss`,`od_pr`, `os_pr`, `od_sph`, `od_cyl`, `od_axis`, `od_va`, `od_comment`, `od_add`,`od_nva`, `os_sph`, `os_cyl`, `os_axis`, `os_va`, `os_comment`, `os_add`, `os_nva`, `ipd`, `head_posture`, `od_forehead`, `od_orbit`, `od_eye_brows`, `od_eye_lids`, `od_position_eyelids`, `od_skin_eyelids`, `od_margins_eyelids`, `od_lacrimal_app`, `od_eye_ball`, `od_moments_eyeball`, `od_conjunctiva`, `od_pulpebral_conjunctiva`, `od_bulbar_conjunctiva`, `od_size_cornea`, `od_surface_cornea`, `od_transparency_cornea`, `od_stroma_cornea`, `od_endothelium_cornea`, `od_ac_contant`, `od_ac_depth`, `od_iris_colour`, `od_iris_pattern`, `od_pupil_size`, `od_pupil_shape`, `od_pupil_reaction`,`od_lens`, `od_lens_opacity`, `od_iop`, `od_media`, `od_optic_disc`, `od_optic_disc_size`, `od_optic_disc_shape`, `od_optic_disc_colour`, `od_optic_disc_margine`, `od_cd_ratio`, `od_bv_over_disc`, `od_bv_over_gf`, `od_macula`, `od_gf`, `od_syringing`, `od_shirmers_test`, `od_gonioscopy`, `od_photograph_num`, `advice`, `folowup_date`, `followup_note`, `other_note`, `os_forehead`, `os_orbit`, `os_eye_brows`, `os_eye_lids`, `os_position_eyelids`, `os_skin_eyelids`, `os_margins_eyelids`, `os_lacrimal_app`, `os_eye_ball`, `os_moments_eyeball`, `os_conjunctiva`, `os_pulpebral_conjunctiva`, `os_bulbar_conjunctiva`, `os_size_cornea`, `os_surface_cornea`, `os_transparency_cornea`, `os_stroma_cornea`, `os_endothelium_cornea`, `os_ac_contant`, `os_ac_depth`, `os_iris_colour`, `os_iris_pattern`, `os_pupil_size`, `os_pupil_shape`, `os_pupil_reaction`,`os_lens`, `os_lens_opacity`, `os_iop`, `os_media`, `os_optic_disc`, `os_optic_disc_size`, `os_optic_disc_shape`, `os_optic_disc_colour`, `os_optic_disc_margine`, `os_cd_ratio`, `os_bv_over_disc`, `os_bv_over_gf`, `os_macula`, `os_gf`, `os_syringing`, `os_shirmers_test`, `os_gonioscopy`, `os_photograph_num`, `review_after`) VALUES ('','$insid','$name','','".mysqli_real_escape_string($db,$co)."','".mysqli_real_escape_string($db,$age)."','".mysqli_real_escape_string($db,$gender)."','".mysqli_real_escape_string($db,$pres_date)."','".mysqli_real_escape_string($db,$contact)."','".mysqli_real_escape_string($db,$address)."','".mysqli_real_escape_string($db,$eye)."','".mysqli_real_escape_string($db,$diagnosis)."','".mysqli_real_escape_string($db,$drug)."','".mysqli_real_escape_string($db,$frequency)."','".mysqli_real_escape_string($db,$duration)."','".mysqli_real_escape_string($db,$deye)."','".mysqli_real_escape_string($db,$uppersec)."','".mysqli_real_escape_string($db,$od_unaided)."','".mysqli_real_escape_string($db,$od_old)."','".mysqli_real_escape_string($db,$od_phss)."','".mysqli_real_escape_string($db,$os_unaided)."','".mysqli_real_escape_string($db,$os_old)."','".mysqli_real_escape_string($db,$os_phss)."','".mysqli_real_escape_string($db,$od_pr)."','".mysqli_real_escape_string($db,$os_pr)."','".mysqli_real_escape_string($db,$od_sph)."','".mysqli_real_escape_string($db,$od_cyl)."','".mysqli_real_escape_string($db,$od_axis)."','".mysqli_real_escape_string($db,$od_va)."','".mysqli_real_escape_string($db,$od_comment)."','".mysqli_real_escape_string($db,$od_add)."','".mysqli_real_escape_string($db,$od_nva)."','".mysqli_real_escape_string($db,$os_sph)."','".mysqli_real_escape_string($db,$os_cyl)."','".mysqli_real_escape_string($db,$os_axis)."','".mysqli_real_escape_string($db,$os_va)."','".mysqli_real_escape_string($db,$os_comment)."','".mysqli_real_escape_string($db,$os_add)."','".mysqli_real_escape_string($db,$os_nva)."','".mysqli_real_escape_string($db,$ipd)."','".mysqli_real_escape_string($db,$head_posture)."','".mysqli_real_escape_string($db,$od_forehead)."','".mysqli_real_escape_string($db,$od_orbit)."','".mysqli_real_escape_string($db,$od_eye_brows)."','".mysqli_real_escape_string($db,$od_eye_lids)."','".mysqli_real_escape_string($db,$od_eye_lids_position)."','".mysqli_real_escape_string($db,$od_eye_lids_skin)."','".mysqli_real_escape_string($db,$od_eye_lids_margins)."','".mysqli_real_escape_string($db,$od_lacrimal_app)."','".mysqli_real_escape_string($db,$od_eye_ball)."','".mysqli_real_escape_string($db,$od_eye_ball_moments)."','".mysqli_real_escape_string($db,$od_conjunctiva)."','".mysqli_real_escape_string($db,$od_pulpebral_conjunctiva)."','".mysqli_real_escape_string($db,$od_bulbar_conjunctiva)."','".mysqli_real_escape_string($db,$od_cornea_size)."','".mysqli_real_escape_string($db,$od_cornea_surface)."','".mysqli_real_escape_string($db,$od_cornea_transparency)."','".mysqli_real_escape_string($db,$od_cornea_stroma)."','".mysqli_real_escape_string($db,$od_cornea_endothelium)."','".mysqli_real_escape_string($db,$od_ac_contant)."','".mysqli_real_escape_string($db,$od_ac_depth)."','".mysqli_real_escape_string($db,$od_iris_colour)."','".mysqli_real_escape_string($db,$od_iris_pattern)."','".mysqli_real_escape_string($db,$od_pupil_size)."','".mysqli_real_escape_string($db,$od_pupil_shape)."','".mysqli_real_escape_string($db,$od_pupil_reaction)."','".mysqli_real_escape_string($db,$od_lens)."','".mysqli_real_escape_string($db,$od_lens_opacity)."','".mysqli_real_escape_string($db,$od_iop)."','".mysqli_real_escape_string($db,$od_media)."','".mysqli_real_escape_string($db,$od_optic_disc)."','".mysqli_real_escape_string($db,$od_optic_disc_size)."','".mysqli_real_escape_string($db,$od_optic_disc_shape)."','".mysqli_real_escape_string($db,$od_optic_disc_colour)."','".mysqli_real_escape_string($db,$od_optic_disc_margine)."','".mysqli_real_escape_string($db,$od_cd_ratio)."','".mysqli_real_escape_string($db,$od_bv_disc)."','".mysqli_real_escape_string($db,$od_bv_gf)."','".mysqli_real_escape_string($db,$od_macula)."','".mysqli_real_escape_string($db,$od_gf)."','".mysqli_real_escape_string($db,$od_syringing)."','".mysqli_real_escape_string($db,$od_shirmers_test)."','".mysqli_real_escape_string($db,$od_gonioscopy)."','".mysqli_real_escape_string($db,$od_photograph_num)."','".mysqli_real_escape_string($db,$advice)."','".mysqli_real_escape_string($db,$followup_date)."','".mysqli_real_escape_string($db,$followup_note)."','','".mysqli_real_escape_string($db,$os_forehead)."','".mysqli_real_escape_string($db,$os_orbit)."','".mysqli_real_escape_string($db,$os_eye_brows)."','".mysqli_real_escape_string($db,$os_eye_lids)."','".mysqli_real_escape_string($db,$os_eye_lids_position)."','".mysqli_real_escape_string($db,$os_eye_lids_skin)."','".mysqli_real_escape_string($db,$os_eye_lids_margins)."','".mysqli_real_escape_string($db,$os_lacrimal_app)."','".mysqli_real_escape_string($db,$os_eye_ball)."','".mysqli_real_escape_string($db,$os_eye_ball_moments)."','".mysqli_real_escape_string($db,$os_conjunctiva)."','".mysqli_real_escape_string($db,$os_pulpebral_conjunctiva)."','".mysqli_real_escape_string($db,$os_bulbar_conjunctiva)."','".mysqli_real_escape_string($db,$os_cornea_size)."','".mysqli_real_escape_string($db,$os_cornea_surface)."','".mysqli_real_escape_string($db,$os_cornea_transparency)."','".mysqli_real_escape_string($db,$os_cornea_stroma)."','".mysqli_real_escape_string($db,$os_cornea_endothelium)."','".mysqli_real_escape_string($db,$os_ac_contant)."','".mysqli_real_escape_string($db,$os_ac_depth)."','".mysqli_real_escape_string($db,$os_iris_colour)."','".mysqli_real_escape_string($db,$os_iris_pattern)."','".mysqli_real_escape_string($db,$os_pupil_size)."','".mysqli_real_escape_string($db,$os_pupil_shape)."','".mysqli_real_escape_string($db,$os_pupil_reaction)."','".mysqli_real_escape_string($db,$os_lens)."','".mysqli_real_escape_string($db,$os_lens_opacity)."','".mysqli_real_escape_string($db,$os_iop)."','".mysqli_real_escape_string($db,$os_media)."','".mysqli_real_escape_string($db,$os_optic_disc)."','".mysqli_real_escape_string($db,$os_optic_disc_size)."','".mysqli_real_escape_string($db,$os_optic_disc_shape)."','".mysqli_real_escape_string($db,$os_optic_disc_colour)."','".mysqli_real_escape_string($db,$os_optic_disc_margine)."','".mysqli_real_escape_string($db,$os_cd_ratio)."','".mysqli_real_escape_string($db,$os_bv_disc)."','".mysqli_real_escape_string($db,$os_bv_gf)."','".mysqli_real_escape_string($db,$os_macula)."','".mysqli_real_escape_string($db,$os_gf)."','".mysqli_real_escape_string($db,$os_syringing)."','".mysqli_real_escape_string($db,$os_shirmers_test)."','".mysqli_real_escape_string($db,$os_gonioscopy)."','".mysqli_real_escape_string($db,$os_photograph_num)."','".mysqli_real_escape_string($db,$review_after)."')");
											$inssql2=mysqli_query($db,"INSERT INTO `glasses`(`id`, `patient_id`, `patient_name`, `appointment_id`, `re_sph`, `re_cyl`, `re_axis`, `re_va`, `le_sph`, `le_cyl`, `le_axis`, `le_va`, `re_add`, `re_nva`, `le_add`, `le_nva`, `ipd`, `colour`, `focal`, `vd`, `ins_date`) VALUES ('','$insid','".mysqli_real_escape_string($db,$name)."','','".mysqli_real_escape_string($db,$re_sph)."','".mysqli_real_escape_string($db,$re_cyl)."','".mysqli_real_escape_string($db,$re_axis)."','".mysqli_real_escape_string($db,$re_va)."','".mysqli_real_escape_string($db,$le_sph)."','".mysqli_real_escape_string($db,$le_cyl)."','".mysqli_real_escape_string($db,$le_axis)."','".mysqli_real_escape_string($db,$le_va)."','".mysqli_real_escape_string($db,$re_add)."','".mysqli_real_escape_string($db,$re_nva)."','".mysqli_real_escape_string($db,$le_add)."','".mysqli_real_escape_string($db,$le_nva)."','".mysqli_real_escape_string($db,$pd)."','".mysqli_real_escape_string($db,$colour)."','".mysqli_real_escape_string($db,$focal)."','".mysqli_real_escape_string($db,$vd)."','$pres_date')");
											$inssql5=mysqli_query($db,"INSERT INTO `lab_report` VALUES ('','$insid','".mysqli_real_escape_string($db,$name)."','','$lab_date','".mysqli_real_escape_string($db,$hb)."','".mysqli_real_escape_string($db,$n)."','".mysqli_real_escape_string($db,$m)."','".mysqli_real_escape_string($db,$sug_f)."','".mysqli_real_escape_string($db,$esr)."','".mysqli_real_escape_string($db,$culture)."','".mysqli_real_escape_string($db,$xray)."','".mysqli_real_escape_string($db,$usg)."','".mysqli_real_escape_string($db,$others)."','".mysqli_real_escape_string($db,$tlc)."','".mysqli_real_escape_string($db,$e)."','".mysqli_real_escape_string($db,$b)."','".mysqli_real_escape_string($db,$pp)."','".mysqli_real_escape_string($db,$ra)."')");
											
									}
									
											unlink($target_file);
										echo "<script> alert('File uploaded successfully!') </script>";
									}
									
								}
							}

					?>		
			</div>	
		</div>	
	<div id = "footer">
		<label class = "footer-title">&copy; Copyright EyeCare 2022</label>
	</div>
	
<?php require'script.php' ?>
<script type = "text/javascript">
	function confirmationDelete(anchor)
		{
			var conf = confirm('Are you sure want to delete this record?');
			if(conf)
			window.location=anchor.attr("href");
		}
</script>
<script type = "text/javascript">
    $(document).ready(function() {
        function disableBack() { window.history.forward() }

        window.onload = disableBack();
        window.onpageshow = function(evt) { if (evt.persisted) disableBack() }
    });
</script>	
</body>
</html>