-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 05, 2023 at 03:14 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hcpms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(12) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `middlename` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `role` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`, `firstname`, `middlename`, `lastname`, `role`) VALUES
(2, 'receptionist', 'receptionist', 'Receptionist', '', '', 'Receptionist'),
(3, 'admin', 'admin', 'Administrator', '', '', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `advice_temp`
--

CREATE TABLE `advice_temp` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `apid` int(11) NOT NULL,
  `advice` text NOT NULL,
  `ins_date` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(11) NOT NULL,
  `app_date` varchar(200) NOT NULL,
  `time` varchar(200) NOT NULL,
  `patient_name` varchar(200) NOT NULL,
  `pid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `app_date`, `time`, `patient_name`, `pid`) VALUES
(26, '2023-06-06', '09:31 AM', 'Rohit Deshpande', 12),
(27, '2023-06-06', '09:33 AM', 'Rohit Deshpande', 12);

-- --------------------------------------------------------

--
-- Table structure for table `co_temp`
--

CREATE TABLE `co_temp` (
  `id` int(11) NOT NULL,
  `apid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `co` varchar(200) NOT NULL,
  `eye` varchar(200) NOT NULL,
  `duration` varchar(200) NOT NULL,
  `note` text NOT NULL,
  `ins_date` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `diagnosis_temp`
--

CREATE TABLE `diagnosis_temp` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `apid` int(11) NOT NULL,
  `eye` varchar(200) NOT NULL,
  `diagnosis` varchar(200) NOT NULL,
  `ins_date` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `examination_temp`
--

CREATE TABLE `examination_temp` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `apid` int(11) NOT NULL,
  `uppersec` varchar(200) NOT NULL,
  `od_unaided` varchar(200) NOT NULL,
  `od_old_spectacles` varchar(200) NOT NULL,
  `od_ph_ss` varchar(200) NOT NULL,
  `os_unaided` varchar(200) NOT NULL,
  `os_old_spectacles` varchar(200) NOT NULL,
  `os_ph_ss` varchar(200) NOT NULL,
  `od_pr` varchar(200) NOT NULL,
  `os_pr` varchar(200) NOT NULL,
  `od_sph` varchar(200) NOT NULL,
  `od_cyl` varchar(200) NOT NULL,
  `od_axis` varchar(200) NOT NULL,
  `od_va` varchar(200) NOT NULL,
  `od_comment` text NOT NULL,
  `od_add` varchar(200) NOT NULL,
  `od_nva` text NOT NULL,
  `os_sph` varchar(200) NOT NULL,
  `os_cyl` varchar(200) NOT NULL,
  `os_axis` varchar(200) NOT NULL,
  `os_va` varchar(200) NOT NULL,
  `os_comment` text NOT NULL,
  `os_add` varchar(200) NOT NULL,
  `os_nva` text NOT NULL,
  `ipd` varchar(200) NOT NULL,
  `head_posture` varchar(200) NOT NULL,
  `od_forehead` varchar(200) NOT NULL,
  `od_orbit` varchar(200) NOT NULL,
  `od_eye_brows` varchar(200) NOT NULL,
  `od_eye_lids` varchar(200) NOT NULL,
  `od_position_eyelids` varchar(200) NOT NULL,
  `od_skin_eyelids` varchar(200) NOT NULL,
  `od_margins_eyelids` varchar(200) NOT NULL,
  `od_lacrimal_app` varchar(200) NOT NULL,
  `od_eye_ball` varchar(200) NOT NULL,
  `od_moments_eyeball` varchar(200) NOT NULL,
  `od_conjunctiva` varchar(200) NOT NULL,
  `od_pulpebral_conjunctiva` varchar(200) NOT NULL,
  `od_bulbar_conjunctiva` varchar(200) NOT NULL,
  `od_size_cornea` varchar(200) NOT NULL,
  `od_surface_cornea` varchar(200) NOT NULL,
  `od_transparency_cornea` varchar(200) NOT NULL,
  `od_stroma_cornea` varchar(200) NOT NULL,
  `od_endothelium_cornea` varchar(200) NOT NULL,
  `od_ac_contant` varchar(200) DEFAULT NULL,
  `od_ac_depth` varchar(200) NOT NULL,
  `od_iris_colour` varchar(200) DEFAULT NULL,
  `od_iris_pattern` varchar(200) DEFAULT NULL,
  `od_pupil_size` varchar(200) DEFAULT NULL,
  `od_pupil_shape` varchar(200) DEFAULT NULL,
  `od_pupil_reaction` varchar(200) DEFAULT NULL,
  `od_lens` varchar(200) NOT NULL,
  `od_lens_opacity` varchar(200) DEFAULT NULL,
  `od_iop` varchar(200) DEFAULT NULL,
  `od_media` varchar(200) DEFAULT NULL,
  `od_optic_disc` varchar(200) DEFAULT NULL,
  `od_optic_disc_size` varchar(200) DEFAULT NULL,
  `od_optic_disc_shape` varchar(200) DEFAULT NULL,
  `od_optic_disc_colour` varchar(200) DEFAULT NULL,
  `od_optic_disc_margine` varchar(200) DEFAULT NULL,
  `od_cd_ratio` varchar(200) DEFAULT NULL,
  `od_bv_over_disc` text DEFAULT NULL,
  `od_bv_over_gf` text DEFAULT NULL,
  `od_macula` text DEFAULT NULL,
  `od_gf` text DEFAULT NULL,
  `od_syringing` varchar(200) DEFAULT NULL,
  `od_shirmers_test` varchar(200) DEFAULT NULL,
  `od_gonioscopy` text DEFAULT NULL,
  `od_photograph_num` varchar(200) DEFAULT NULL,
  `os_forehead` varchar(200) DEFAULT NULL,
  `os_orbit` varchar(200) DEFAULT NULL,
  `os_eye_brows` varchar(200) DEFAULT NULL,
  `os_eye_lids` varchar(200) DEFAULT NULL,
  `os_position_eyelids` varchar(200) DEFAULT NULL,
  `os_skin_eyelids` varchar(200) DEFAULT NULL,
  `os_margins_eyelids` varchar(200) DEFAULT NULL,
  `os_lacrimal_app` varchar(200) DEFAULT NULL,
  `os_eye_ball` varchar(200) DEFAULT NULL,
  `os_moments_eyeball` varchar(200) DEFAULT NULL,
  `os_conjunctiva` varchar(200) DEFAULT NULL,
  `os_pulpebral_conjunctiva` varchar(200) DEFAULT NULL,
  `os_bulbar_conjunctiva` varchar(200) DEFAULT NULL,
  `os_size_cornea` varchar(200) DEFAULT NULL,
  `os_surface_cornea` varchar(200) DEFAULT NULL,
  `os_transparency_cornea` varchar(200) DEFAULT NULL,
  `os_stroma_cornea` varchar(200) DEFAULT NULL,
  `os_endothelium_cornea` varchar(200) DEFAULT NULL,
  `os_ac_contant` varchar(200) DEFAULT NULL,
  `os_ac_depth` varchar(200) NOT NULL,
  `os_iris_colour` varchar(200) DEFAULT NULL,
  `os_iris_pattern` varchar(200) DEFAULT NULL,
  `os_pupil_size` varchar(200) DEFAULT NULL,
  `os_pupil_shape` varchar(200) DEFAULT NULL,
  `os_pupil_reaction` varchar(200) DEFAULT NULL,
  `os_lens` varchar(200) NOT NULL,
  `os_lens_opacity` varchar(200) DEFAULT NULL,
  `os_iop` varchar(200) DEFAULT NULL,
  `os_media` varchar(200) DEFAULT NULL,
  `os_optic_disc` varchar(200) DEFAULT NULL,
  `os_optic_disc_size` varchar(200) DEFAULT NULL,
  `os_optic_disc_shape` varchar(200) DEFAULT NULL,
  `os_optic_disc_colour` varchar(200) DEFAULT NULL,
  `os_optic_disc_margine` varchar(200) DEFAULT NULL,
  `os_cd_ratio` varchar(200) DEFAULT NULL,
  `os_bv_over_disc` text DEFAULT NULL,
  `os_bv_over_gf` text DEFAULT NULL,
  `os_macula` text DEFAULT NULL,
  `os_gf` text DEFAULT NULL,
  `os_syringing` text DEFAULT NULL,
  `os_shirmers_test` text DEFAULT NULL,
  `os_gonioscopy` text DEFAULT NULL,
  `os_photograph_num` varchar(200) DEFAULT NULL,
  `ins_date` varchar(200) NOT NULL,
  `od_fundus` varchar(200) NOT NULL,
  `os_fundus` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `followup_temp`
--

CREATE TABLE `followup_temp` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `apid` int(11) NOT NULL,
  `followup_date` varchar(200) NOT NULL,
  `followup_note` varchar(200) NOT NULL,
  `ins_date` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `glasses`
--

CREATE TABLE `glasses` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `patient_name` varchar(200) NOT NULL,
  `appointment_id` int(11) NOT NULL,
  `re_sph` varchar(200) NOT NULL,
  `re_cyl` varchar(200) NOT NULL,
  `re_axis` varchar(200) NOT NULL,
  `re_va` varchar(200) NOT NULL,
  `le_sph` varchar(200) NOT NULL,
  `le_cyl` varchar(200) NOT NULL,
  `le_axis` varchar(200) NOT NULL,
  `le_va` varchar(200) NOT NULL,
  `re_add` varchar(200) NOT NULL,
  `re_nva` varchar(200) NOT NULL,
  `le_add` varchar(200) NOT NULL,
  `le_nva` varchar(200) NOT NULL,
  `ipd` varchar(200) NOT NULL,
  `colour` varchar(200) NOT NULL,
  `focal` varchar(200) NOT NULL,
  `vd` varchar(200) NOT NULL,
  `ins_date` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `glasses`
--

INSERT INTO `glasses` (`id`, `patient_id`, `patient_name`, `appointment_id`, `re_sph`, `re_cyl`, `re_axis`, `re_va`, `le_sph`, `le_cyl`, `le_axis`, `le_va`, `re_add`, `re_nva`, `le_add`, `le_nva`, `ipd`, `colour`, `focal`, `vd`, `ins_date`) VALUES
(50, 12, 'Rohit Deshpande', 27, '- 4.5', '- 3.5', '85', '2/60', '- 3.0', '- 3.0', '45', '6/12', '+1.75', 'N10', '+2.25', 'N12', 'IPD- 71', 'English White', 'Protective Polycarbonate Lenses', '09', '2023-06-05');

-- --------------------------------------------------------

--
-- Table structure for table `glasses_temp`
--

CREATE TABLE `glasses_temp` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `apid` int(11) NOT NULL,
  `re_sph` varchar(200) NOT NULL,
  `re_cyl` varchar(200) NOT NULL,
  `re_axis` varchar(200) NOT NULL,
  `re_va` varchar(200) NOT NULL,
  `le_sph` varchar(200) NOT NULL,
  `le_cyl` varchar(200) NOT NULL,
  `le_axis` varchar(200) NOT NULL,
  `le_va` varchar(200) NOT NULL,
  `re_add` varchar(200) NOT NULL,
  `re_nva` varchar(200) NOT NULL,
  `le_add` varchar(200) NOT NULL,
  `le_nva` varchar(200) NOT NULL,
  `colour` varchar(200) NOT NULL,
  `focal` varchar(200) NOT NULL,
  `vd` varchar(200) NOT NULL,
  `ipd` varchar(200) NOT NULL,
  `ins_date` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `itr`
--

CREATE TABLE `itr` (
  `patient_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `middlename` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `birthdate` varchar(20) NOT NULL,
  `age` int(3) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `house` varchar(100) NOT NULL,
  `street` varchar(100) NOT NULL,
  `locality` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `pin` varchar(100) NOT NULL,
  `contact` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `itr`
--

INSERT INTO `itr` (`patient_id`, `title`, `firstname`, `middlename`, `lastname`, `birthdate`, `age`, `gender`, `house`, `street`, `locality`, `city`, `state`, `pin`, `contact`) VALUES
(12, 'Mr.', 'Rohit', '', 'Deshpande', '10/16/1993', 29, 'Male', 'ward no. 18 ', 'raman nagar', 'Behind dream house', 'janjgir', 'chhattisgarh', '495668', '9907120508');

-- --------------------------------------------------------

--
-- Table structure for table `lab_report`
--

CREATE TABLE `lab_report` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `patient_name` varchar(200) NOT NULL,
  `appointment_id` int(11) NOT NULL,
  `report_date` varchar(200) NOT NULL,
  `HB` varchar(200) NOT NULL,
  `N` varchar(200) NOT NULL,
  `M` varchar(200) NOT NULL,
  `sug_f` varchar(200) NOT NULL,
  `ESR` varchar(200) NOT NULL,
  `culture` varchar(200) NOT NULL,
  `x_ray` varchar(200) NOT NULL,
  `USG` varchar(200) NOT NULL,
  `others` varchar(200) NOT NULL,
  `tlc` varchar(200) NOT NULL,
  `E` varchar(200) NOT NULL,
  `B` varchar(200) NOT NULL,
  `PP` varchar(200) NOT NULL,
  `RA` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `lab_report`
--

INSERT INTO `lab_report` (`id`, `patient_id`, `patient_name`, `appointment_id`, `report_date`, `HB`, `N`, `M`, `sug_f`, `ESR`, `culture`, `x_ray`, `USG`, `others`, `tlc`, `E`, `B`, `PP`, `RA`) VALUES
(23, 12, 'Rohit Deshpande', 0, '2023-06-13', '13', 'kk', 'k', 'kj', 'k', 'kl', 'mk', 'm', ' m', 'm m ', ' k', 'nk', 'kn', 'kn');

-- --------------------------------------------------------

--
-- Table structure for table `patients_visits`
--

CREATE TABLE `patients_visits` (
  `id` int(11) NOT NULL,
  `patient_name` varchar(200) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `appointment_id` int(11) NOT NULL,
  `visit_date` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `patients_visits`
--

INSERT INTO `patients_visits` (`id`, `patient_name`, `patient_id`, `appointment_id`, `visit_date`) VALUES
(29, 'Rohit Deshpande', 12, 27, '2023-06-05');

-- --------------------------------------------------------

--
-- Table structure for table `prescriptions`
--

CREATE TABLE `prescriptions` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `patient_name` varchar(200) NOT NULL,
  `appointment_id` int(11) NOT NULL,
  `co` text NOT NULL,
  `age` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `pres_date` varchar(200) NOT NULL,
  `contact_num` varchar(200) NOT NULL,
  `address` text NOT NULL,
  `eye` text NOT NULL,
  `diagnosis` text NOT NULL,
  `drug` text NOT NULL,
  `freq` text NOT NULL,
  `duration` text NOT NULL,
  `diagnosis_eye` text NOT NULL,
  `uppersec` text NOT NULL,
  `od_unaided` varchar(200) NOT NULL,
  `od_old_spectacles` varchar(200) NOT NULL,
  `od_ph_ss` varchar(200) NOT NULL,
  `os_unaided` varchar(200) NOT NULL,
  `os_old_spectacles` varchar(200) NOT NULL,
  `os_ph_ss` varchar(200) NOT NULL,
  `od_pr` varchar(200) NOT NULL,
  `os_pr` varchar(200) NOT NULL,
  `od_sph` varchar(200) NOT NULL,
  `od_cyl` varchar(200) NOT NULL,
  `od_axis` varchar(200) NOT NULL,
  `od_va` varchar(200) NOT NULL,
  `od_comment` text NOT NULL,
  `od_add` varchar(200) NOT NULL,
  `od_nva` varchar(200) NOT NULL,
  `os_sph` varchar(200) NOT NULL,
  `os_cyl` varchar(200) NOT NULL,
  `os_axis` varchar(200) NOT NULL,
  `os_va` varchar(200) NOT NULL,
  `os_comment` text NOT NULL,
  `os_add` varchar(200) NOT NULL,
  `os_nva` text NOT NULL,
  `ipd` varchar(200) NOT NULL,
  `head_posture` varchar(200) NOT NULL,
  `od_forehead` varchar(200) NOT NULL,
  `od_orbit` varchar(200) NOT NULL,
  `od_eye_brows` varchar(200) NOT NULL,
  `od_eye_lids` varchar(200) NOT NULL,
  `od_position_eyelids` varchar(200) NOT NULL,
  `od_skin_eyelids` varchar(200) NOT NULL,
  `od_margins_eyelids` varchar(200) NOT NULL,
  `od_lacrimal_app` varchar(200) NOT NULL,
  `od_eye_ball` varchar(200) NOT NULL,
  `od_moments_eyeball` varchar(200) NOT NULL,
  `od_conjunctiva` varchar(200) NOT NULL,
  `od_pulpebral_conjunctiva` varchar(200) NOT NULL,
  `od_bulbar_conjunctiva` varchar(200) NOT NULL,
  `od_size_cornea` varchar(200) NOT NULL,
  `od_surface_cornea` varchar(200) NOT NULL,
  `od_transparency_cornea` varchar(200) NOT NULL,
  `od_stroma_cornea` varchar(200) NOT NULL,
  `od_endothelium_cornea` varchar(200) NOT NULL,
  `od_ac_contant` varchar(200) DEFAULT NULL,
  `od_ac_depth` varchar(200) NOT NULL,
  `od_iris_colour` varchar(200) DEFAULT NULL,
  `od_iris_pattern` varchar(200) DEFAULT NULL,
  `od_pupil_size` varchar(200) DEFAULT NULL,
  `od_pupil_shape` varchar(200) DEFAULT NULL,
  `od_pupil_reaction` varchar(200) DEFAULT NULL,
  `od_lens` varchar(200) NOT NULL,
  `od_lens_opacity` varchar(200) DEFAULT NULL,
  `od_iop` varchar(200) DEFAULT NULL,
  `od_media` varchar(200) DEFAULT NULL,
  `od_optic_disc` varchar(200) DEFAULT NULL,
  `od_optic_disc_size` varchar(200) DEFAULT NULL,
  `od_optic_disc_shape` varchar(200) DEFAULT NULL,
  `od_optic_disc_colour` varchar(200) DEFAULT NULL,
  `od_optic_disc_margine` varchar(200) DEFAULT NULL,
  `od_cd_ratio` varchar(200) DEFAULT NULL,
  `od_bv_over_disc` text DEFAULT NULL,
  `od_bv_over_gf` text DEFAULT NULL,
  `od_macula` text DEFAULT NULL,
  `od_gf` text DEFAULT NULL,
  `od_syringing` varchar(200) DEFAULT NULL,
  `od_shirmers_test` varchar(200) DEFAULT NULL,
  `od_gonioscopy` text DEFAULT NULL,
  `od_photograph_num` varchar(200) DEFAULT NULL,
  `advice` text NOT NULL,
  `folowup_date` varchar(200) NOT NULL,
  `followup_note` text NOT NULL,
  `other_note` text NOT NULL,
  `os_forehead` varchar(200) DEFAULT NULL,
  `os_orbit` varchar(200) DEFAULT NULL,
  `os_eye_brows` varchar(200) DEFAULT NULL,
  `os_eye_lids` varchar(200) DEFAULT NULL,
  `os_position_eyelids` varchar(200) DEFAULT NULL,
  `os_skin_eyelids` varchar(200) DEFAULT NULL,
  `os_margins_eyelids` varchar(200) DEFAULT NULL,
  `os_lacrimal_app` varchar(200) DEFAULT NULL,
  `os_eye_ball` varchar(200) DEFAULT NULL,
  `os_moments_eyeball` varchar(200) DEFAULT NULL,
  `os_conjunctiva` varchar(200) DEFAULT NULL,
  `os_pulpebral_conjunctiva` varchar(200) DEFAULT NULL,
  `os_bulbar_conjunctiva` varchar(200) DEFAULT NULL,
  `os_size_cornea` varchar(200) DEFAULT NULL,
  `os_surface_cornea` varchar(200) DEFAULT NULL,
  `os_transparency_cornea` varchar(200) DEFAULT NULL,
  `os_stroma_cornea` varchar(200) DEFAULT NULL,
  `os_endothelium_cornea` varchar(200) DEFAULT NULL,
  `os_ac_contant` varchar(200) DEFAULT NULL,
  `os_ac_depth` varchar(200) NOT NULL,
  `os_iris_colour` varchar(200) DEFAULT NULL,
  `os_iris_pattern` varchar(200) DEFAULT NULL,
  `os_pupil_size` varchar(200) DEFAULT NULL,
  `os_pupil_shape` varchar(200) DEFAULT NULL,
  `os_pupil_reaction` varchar(200) DEFAULT NULL,
  `os_lens` varchar(200) NOT NULL,
  `os_lens_opacity` varchar(200) DEFAULT NULL,
  `os_iop` varchar(200) DEFAULT NULL,
  `os_media` varchar(200) DEFAULT NULL,
  `os_optic_disc` varchar(200) DEFAULT NULL,
  `os_optic_disc_size` varchar(200) DEFAULT NULL,
  `os_optic_disc_shape` varchar(200) DEFAULT NULL,
  `os_optic_disc_colour` varchar(200) DEFAULT NULL,
  `os_optic_disc_margine` varchar(200) DEFAULT NULL,
  `os_cd_ratio` varchar(200) DEFAULT NULL,
  `os_bv_over_disc` text DEFAULT NULL,
  `os_bv_over_gf` text DEFAULT NULL,
  `os_macula` text DEFAULT NULL,
  `os_gf` text DEFAULT NULL,
  `os_syringing` text DEFAULT NULL,
  `os_shirmers_test` text DEFAULT NULL,
  `os_gonioscopy` text DEFAULT NULL,
  `os_photograph_num` varchar(200) DEFAULT NULL,
  `review_after` varchar(200) NOT NULL,
  `od_fundus` varchar(200) NOT NULL,
  `os_fundus` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `prescriptions`
--

INSERT INTO `prescriptions` (`id`, `patient_id`, `patient_name`, `appointment_id`, `co`, `age`, `gender`, `pres_date`, `contact_num`, `address`, `eye`, `diagnosis`, `drug`, `freq`, `duration`, `diagnosis_eye`, `uppersec`, `od_unaided`, `od_old_spectacles`, `od_ph_ss`, `os_unaided`, `os_old_spectacles`, `os_ph_ss`, `od_pr`, `os_pr`, `od_sph`, `od_cyl`, `od_axis`, `od_va`, `od_comment`, `od_add`, `od_nva`, `os_sph`, `os_cyl`, `os_axis`, `os_va`, `os_comment`, `os_add`, `os_nva`, `ipd`, `head_posture`, `od_forehead`, `od_orbit`, `od_eye_brows`, `od_eye_lids`, `od_position_eyelids`, `od_skin_eyelids`, `od_margins_eyelids`, `od_lacrimal_app`, `od_eye_ball`, `od_moments_eyeball`, `od_conjunctiva`, `od_pulpebral_conjunctiva`, `od_bulbar_conjunctiva`, `od_size_cornea`, `od_surface_cornea`, `od_transparency_cornea`, `od_stroma_cornea`, `od_endothelium_cornea`, `od_ac_contant`, `od_ac_depth`, `od_iris_colour`, `od_iris_pattern`, `od_pupil_size`, `od_pupil_shape`, `od_pupil_reaction`, `od_lens`, `od_lens_opacity`, `od_iop`, `od_media`, `od_optic_disc`, `od_optic_disc_size`, `od_optic_disc_shape`, `od_optic_disc_colour`, `od_optic_disc_margine`, `od_cd_ratio`, `od_bv_over_disc`, `od_bv_over_gf`, `od_macula`, `od_gf`, `od_syringing`, `od_shirmers_test`, `od_gonioscopy`, `od_photograph_num`, `advice`, `folowup_date`, `followup_note`, `other_note`, `os_forehead`, `os_orbit`, `os_eye_brows`, `os_eye_lids`, `os_position_eyelids`, `os_skin_eyelids`, `os_margins_eyelids`, `os_lacrimal_app`, `os_eye_ball`, `os_moments_eyeball`, `os_conjunctiva`, `os_pulpebral_conjunctiva`, `os_bulbar_conjunctiva`, `os_size_cornea`, `os_surface_cornea`, `os_transparency_cornea`, `os_stroma_cornea`, `os_endothelium_cornea`, `os_ac_contant`, `os_ac_depth`, `os_iris_colour`, `os_iris_pattern`, `os_pupil_size`, `os_pupil_shape`, `os_pupil_reaction`, `os_lens`, `os_lens_opacity`, `os_iop`, `os_media`, `os_optic_disc`, `os_optic_disc_size`, `os_optic_disc_shape`, `os_optic_disc_colour`, `os_optic_disc_margine`, `os_cd_ratio`, `os_bv_over_disc`, `os_bv_over_gf`, `os_macula`, `os_gf`, `os_syringing`, `os_shirmers_test`, `os_gonioscopy`, `os_photograph_num`, `review_after`, `od_fundus`, `os_fundus`) VALUES
(41, 12, 'Rohit Deshpande', 27, 'Nausea  OD  5days  NCT OD , OS<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Epilation done<br>Diplopia  OD  1 wk  Epilation done,FB removed under TA<br>', '29', 'Male', '2023-06-05', '9907120508', 'ward no. 18 ', 'OD<br>OS<br>', 'Albinism<br>Amblyopia<br>', 'Apdrops LP eye drops<br>Bidin eye drops<br>', '3 times a day for<br>6 times a day for<br>', '2 wks<br>3 mth<br>', 'in Both Eyes<br>On eye lids<br>', 'BE Anterior Segment and Central Fundus NAD', 'HM N6', '6/6 N6', '6/6 N6', '6/6 N6', '6/6 N6\r\n						  ', '6/6 N6', 'Correct in all Q.', 'Correct in all Q.', '- 0.25', '~', '5', '6/6', '', '~', 'N6', '~', '~', '', '6/9', '', '+0.25', 'N6', 'IPD- 56', 'Chin down', 'Crusts', 'NAD', 'Madarosis', 'Atrophic bulbi', 'Lagophthalmos', 'L/W', 'Blepheritis ulcerative', 'NAD', 'Atrophic bulbi', 'Convergence weakness', 'Chemosis', 'Chemosis', 'Chemosis', 'Buphthalmos', 'Abrasion', 'Generalised corneal haze', 'Abcess', 'Edema', 'Cells', 'Deep', 'Heterochromia iridis', 'Arophied', 'Mydriasis', 'Central circular', 'Hippus', 'Aphakia', 'Aphakia', 'NAD', 'Astroid hylosis', 'Normal in s/s/c/m', 'Small', 'tilted', 'Hyperemic', 'Raised', 'cup filled', 'Nasal shifting', 'Arterial attenuation', 'NAD\r\n', 'NAD\r\n', 'NAD', 'NAD', 'NAD', 'test\r\n						  ', 'Blood sugar- Random\r\nCT, BT\r\n', '2023-06-16', 'testing', 'sucess', 'Scar mark', 'NAD', 'Raised', 'Anophthalmos', 'Lagophthalmos', 'Crusts', 'Blepheritis squamous', 'NAD', 'Anophthalmos', 'Restricted abd.', 'Chemosis', 'CC+', 'CC+', 'Buphthalmos', 'Bullous keratopathy', 'Generalised corneal haze', 'Edema', 'Edema', 'Forign body', 'Irregular', 'Heterochromia iridum', 'Arophied', 'Miosis', 'Irregular', 'Illsustained', 'Aphakia', 'Aphakia', 'NAD', 'Clear', 'Normal in s/s/c/m', 'Large', 'Hypoplegia', 'Hyperemic', 'Blurred', 'cup filled', 'attenuated', 'Arterial sclerosis', 'NAD\r\n', 'NAD\r\nBerlin\'s edema\r\n', 'NAD', 'NAD', 'NAD', 'test\r\n						  ', '1 wk', 'Direct', 'Direct');

-- --------------------------------------------------------

--
-- Table structure for table `prescription_analysis`
--

CREATE TABLE `prescription_analysis` (
  `id` int(11) NOT NULL,
  `eye` varchar(3) DEFAULT NULL,
  `sex` varchar(3) DEFAULT NULL,
  `freq` varchar(17) DEFAULT NULL,
  `duration` varchar(24) DEFAULT NULL,
  `va` varchar(5) DEFAULT NULL,
  `nva` varchar(3) DEFAULT NULL,
  `glass` varchar(6) DEFAULT NULL,
  `axis` varchar(4) DEFAULT NULL,
  `ad` varchar(5) DEFAULT NULL,
  `diagnosis` varchar(36) DEFAULT NULL,
  `drug` varchar(36) DEFAULT NULL,
  `co` varchar(24) DEFAULT NULL,
  `title` varchar(6) DEFAULT NULL,
  `adv` varchar(56) DEFAULT NULL,
  `note` varchar(30) DEFAULT NULL,
  `colour` varchar(13) DEFAULT NULL,
  `focal` varchar(40) DEFAULT NULL,
  `pd` varchar(7) DEFAULT NULL,
  `eye2` varchar(16) DEFAULT NULL,
  `head` varchar(10) DEFAULT NULL,
  `forehead` varchar(18) DEFAULT NULL,
  `eyebrows` varchar(9) DEFAULT NULL,
  `lid` varchar(200) NOT NULL,
  `lidposition` varchar(15) DEFAULT NULL,
  `lidskin` varchar(8) DEFAULT NULL,
  `lidmargine` varchar(22) DEFAULT NULL,
  `eyeball` varchar(14) DEFAULT NULL,
  `moments` varchar(20) DEFAULT NULL,
  `conjunctiva` varchar(11) DEFAULT NULL,
  `corneasize` varchar(12) DEFAULT NULL,
  `corneasurface` varchar(23) DEFAULT NULL,
  `transparency` varchar(24) DEFAULT NULL,
  `stroma` varchar(8) DEFAULT NULL,
  `endoth` varchar(8) DEFAULT NULL,
  `accontant` varchar(15) DEFAULT NULL,
  `acdepth` varchar(9) DEFAULT NULL,
  `iriscolour` varchar(20) DEFAULT NULL,
  `irispattern` varchar(23) DEFAULT NULL,
  `pupilsize` varchar(9) DEFAULT NULL,
  `pupilshape` varchar(16) DEFAULT NULL,
  `pupilreaction` varchar(23) DEFAULT NULL,
  `lens` varchar(15) DEFAULT NULL,
  `iop` varchar(3) DEFAULT NULL,
  `media` varchar(19) DEFAULT NULL,
  `opticdisc` varchar(17) DEFAULT NULL,
  `discsize` varchar(8) DEFAULT NULL,
  `discshape` varchar(10) DEFAULT NULL,
  `disccolour` varchar(10) DEFAULT NULL,
  `discmargine` varchar(21) DEFAULT NULL,
  `cdratio` varchar(20) DEFAULT NULL,
  `bvdisc` varchar(20) DEFAULT NULL,
  `bvgf` varchar(22) DEFAULT NULL,
  `macula` varchar(20) DEFAULT NULL,
  `gf` varchar(23) DEFAULT NULL,
  `nad` varchar(3) DEFAULT NULL,
  `pr` varchar(17) DEFAULT NULL,
  `beanteriorcf` varchar(42) DEFAULT NULL,
  `glasstype` varchar(11) DEFAULT NULL,
  `fundus` varchar(6) DEFAULT NULL,
  `patadv` varchar(74) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `prescription_analysis`
--

INSERT INTO `prescription_analysis` (`id`, `eye`, `sex`, `freq`, `duration`, `va`, `nva`, `glass`, `axis`, `ad`, `diagnosis`, `drug`, `co`, `title`, `adv`, `note`, `colour`, `focal`, `pd`, `eye2`, `head`, `forehead`, `eyebrows`, `lid`, `lidposition`, `lidskin`, `lidmargine`, `eyeball`, `moments`, `conjunctiva`, `corneasize`, `corneasurface`, `transparency`, `stroma`, `endoth`, `accontant`, `acdepth`, `iriscolour`, `irispattern`, `pupilsize`, `pupilshape`, `pupilreaction`, `lens`, `iop`, `media`, `opticdisc`, `discsize`, `discshape`, `disccolour`, `discmargine`, `cdratio`, `bvdisc`, `bvgf`, `macula`, `gf`, `nad`, `pr`, `beanteriorcf`, `glasstype`, `fundus`, `patadv`) VALUES
(2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'NAD', 'NAD', 'NAD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'NAD', '', 'NAD', '', 'NAD', 'NAD', '', '', '', '', 'NAD', '', '', '', '', '', '', 'BE Anterior Segment and Central Fundus NAD', 'ARK', 'NAD', ''),
(3, 'OD', 'M', 'Once a day for', '1day', '6/6', 'N6', '~', '5', '~', 'VA- 6/6, N6', '', '', '', '', '', 'English White', 'Bifocal lenses for constant use', 'IPD- 55', 'in Right Eye', 'NAD', 'NAD', 'NAD', 'Edema', 'Lagophthalmos', 'Crusts', 'NAD', 'NAD', 'NAD', 'NAD', 'NAD', 'NAD', 'NAD', 'NAD', 'NAD', 'NAD', 'NAD', 'NAD', 'NAD', 'NAD', 'Central circular', 'NAD', 'Aphakia', '', 'Clear', 'Normal in s/s/c/m', 'NAD', 'NAD', 'NAD', 'NAD', 'cup filled', 'NAD', 'NAD', 'NAD', 'NAD', 'NAD', 'Correct in all Q.', '', 'ARK (CYP)', 'Direct', 'Patient is advised to have-'),
(4, 'OS', 'F', 'Before sleep for', '2 days', '6/9', 'N8', '- 0.25', '10', '+0.25', 'VA (with old glasses)- 6/6, N6', 'Acivir 3% eye ointment', 'Burning sensation', 'Baby', 'Automated perimetry', 'NCT OD , OS', 'Photo Grey', 'Bifocal CR lenses for constant use', 'IPD- 56', 'in Left Eye', 'Chin down', 'Crusts', 'Raised', 'Echymosis  ', 'Ptosis mild', 'L/W', 'Blepheritis squamous', 'Atrophic bulbi', 'Convergence weakness', 'Chemosis', 'Buphthalmos', 'Abrasion', 'Generalised corneal haze', 'Abcess', 'Edema', 'Cells', 'Deep', 'Heterochromia iridis', 'Arophied', 'Miosis', 'Irregular', 'Hippus', 'APC', '', 'Astroid hylosis', '', 'Large', 'tilted', 'Hyperemic', 'Blurred', '0.1', 'attenuated', 'Arterial attenuation', 'AMD', 'Berlin\'s edema ', '', 'Defective in', '', 'ARK (atro)', 'IDO', 'Patient is reffered to GMH for further management'),
(5, 'OU', '', '2 times a day for', '3 days', '6/12', 'N10', '- 0.5', '15', '+0.50', 'Anterior segment - WNL', 'Acivir 5% skin ointment', 'Came for routine checkup', 'Dr.', 'B-Scan ultrasound', 'Epilation done', 'Photo Brown', 'D-bifocal CR lenses for constant use', 'IPD- 57', 'in Both Eyes', 'Chin up', 'Scar mark', 'Madarosis', '', 'Ptosis moderate', 'Vesicles', 'Blepheritis ulcerative', 'Anophthalmos', 'Restricted abd.', 'CC+', 'Cornea plana', 'Bullous keratopathy', 'Leuco. Opa.', 'Edema', 'Folds', 'Forign body', 'Irregular', 'Heterochromia iridum', 'Busacca\'s nodules', 'Mydriasis', 'Verically oval', 'Illsustained', 'Dislocated lens', '', 'Fibrous band', '', 'Small', 'Hypoplegia', 'Pale', 'Raised', '0.2', 'Nasal shifting', 'Arterial sclerosis', 'CME', 'Bony spicules', '', '', '', 'Old glasses', '', 'Patient is reffered to SNC, Chitrakot, for further management'),
(6, '', '', '3 times a day for', '5days', '6/18', 'N12', '- 0.75', '20', '+0.75', 'Central fundus - WNL', 'Acupat eye drops', 'Colored halos', 'Master', 'Bed rest for ', 'FB removed under TA', 'Opaque', 'D-bifocal lenses for constant use', 'IPD- 58', 'On eye lids', 'Right tilt', 'Vesicles', '', '', 'Ptosis severe', '', 'Chalazion', 'Enophthalmos', 'Restricted add.', 'CCC+', 'Keratoconus', 'Band shaped keratopathy', 'Nebular opa.', 'FB', 'KPs fine', 'Fibrin', 'Shallow', '', 'Coloboma iris', '', '', 'Motor defect (D-/C-)', 'Gr. I Nu', '', 'Hazy d/to LO', '', '', 'Coloboma', 'Waxy pale', 'Medullated NF', '0.3', 'NVD', 'A-V crossing changes', 'CNVM', 'CR deg.', '', '', '', '', '', 'Patient is reffered to Sankara Nethralaya, Chennai, for further management'),
(7, '', '', '4 times a day for', '1 wk', '6/24', 'N18', '- 1.0', '25', '+1.00', 'Acne rosacea', 'Alphagan eye drops', 'Deviation', 'Mr.', 'Blood sugar- Fasting & PP', 'H/O accidental instillation of', '', 'Executive lenses for constant use', 'IPD- 59', 'then as required', 'Right turn', 'Wrinkles excessive', '', '', '', '', 'Ectropion', 'Esophoria', 'Rstricted dep.', 'Conj. tear', 'Keratoglobus', 'Corneal abrasion', 'Macular opa.', 'Necrosis', 'KPs MF', 'Hyphaema', '', '', 'Iris bombe', '', '', 'Not reacting', 'Gr. II Nu', '', 'Hazy d/to Vit. Opa.', '', '', '', '', 'Peripapillary atrophy', '0.4', 'Tortuous', 'Gunn sign', 'CSME', 'Choroiditis active', '', '', '', '', '', 'Patient is reffered to LVPEI, Hyderabad, for further management'),
(8, '', '', '5 times a day for', '2 wks', '6/36', 'N36', '- 1.25', '30', '+1.25', 'Albinism', 'Aminogen eye drops', 'Diminution of Vn', 'Miss', 'Blood sugar- Random', 'H/O Allergy', '', 'High index lenses for constant use', 'IPD- 60', '', 'Left tilt', 'Wrinkles absent', '', '', '', '', 'Entropion', 'Esotropia', 'Restricted ele.', 'Conj. cyst', 'Megalocornea', 'Corneal Tear', '', '', 'Staining', 'Hypopeon', '', '', 'Koeppe nodule', '', '', 'RAPD', 'Gr. III Nu', '', 'PVD', '', '', '', '', 'Splinter h\'ge', '0.5', 'Venous pulsation +nt', 'NVE', 'CSCR', 'Choroiditis old', '', '', '', '', '', 'Patient is reffered to AIIMS, New Delhi, for further management'),
(9, '', '', '6 times a day for', '3 wks', '6/60', '', '- 1.5', '35', '+1.50', 'Allergic conjunctivitis', 'Apdrops KT eye drops', 'Difficulty in near Vn', 'Mrs.', 'CBC', 'H/O Asthuma', '', 'Kryptoc lenses', 'IPD- 61', '', 'Left turn', '', '', '', '', '', 'Hardeolum internum', 'Exophoria', '', 'Follicles', 'Microcornea', 'Corneal ulcer', '', '', '', 'Subluxated lens', '', '', 'Muddy', '', '', 'Sluggish', 'Gr. IV Nu', '', 'Sinchysis sintilens', '', '', '', '', 'Temporal creascent', '0.6', 'Venous pulsation -nt', 'Perivascular sheathing', 'Central choiditis', 'Chorioretinitis', '', '', '', '', '', ''),
(10, '', '', '2 hourly for', '4 wks', '5/60', '', '- 1.75', '40', '+1.75', 'Amblyopia', 'Apdrops LP eye drops', 'Diplopia', 'Prof.', 'Cataract surgery', 'H/O Blunt injury', '', 'Progressive CR lenses', 'IPD- 62', '', '', '', '', '', '', '', 'Matting of lashes', 'Exotropia', '', 'FB', '', 'Dendritic ulcer', '', '', '', 'Vitreous', '', '', 'Multiple post. Syneachi', '', '', 'Sensory defect (D-/ C+)', 'HMC', '', 'Vit cells', '', '', '', '', '', '0.7', '', 'Salus sign', 'Cherry red spot', 'Coloboma choroid', '', '', '', '', '', ''),
(11, '', '', '1 hourly for', '6 wks', '4/60', '', '- 2.0', '45', '+2.00', 'Aniridia', 'Aqualube eye drops', 'Discharge', '', 'Convergence exercise', 'H/O Cataract surgery', '', 'Progressive Glass lenses', 'IPD- 63', '', '', '', '', '', '', '', 'Meibomitis', 'Hyperphoria', '', 'Papillae', '', 'Filamentary Keratitis', '', '', '', '', '', '', 'PAS', '', '', '', 'Mature cat.', '', 'Vit floaters', '', '', '', '', '', '0.8', '', 'Venous dilation', 'Drusen', 'ERM', '', '', '', '', '', ''),
(12, '', '', 'as required', '1 mth', '3/60', '', '- 2.25', '50', '+2.25', 'Anisocoria', 'Atro 1% eye drops', 'Drooping of lid', '', 'CT, BT', 'H/O Diabetes', '', 'CR lenses for constant use', 'IPD- 64', '', '', '', '', '', '', '', 'Sty', 'Hypertropia', '', 'Pinguecula', '', 'Forign body', '', '', '', '', '', '', '', '', '', '', 'PACC', '', 'Vit heme', '', '', '', '', '', '0.9', '', 'Venous tortusity', 'ERM', 'Geographic atrophy', '', '', '', '', '', ''),
(13, '', '', '', '2 mth', '2/60', '', '- 2.5', '55', '+2.50', 'Anisometropia', 'Atro 1% eye ointment', 'Dryness', '', 'CT head including orbit', 'H/O Glaucoma surgry', '', 'CR lenses for Near work only', 'IPD- 65', '', '', '', '', '', '', '', 'Trichiasis', 'Hypophoria', '', 'Pterygium', '', 'PUK', '', '', '', '', '', '', '', '', '', '', 'PCO', '', 'Weiss ring', '', '', '', '', '', 'Glaucomatous atrophy', '', '', 'Foester fuch spot', 'Hard exudates', '', '', '', '', '', ''),
(14, '', '', '', '3 mth', '1/60', '', '- 2.75', '60', '+2.75', 'Anophthalmos', 'Betoact eye drops', 'Eye strain', '', 'CECT', 'H/O Hypertension', '', 'CR lenses (Separate for Distance & Near)', 'IPD- 66', '', '', '', '', '', '', '', '', 'Hypertropia', '', 'S/C h\'ge', '', 'SPK', '', '', '', '', '', '', '', '', '', '', 'PPC', '', '', '', '', '', '', '', 'ISNT disturbed', '', '', 'Geographical atrophy', 'H\'ge dot blot', '', '', '', '', '', ''),
(15, '', '', '', '6 mth', 'CF3\"', '', '- 3.0', '65', '+3.00', 'Aphakia', 'Bidin eye drops', 'FB sensation', '', 'Culture & sensitivity', 'H/O Injury by fall', '', 'Protective Polycarbonate Lenses', 'IPD- 67', '', '', '', '', '', '', '', '', 'Microphthalmos', '', '', '', 'Vascularisation deep', '', '', '', '', '', '', '', '', '', '', 'PSC', '', '', '', '', '', '', '', '', '', '', 'HE', 'H\'ge supeficial', '', '', '', '', '', ''),
(16, '', '', '', '1 year', 'CF2\"', '', '- 3.25', '70', '', 'ARMD', 'Bidin T eye drops', 'Flashes', '', 'Continue glaucoma medicines as per previous prescription', 'H/O injury by wooden stick', '', 'Glass lenses for constant use', 'IPD- 68', '', '', '', '', '', '', '', '', 'Proptosis', '', '', '', 'Vascularisation supf.', '', '', '', '', '', '', '', '', '', '', 'Phacodonensis', '', '', '', '', '', '', '', '', '', '', 'H\'ge dot', 'H\'ge subhyloid', '', '', '', '', '', ''),
(17, '', '', '', 'to continue in both eyes', 'CF1\"', '', '- 3.5', '75', '', 'Astigmatism', 'Bimat eye drops', 'Floaters', '', 'Dental checkup', 'H/O Joint pain', '', 'Glass lenses for Near Work only', 'IPD- 69', '', '', '', '', '', '', '', '', 'Pthisis bulbi', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Pig. Over ALC', '', '', '', '', '', '', '', '', '', '', 'H\'ge superficial', 'Hoarse shoe tear', '', '', '', '', '', ''),
(18, '', '', '', '', 'HM', '', '- 4.0', '80', '', 'Band shaped keratopathy', 'Bimat T eye drops', 'Headache', '', 'Dermatology opinion', 'H/O Lacrimal surgery', '', '', 'IPD- 70', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Pseudophakia', '', '', '', '', '', '', '', '', '', '', 'H\'ge subhyloid', 'Hole', '', '', '', '', '', ''),
(19, '', '', '', '', 'PL+', '', '- 4.5', '85', '', 'Basal cell carcinoma', 'Brinzox eye drops', 'Itching', '', 'ENT checkup', 'H/O Laser procedure', '', '', 'IPD- 71', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Subluxated lens', '', '', '', '', '', '', '', '', '', '', 'Hole atrophic', 'Lattice degeneration', '', '', '', '', '', ''),
(20, '', '', '', '', 'NoPL', '', '- 5.0', '90', '', 'Bell\'s Palsy', 'Cyclodex eye drops', 'Lid lag', '', 'ESR', 'H/O Retinal surgery', '', '', 'IPD- 72', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'MA', 'MA', '', '', '', '', '', ''),
(21, '', '', '', '', '', '', '- 6.0', '95', '', 'Bitot spots', 'Dilate eye drops', 'Nausea', '', 'FB Removal', 'H/O Squint surgery', '', '', 'IPD- 73', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Macular dystrophy', 'NVE', '', '', '', '', '', ''),
(22, '', '', '', '', '', '', '- 7.0', '100', '', 'Blepheritis Squamous', 'Diflucor eye drops', 'Night blindness', '', 'Fundus Fluoroscien angiography', 'H/O Trauma', '', '', 'IPD- 74', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Macula star', 'RD rhegmaogenous', '', '', '', '', '', ''),
(23, '', '', '', '', '', '', '- 8.0', '105', '', 'Blepheritis Ulcerative', 'Diflumox eye drops', 'Pain', '', 'Fundus examination under mydriasis', 'PST Inj Triacort 0.5cc given', '', '', 'IPD- 75', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Scaring', 'RD tractinal ', '', '', '', '', '', ''),
(24, '', '', '', '', '', '', '- 9.0', '110', '', 'Blue sclera', 'Dortas 2 % eye drops', 'Redness', '', 'Fundus photography', 'Reffered by Dr. ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'RD serous', '', '', '', '', '', ''),
(25, '', '', '', '', '', '', '- 10.0', '115', '', 'BRAO', 'Duobrom eye drops', 'Swelling', '', 'Glaucoma surgery', 'S/C Inj. Triacort 0.5cc given', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Roth\'s spots', '', '', '', '', '', ''),
(26, '', '', '', '', '', '', '+10.0', '120', '', 'BRVO', 'Eyebrex eye drops', 'Vomiting', '', 'Glycosylated Hb (HbA1c)', 'VISUAL PROGNOSIS EXPLAINED ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Serpegenous choroiditis', '', '', '', '', '', ''),
(27, '', '', '', '', '', '', '+9.0', '125', '', 'Bullous keratopathy', 'Eyedol eye drops', 'Watering', '', 'Gonioscopy', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Snow banking', '', '', '', '', '', ''),
(28, '', '', '', '', '', '', '+8.0', '130', '', 'Buphthalmos', 'FML- T eye drops', '', '', 'Hb', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Soft exudates', '', '', '', '', '', ''),
(29, '', '', '', '', '', '', '+7.0', '135', '', 'Cataract immature', 'Homide eye drops', '', '', 'I & C of chalazion', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Tomato Splash', '', '', '', '', '', ''),
(30, '', '', '', '', '', '', '+6.0', '140', '', 'Cataract mature', 'Hypersol eye drops', '', '', 'Incision and drainage', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(31, '', '', '', '', '', '', '+5.0', '145', '', 'Cellulitis', 'Hypersol- 6 eye ointment', '', '', 'Lacrimal sac massage as explained', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(32, '', '', '', '', '', '', '+4.5', '150', '', 'Central serous retinopathy', 'I Kul Plus eye drops', '', '', 'Lacrimal sac surgery', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(33, '', '', '', '', '', '', '+4.0', '155', '', 'Chalazion', 'I Dew eye drops', '', '', 'LASER capsulotomy', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(34, '', '', '', '', '', '', '+3.5', '160', '', 'Chemical injury', 'Itral eye ointment', '', '', 'Lipid Profile', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(35, '', '', '', '', '', '', '+3.25', '165', '', 'Choroiditis', 'Just Tears eye drops', '', '', 'Non contact tonometry', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(36, '', '', '', '', '', '', '+3.0', '170', '', 'Ciliary staphyloma', 'Ketogate eye drops', '', '', 'Medical checkup', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(37, '', '', '', '', '', '', '+2.75', '175', '', 'Coats disease', 'Ketopat eye drops', '', '', 'MRI orbit & brain', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(38, '', '', '', '', '', '', '+2.5', '180', '', 'Coloboma Choroid', 'Levotop PF eye drops ', '', '', 'Occlude Left eye for 6 hours/day for 3 months', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(39, '', '', '', '', '', '', '+2.25', '', '', 'Coloboma iris', 'Lotel Gel eye drops', '', '', 'Occlude Right eye for 6 hours/day for 3 months', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(40, '', '', '', '', '', '', '+2.0', '', '', 'Coloboma lens', 'Lopres 0.5% eye drops', '', '', 'Orthopedic checkup', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(41, '', '', '', '', '', '', '+1.75', '', '', 'Colour Blindness', 'Lotegate eye drops', '', '', 'Orthoptic workup', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(42, '', '', '', '', '', '', '+1.5', '', '', 'Comittent strabismus', 'Lubrex eye drops ', '', '', 'Pediatric checkup', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(43, '', '', '', '', '', '', '+1.25', '', '', 'Commotio retinae', 'Moxifax DX eye drops', '', '', 'Plane Antiglare glasses', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(44, '', '', '', '', '', '', '+1.0', '', '', 'Conjunctivitis allergic', 'Moxigram LX eye drops', '', '', 'Plane Photochromic glasses', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(45, '', '', '', '', '', '', '+0.75', '', '', 'Conjunctivitis mucopurulent', 'Nataforce 5% eye drops', '', '', 'Post mydriatic test on', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(46, '', '', '', '', '', '', '+0.5', '', '', 'Conjunctivitis vernal', 'Nebracin LP eye drops', '', '', 'Probing and syringing', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(47, '', '', '', '', '', '', '+0.25', '', '', 'Convergence weakness', 'Neosporin eye ointment', '', '', 'Pterygium Excision', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(48, '', '', '', '', '', '', '', '', '', 'Corneal abrasion', 'No Dry eye drops', '', '', 'RA factor', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(49, '', '', '', '', '', '', '', '', '', 'Corneal Opacity', 'Nuforce Lotion for head bath', '', '', 'Reffered back to Dr. for needful.', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(50, '', '', '', '', '', '', '', '', '', 'Corneal edema', 'Ocurest AH eye drops', '', '', 'Refraction in next visit', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(51, '', '', '', '', '', '', '', '', '', 'Corneal tear', 'Ocupol eye ointment', '', '', 'Second opinion', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(52, '', '', '', '', '', '', '', '', '', 'Corneal ulcer', 'Oflo-BM eye ointment', '', '', 'Syringing', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(53, '', '', '', '', '', '', '', '', '', 'CRAO', 'Olopat KT eye drops', '', '', 'T & D count', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(54, '', '', '', '', '', '', '', '', '', 'CRVO', 'Oxymoist eye drops', '', '', 'Urine R & M', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(55, '', '', '', '', '', '', '', '', '', 'Cyst', 'Pilocar 2% eye drops', '', '', 'Use Johnson Baby shampoo for cleaning of eye lashes', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(56, '', '', '', '', '', '', '', '', '', 'Dacryocystitis', 'Rapidon eye drops', '', '', 'X Ray orbit AP & Lat. - RE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(57, '', '', '', '', '', '', '', '', '', 'Dendritic ulcer', 'Refresh Tears eye drops', '', '', 'X Ray orbit AP & Lat. - LE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(58, '', '', '', '', '', '', '', '', '', 'Descematocele', 'Retane eye drops', '', '', 'X Ray PNS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(59, '', '', '', '', '', '', '', '', '', 'Diabetic retinopathy (Mild NPDR)', 'Softdrops eye drops', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(60, '', '', '', '', '', '', '', '', '', 'Diabetic retinopathy (Moderate NPDR)', 'Timolet Plus eye drops', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(61, '', '', '', '', '', '', '', '', '', 'Diabetic retinopathy (Severe NPDR)', 'Tropac - P eye drops', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(62, '', '', '', '', '', '', '', '', '', 'Diabetic retinopathy Proliferative', 'Toba DM eye drops', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(63, '', '', '', '', '', '', '', '', '', 'Dislocated lens', 'Tocin eye ointment', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(64, '', '', '', '', '', '', '', '', '', 'Dry eye', 'Tovoxo eye drops', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(65, '', '', '', '', '', '', '', '', '', 'Duane retraction syndrome', 'Virson gel eye ointment', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(66, '', '', '', '', '', '', '', '', '', 'Dyslexia', 'Vodamox LP eye drops', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(67, '', '', '', '', '', '', '', '', '', 'Eales disease', 'Xalatan eye drops', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(68, '', '', '', '', '', '', '', '', '', 'Ecchymosis', 'Zaha eye ointment', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(69, '', '', '', '', '', '', '', '', '', 'Ectropion', 'Zocon eye drops', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(70, '', '', '', '', '', '', '', '', '', 'Endophthalmitis', 'Zoline Gold eye drops', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(71, '', '', '', '', '', '', '', '', '', 'Entropion', 'Tab. Aciloc 150 mg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(72, '', '', '', '', '', '', '', '', '', 'Forign body', 'Tab. Acivir 800 mg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(73, '', '', '', '', '', '', '', '', '', 'Foveal dystrophy', 'Tab. Acivir 400 mg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(74, '', '', '', '', '', '', '', '', '', 'Epiphora', 'Tab. Alprax 0.5 mg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(75, '', '', '', '', '', '', '', '', '', 'Episcleritis', 'Cap. AstaGOLD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(76, '', '', '', '', '', '', '', '', '', 'Esophoria', 'Tab. Augmentin 625 mg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(77, '', '', '', '', '', '', '', '', '', 'Esotropia', 'Tab. Avil 50 mg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(78, '', '', '', '', '', '', '', '', '', 'Exophoria', 'Tab. Brutacef O', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(79, '', '', '', '', '', '', '', '', '', 'Exotropia', 'Tab. Brutacef 100 DT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(80, '', '', '', '', '', '', '', '', '', 'Exophthalmos', 'Tab. Cardimol Plus 5mg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(81, '', '', '', '', '', '', '', '', '', 'Glaucoma closed angle', 'Tab. Cardimol Plus 10mg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(82, '', '', '', '', '', '', '', '', '', 'Glaucoma open angle', 'Tab. Cifran 1 Gm', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(83, '', '', '', '', '', '', '', '', '', 'Glaucoma lens indused', 'Tab. Combiflam', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(84, '', '', '', '', '', '', '', '', '', 'Glaucoma juvenile', 'Tab. Cope MD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(85, '', '', '', '', '', '', '', '', '', 'Graves ophthalmopathy', 'Tab. Crocin Advance', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(86, '', '', '', '', '', '', '', '', '', 'Haemangioma', 'Tab. Crocin Pain Relief', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(87, '', '', '', '', '', '', '', '', '', 'Hemianopia', 'Tab. Diamox 250 mg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(88, '', '', '', '', '', '', '', '', '', 'Heterophoria', 'Tab. Dolokind SR', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(89, '', '', '', '', '', '', '', '', '', 'Hippus', 'Tab. Domcet', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(90, '', '', '', '', '', '', '', '', '', 'Hordeolum externum', 'Tab. Doxy 100 mg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(91, '', '', '', '', '', '', '', '', '', 'Hordeolum internum', 'Cap. Eyetamin Gold', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(92, '', '', '', '', '', '', '', '', '', 'Hypermetropia', 'Tab. Fungina 150 mg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(93, '', '', '', '', '', '', '', '', '', 'Hypertensive retinopathy', 'Tab. Graincide', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(94, '', '', '', '', '', '', '', '', '', 'Hyphaema', 'Tab. Grenil', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(95, '', '', '', '', '', '', '', '', '', 'Hypopeon', 'Tab. Gudgesic Plus', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(96, '', '', '', '', '', '', '', '', '', 'Hysterical blindness', 'Tab. Gudgesic AA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(97, '', '', '', '', '', '', '', '', '', 'Incomitant strabismus', 'Tab. Histafree M', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(98, '', '', '', '', '', '', '', '', '', 'Internal ophthalmoplegia', 'Tab. Levocet 5 mg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(99, '', '', '', '', '', '', '', '', '', 'Iris bombe', 'Tab. Levoflox 500 mg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(100, '', '', '', '', '', '', '', '', '', 'Iridocyclitis', 'Cap. Lutivit', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(101, '', '', '', '', '', '', '', '', '', 'Juvenile glaucoma', 'Cap. Lycosiya GT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(102, '', '', '', '', '', '', '', '', '', 'Kayser fleisher ring', 'Tab. Lyser D', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(103, '', '', '', '', '', '', '', '', '', 'Keratic precipitates', 'Tab. Moxikind CV 625 mg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(104, '', '', '', '', '', '', '', '', '', 'Keratitis disciform', 'Tab. Naxdom 500mg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(105, '', '', '', '', '', '', '', '', '', 'Keratitis exposure', 'Tab. Omnacortil 60 mg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(106, '', '', '', '', '', '', '', '', '', 'Keratitis fungal', '                               40 mg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(107, '', '', '', '', '', '', '', '', '', 'Keratitis herpes simplex', 'Tab. Rabikind 20 mg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(108, '', '', '', '', '', '', '', '', '', 'Keratitis herpes zoster', 'Tab. Solopose Beta 0.5', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(109, '', '', '', '', '', '', '', '', '', 'Keratitis interstitial', 'Tab. Vasograin', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(110, '', '', '', '', '', '', '', '', '', 'Keratitis pyogenous', 'Tab. Voveran 50 mg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(111, '', '', '', '', '', '', '', '', '', 'Keratitis phlyctenular', 'Cap. Vitakind-I', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(112, '', '', '', '', '', '', '', '', '', 'Keratitis superficial punctate', 'Tab. Taxim - O 200 mg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(113, '', '', '', '', '', '', '', '', '', 'Keratitis vernal', 'Tab. Taxim - O 100 mg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(114, '', '', '', '', '', '', '', '', '', 'Keratoconus', 'Syp. Sporidex 1 tsf', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(115, '', '', '', '', '', '', '', '', '', 'Lateral rectus palsy', 'Syp. Ibugesic Plus 1 tsf', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(116, '', '', '', '', '', '', '', '', '', 'Lens dislocation', 'Syp. Cobion 1 tsf', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(117, '', '', '', '', '', '', '', '', '', 'Lens subluxation', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(118, '', '', '', '', '', '', '', '', '', 'Lid laceration', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(119, '', '', '', '', '', '', '', '', '', 'Lid abcess', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(120, '', '', '', '', '', '', '', '', '', 'Macular dystrophy', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(121, '', '', '', '', '', '', '', '', '', 'Macular hole', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(122, '', '', '', '', '', '', '', '', '', 'Malingering', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(123, '', '', '', '', '', '', '', '', '', 'Mechanical injury', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(124, '', '', '', '', '', '', '', '', '', 'Migraine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(125, '', '', '', '', '', '', '', '', '', 'Microphakia', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(126, '', '', '', '', '', '', '', '', '', 'Mooren ulcer', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(127, '', '', '', '', '', '', '', '', '', 'Myopia', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(128, '', '', '', '', '', '', '', '', '', 'Neurotrophic keratitis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(129, '', '', '', '', '', '', '', '', '', 'Night blindness', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(130, '', '', '', '', '', '', '', '', '', 'Nodules', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(131, '', '', '', '', '', '', '', '', '', 'No Ophthalmic cause of headache', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(132, '', '', '', '', '', '', '', '', '', 'NVD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(133, '', '', '', '', '', '', '', '', '', 'NVE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(134, '', '', '', '', '', '', '', '', '', 'Nystagmus', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(135, '', '', '', '', '', '', '', '', '', 'Occlusio pupillae', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(136, '', '', '', '', '', '', '', '', '', 'Oculomotor nerve Palsy', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(137, '', '', '', '', '', '', '', '', '', 'Optic atrophy', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(138, '', '', '', '', '', '', '', '', '', 'Optic neuritis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(139, '', '', '', '', '', '', '', '', '', 'Optic neuropathy', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(140, '', '', '', '', '', '', '', '', '', 'Orbital Cellulitis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(141, '', '', '', '', '', '', '', '', '', 'Orbital Fracture', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(142, '', '', '', '', '', '', '', '', '', 'Papilloedema', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(143, '', '', '', '', '', '', '', '', '', 'Papillitis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(144, '', '', '', '', '', '', '', '', '', 'PACG', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(145, '', '', '', '', '', '', '', '', '', 'Paralytic strabismus', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(146, '', '', '', '', '', '', '', '', '', 'Penetrating injury', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(147, '', '', '', '', '', '', '', '', '', 'Phthisis bulbi', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(148, '', '', '', '', '', '', '', '', '', 'Pinguecula', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(149, '', '', '', '', '', '', '', '', '', 'POAG', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(150, '', '', '', '', '', '', '', '', '', 'Presbiopia', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(151, '', '', '', '', '', '', '', '', '', 'Preseptal Cellulits', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(152, '', '', '', '', '', '', '', '', '', 'Pseudophakia', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(153, '', '', '', '', '', '', '', '', '', 'Pseudoneuritis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(154, '', '', '', '', '', '', '', '', '', 'PVD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(155, '', '', '', '', '', '', '', '', '', 'PVR', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(156, '', '', '', '', '', '', '', '', '', 'Proptosis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(157, '', '', '', '', '', '', '', '', '', 'Pterygium', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(158, '', '', '', '', '', '', '', '', '', 'Ptosis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(159, '', '', '', '', '', '', '', '', '', 'RAPD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `prescription_analysis` (`id`, `eye`, `sex`, `freq`, `duration`, `va`, `nva`, `glass`, `axis`, `ad`, `diagnosis`, `drug`, `co`, `title`, `adv`, `note`, `colour`, `focal`, `pd`, `eye2`, `head`, `forehead`, `eyebrows`, `lid`, `lidposition`, `lidskin`, `lidmargine`, `eyeball`, `moments`, `conjunctiva`, `corneasize`, `corneasurface`, `transparency`, `stroma`, `endoth`, `accontant`, `acdepth`, `iriscolour`, `irispattern`, `pupilsize`, `pupilshape`, `pupilreaction`, `lens`, `iop`, `media`, `opticdisc`, `discsize`, `discshape`, `disccolour`, `discmargine`, `cdratio`, `bvdisc`, `bvgf`, `macula`, `gf`, `nad`, `pr`, `beanteriorcf`, `glasstype`, `fundus`, `patadv`) VALUES
(160, '', '', '', '', '', '', '', '', '', 'Retinal detachment', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(161, '', '', '', '', '', '', '', '', '', 'Retinitis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(162, '', '', '', '', '', '', '', '', '', 'Retinitis pigmentosa', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(163, '', '', '', '', '', '', '', '', '', 'Retinoblastoma', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(164, '', '', '', '', '', '', '', '', '', 'Retinopathy', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(165, '', '', '', '', '', '', '', '', '', 'Retinopathy of prematurity', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(166, '', '', '', '', '', '', '', '', '', 'Retinoschisis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(167, '', '', '', '', '', '', '', '', '', 'Retrobulbar neuritis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(168, '', '', '', '', '', '', '', '', '', 'Roth spots', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(169, '', '', '', '', '', '', '', '', '', 'S/P DCR', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(170, '', '', '', '', '', '', '', '', '', 'S/P DCT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(171, '', '', '', '', '', '', '', '', '', 'S/P IVA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(172, '', '', '', '', '', '', '', '', '', 'S/P IVTA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(173, '', '', '', '', '', '', '', '', '', 'S/P Keratoplasty', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(174, '', '', '', '', '', '', '', '', '', 'S/P LASER PI', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(175, '', '', '', '', '', '', '', '', '', 'S/P LASER Grid/Focal', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(176, '', '', '', '', '', '', '', '', '', 'S/P LASER PRP', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(177, '', '', '', '', '', '', '', '', '', 'S/P LASIK', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(178, '', '', '', '', '', '', '', '', '', 'S/P Trabeculectomy', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(179, '', '', '', '', '', '', '', '', '', 'S/P Vitrectomy', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(180, '', '', '', '', '', '', '', '', '', 'Scleritis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(181, '', '', '', '', '', '', '', '', '', 'Squamous cell carcinoma', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(182, '', '', '', '', '', '', '', '', '', 'Staphyloma anterior', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(183, '', '', '', '', '', '', '', '', '', 'Staphyloma posterior', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(184, '', '', '', '', '', '', '', '', '', 'Staphyloma ciliary', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(185, '', '', '', '', '', '', '', '', '', 'Stevens Johnson syndrome', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(186, '', '', '', '', '', '', '', '', '', 'Strabismus', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(187, '', '', '', '', '', '', '', '', '', 'Stargardt disease', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(188, '', '', '', '', '', '', '', '', '', 'Subconjunctival Hemorrhage', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(189, '', '', '', '', '', '', '', '', '', 'Subluxation of lens', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(190, '', '', '', '', '', '', '', '', '', 'Symblepharon', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(191, '', '', '', '', '', '', '', '', '', 'Sympathetic ophthalmitis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(192, '', '', '', '', '', '', '', '', '', 'Tolosa hunt syndrome', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(193, '', '', '', '', '', '', '', '', '', 'Total ophthalmoplegia', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(194, '', '', '', '', '', '', '', '', '', 'Traumatic cataract', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(195, '', '', '', '', '', '', '', '', '', 'Trichiasis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(196, '', '', '', '', '', '', '', '', '', 'Ulcer', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(197, '', '', '', '', '', '', '', '', '', 'Uveitis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(198, '', '', '', '', '', '', '', '', '', 'Vernal conjunctivitis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(199, '', '', '', '', '', '', '', '', '', 'Vitamine A deficiency', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(200, '', '', '', '', '', '', '', '', '', 'Vitreoretinal degeneration', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(201, '', '', '', '', '', '', '', '', '', 'Vitreous degeneration', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(202, '', '', '', '', '', '', '', '', '', 'Vitreous detachment', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(203, '', '', '', '', '', '', '', '', '', 'Vitreous hemorrhage', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(204, '', '', '', '', '', '', '', '', '', 'Weiss ring', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(205, '', '', '', '', '', '', '', '', '', 'Xerophthalmia', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(206, '', '', '', '', '', '', '', '', '', 'Zonular cataract', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `review_temp`
--

CREATE TABLE `review_temp` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `apid` int(11) NOT NULL,
  `duration` varchar(200) NOT NULL,
  `ins_date` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rx_temp`
--

CREATE TABLE `rx_temp` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `apid` int(11) NOT NULL,
  `drug` varchar(200) NOT NULL,
  `frequency` varchar(200) NOT NULL,
  `duration` varchar(200) NOT NULL,
  `eye` varchar(200) NOT NULL,
  `ins_date` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(12) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `middlename` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `password`, `firstname`, `middlename`, `lastname`) VALUES
(6, 'doctor', 'test123', 'Pratik', '', 'Deshpande');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `advice_temp`
--
ALTER TABLE `advice_temp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `co_temp`
--
ALTER TABLE `co_temp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `diagnosis_temp`
--
ALTER TABLE `diagnosis_temp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `examination_temp`
--
ALTER TABLE `examination_temp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `followup_temp`
--
ALTER TABLE `followup_temp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `glasses`
--
ALTER TABLE `glasses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `glasses_temp`
--
ALTER TABLE `glasses_temp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itr`
--
ALTER TABLE `itr`
  ADD PRIMARY KEY (`patient_id`);

--
-- Indexes for table `lab_report`
--
ALTER TABLE `lab_report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patients_visits`
--
ALTER TABLE `patients_visits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prescriptions`
--
ALTER TABLE `prescriptions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prescription_analysis`
--
ALTER TABLE `prescription_analysis`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `review_temp`
--
ALTER TABLE `review_temp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rx_temp`
--
ALTER TABLE `rx_temp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `advice_temp`
--
ALTER TABLE `advice_temp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `co_temp`
--
ALTER TABLE `co_temp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `diagnosis_temp`
--
ALTER TABLE `diagnosis_temp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `examination_temp`
--
ALTER TABLE `examination_temp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `followup_temp`
--
ALTER TABLE `followup_temp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `glasses`
--
ALTER TABLE `glasses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `glasses_temp`
--
ALTER TABLE `glasses_temp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `itr`
--
ALTER TABLE `itr`
  MODIFY `patient_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `lab_report`
--
ALTER TABLE `lab_report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `patients_visits`
--
ALTER TABLE `patients_visits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `prescriptions`
--
ALTER TABLE `prescriptions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `prescription_analysis`
--
ALTER TABLE `prescription_analysis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=207;

--
-- AUTO_INCREMENT for table `review_temp`
--
ALTER TABLE `review_temp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `rx_temp`
--
ALTER TABLE `rx_temp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
