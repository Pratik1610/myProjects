<!DOCTYPE html>
<?php
    ob_start();
	require_once 'logincheck.php';
	require_once 'authentication.php';
?>
<html lang = "eng">
	<head>
		<title>EyeCare</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "shortcut icon" href = "images/eye-gb51ecb13e_1280.PNG" />
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/customize.css" />
	</head>
<body>
	<div class = "navbar navbar-default navbar-fixed-top">
		<img src = "images/eye-gb51ecb13e_1280.PNG" style = "float:left;" height = "55px" /><label class = "navbar-brand">EyeCare</label>
			<?php
				$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
				$q = $conn->query("SELECT * FROM `user` WHERE `user_id` = '$_SESSION[user_id]'") or die(mysqli_error());
				$f = $q->fetch_array();
			?>
			<ul class = "nav navbar-right">	
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#">
						<span class = "glyphicon glyphicon-user"></span>
						<?php
							echo $f['firstname']." ".$f['lastname'];
							$conn->close();
						?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
					<li>
						<a class = "me" href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
	</div>
	<div id = "sidebar">
			<ul id = "menu" class = "nav menu">
				<li><a href = "home.php"><i class = "glyphicon glyphicon-home"></i> Dashboard</a></li>
				<li><a href = ""><i class = "glyphicon glyphicon-cog"></i> Accounts</a>
					<ul>
						<li><a href = "user.php"><i class = "glyphicon glyphicon-cog"></i> My Account</a></li>
					</ul>
				</li>
			</ul>
	</div>
	<div id = "content">
		<br />
		<br />
		<br />
		<div class = "panel panel-success">	
		<?php
			$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
			$query = $conn->query("SELECT * FROM `appointments` WHERE `id` = '$_GET[apid]'") or die(mysqli_error());
			$fetch = $query->fetch_array();
			$pid=$fetch["pid"]; // patient id
			$selp=mysqli_query($db,"select * from itr where patient_id='$pid'");
			$rowp=mysqli_fetch_array($selp);
		?>
			<div class = "panel-heading">
				<label>ADD Prescription</label>
				<a href = "home.php" class = "btn btn-sm btn-info" style = "float:right; margin-top:-5px;"><span class = "glyphicon glyphicon-hand-right"></span> BACK</a>
			</div>
			<div class = "panel-body">
				<form id = "form_admin" method = "POST" enctype = "multi-part/form-data" >
					<div class = "panel panel-default">
					<div class = "panel-heading">
					  <label>Patient Details</label>
					  <p><strong>Patient Name: </strong><?php echo ucwords($fetch["patient_name"]);?> &nbsp; &nbsp; 
				   <strong>Gender: </strong><?php echo ucwords($rowp["gender"]);?> &nbsp; &nbsp; 
				</p>
				<p><strong>Address: </strong><?php 
				if(!empty($rowp["house"]))
				{
					echo $rowp["house"]." ";
					$address=$rowp["house"]." ";
				}
				if(!empty($rowp["street"]))
				{
					echo $rowp["street"]." ";
					$address.=$rowp["street"]." ";
				}
				if(!empty($rowp["locality"]))
				{
					echo $rowp["locality"]." ";
					$address.=$rowp["locality"]." ";
				}
				if(!empty($rowp["city"]))
				{
					echo ",".$rowp["city"]." ";
					$address.=$rowp["city"]." ";
				}
				if(!empty($rowp["state"]))
				{
					echo $rowp["state"]." ";
					$address.=$rowp["state"]." ";
				}
				if(!empty($rowp["pin"]))
				{
					echo $rowp["pin"]." ";
					$address.=$rowp["pin"]." ";
				}
				?>
				</p>
					</div>
					</div>
					<table border="2px" width="1013">
<tbody>
<tr>
<td width="53">C/O-</td>
<td width="64">&nbsp;</td>
<td colspan="2" width="128">&nbsp;</td>
<td width="64">&nbsp;</td>
<td colspan="5" width="320">&nbsp;</td>
<td width="64">&nbsp;</td>
<td width="64">&nbsp;</td>
<td colspan="3" width="192">&nbsp;</td>
<td width="64">&nbsp;</td>
</tr>
<tr>
<td colspan="3">
<select name="co[]" class="form-control" required>
							<option value="">----Co----</option>
							<?php
							 $selco=mysqli_query($db,"select distinct co from prescription_analysis");
							 while($rowco=mysqli_fetch_array($selco))
							 {
							?>
							<option><?php echo $rowco["co"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="coeye[]" class="form-control" required>
							<option value="">----Eye----</option>
							<?php
							 $seleye=mysqli_query($db,"select distinct eye from prescription_analysis");
							 while($roweye=mysqli_fetch_array($seleye))
							 {
							?>
							<option><?php echo $roweye["eye"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="coduration[]" class="form-control">
							<option value="">----Duration----</option>
							<?php
							 $seldur=mysqli_query($db,"select distinct duration from prescription_analysis");
							 while($rowdur=mysqli_fetch_array($seldur))
							 {
							?>
							<option><?php echo $rowdur["duration"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="5">
<select name="conote" class="form-control">
							<option value="">----Note----</option>
							<?php
							 $selnote=mysqli_query($db,"select distinct note from prescription_analysis");
							 while($rownote=mysqli_fetch_array($selnote))
							 {
							?>
							<option><?php echo $rownote["note"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td width="64">&nbsp;</td>
<td width="64">&nbsp;</td>
<td colspan="3" width="192">&nbsp;</td>
<td width="64">&nbsp;</td>
</tr>
<tr>
<td colspan="3">
<select name="co[]" class="form-control" required>
							<option value="">----Co----</option>
							<?php
							 $selco=mysqli_query($db,"select distinct co from prescription_analysis");
							 while($rowco=mysqli_fetch_array($selco))
							 {
							?>
							<option><?php echo $rowco["co"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="coeye[]" class="form-control" required>
							<option value="">----Eye----</option>
							<?php
							 $seleye=mysqli_query($db,"select distinct eye from prescription_analysis");
							 while($roweye=mysqli_fetch_array($seleye))
							 {
							?>
							<option><?php echo $roweye["eye"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="coduration[]" class="form-control">
							<option value="">----Duration----</option>
							<?php
							 $seldur=mysqli_query($db,"select distinct duration from prescription_analysis");
							 while($rowdur=mysqli_fetch_array($seldur))
							 {
							?>
							<option><?php echo $rowdur["duration"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="5">
<select name="conote" class="form-control">
							<option value="">----Note----</option>
							<?php
							 $selnote=mysqli_query($db,"select distinct note from prescription_analysis");
							 while($rownote=mysqli_fetch_array($selnote))
							 {
							?>
							<option><?php echo $rownote["note"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>&nbsp;</td>
<td colspan="4">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">
<select name="co[]" class="form-control" required>
							<option value="">----Co----</option>
							<?php
							 $selco=mysqli_query($db,"select distinct co from prescription_analysis");
							 while($rowco=mysqli_fetch_array($selco))
							 {
							?>
							<option><?php echo $rowco["co"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="coeye[]" class="form-control" required>
							<option value="">----Eye----</option>
							<?php
							 $seleye=mysqli_query($db,"select distinct eye from prescription_analysis");
							 while($roweye=mysqli_fetch_array($seleye))
							 {
							?>
							<option><?php echo $roweye["eye"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="coduration[]" class="form-control">
							<option value="">----Duration----</option>
							<?php
							 $seldur=mysqli_query($db,"select distinct duration from prescription_analysis");
							 while($rowdur=mysqli_fetch_array($seldur))
							 {
							?>
							<option><?php echo $rowdur["duration"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="5">
<select name="conote" class="form-control">
							<option value="">----Note----</option>
							<?php
							 $selnote=mysqli_query($db,"select distinct note from prescription_analysis");
							 while($rownote=mysqli_fetch_array($selnote))
							 {
							?>
							<option><?php echo $rownote["note"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>&nbsp;</td>
<td colspan="4">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td colspan="4">&nbsp;</td>
<td>&nbsp;</td>
<td colspan="4">&nbsp;</td>
<td>&nbsp;</td>
<td colspan="4">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td><select name="eye[]" class="form-control" required>
							<option value="">----Eye----</option>
							<?php
							 $seleye=mysqli_query($db,"select distinct eye from prescription_analysis");
							 while($roweye=mysqli_fetch_array($seleye))
							 {
							?>
							<option><?php echo $roweye["eye"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="4">
<select name="diagnosis[]" class="form-control">
							<option value="">----Diagnosis----</option>
							<?php
							 $seldiagnosis=mysqli_query($db,"select distinct diagnosis from prescription_analysis");
							 while($rowdiagnosis=mysqli_fetch_array($seldiagnosis))
							 {
							?>
							<option><?php echo $rowdiagnosis["diagnosis"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="eye[]" class="form-control" required>
							<option value="">----Eye----</option>
							<?php
							 $seleye=mysqli_query($db,"select distinct eye from prescription_analysis");
							 while($roweye=mysqli_fetch_array($seleye))
							 {
							?>
							<option><?php echo $roweye["eye"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="4">
<select name="diagnosis[]" class="form-control">
							<option value="">----Diagnosis----</option>
							<?php
							 $seldiagnosis=mysqli_query($db,"select distinct diagnosis from prescription_analysis");
							 while($rowdiagnosis=mysqli_fetch_array($seldiagnosis))
							 {
							?>
							<option><?php echo $rowdiagnosis["diagnosis"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2" style="color:red;">DATE</td>
<td colspan="3" style="color:red;">FOLLOW UP NOTES</td>
<td>&nbsp;</td>
</tr>
<tr>
<td><select name="eye[]" class="form-control" required>
							<option value="">----Eye----</option>
							<?php
							 $seleye=mysqli_query($db,"select distinct eye from prescription_analysis");
							 while($roweye=mysqli_fetch_array($seleye))
							 {
							?>
							<option><?php echo $roweye["eye"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="4">
<select name="diagnosis[]" class="form-control">
							<option value="">----Diagnosis----</option>
							<?php
							 $seldiagnosis=mysqli_query($db,"select distinct diagnosis from prescription_analysis");
							 while($rowdiagnosis=mysqli_fetch_array($seldiagnosis))
							 {
							?>
							<option><?php echo $rowdiagnosis["diagnosis"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="eye[]" class="form-control" required>
							<option value="">----Eye----</option>
							<?php
							 $seleye=mysqli_query($db,"select distinct eye from prescription_analysis");
							 while($roweye=mysqli_fetch_array($seleye))
							 {
							?>
							<option><?php echo $roweye["eye"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="4">
<select name="diagnosis[]" class="form-control">
							<option value="">----Diagnosis----</option>
							<?php
							 $seldiagnosis=mysqli_query($db,"select distinct diagnosis from prescription_analysis");
							 while($rowdiagnosis=mysqli_fetch_array($seldiagnosis))
							 {
							?>
							<option><?php echo $rowdiagnosis["diagnosis"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<input class = "form-control" type = "date" name = "followup_date">
</td>
<td colspan="3"><textarea name="followup_note" class="form-control" rows="5" cols="143"></textarea></td>
<td>&nbsp;</td>
</tr>
<tr>
<td><select name="eye[]" class="form-control" required>
							<option value="">----Eye----</option>
							<?php
							 $seleye=mysqli_query($db,"select distinct eye from prescription_analysis");
							 while($roweye=mysqli_fetch_array($seleye))
							 {
							?>
							<option><?php echo $roweye["eye"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="4">
<select name="diagnosis[]" class="form-control">
							<option value="">----Diagnosis----</option>
							<?php
							 $seldiagnosis=mysqli_query($db,"select distinct diagnosis from prescription_analysis");
							 while($rowdiagnosis=mysqli_fetch_array($seldiagnosis))
							 {
							?>
							<option><?php echo $rowdiagnosis["diagnosis"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="eye[]" class="form-control" required>
							<option value="">----Eye----</option>
							<?php
							 $seleye=mysqli_query($db,"select distinct eye from prescription_analysis");
							 while($roweye=mysqli_fetch_array($seleye))
							 {
							?>
							<option><?php echo $roweye["eye"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="4">
<select name="diagnosis[]" class="form-control">
							<option value="">----Diagnosis----</option>
							<?php
							 $seldiagnosis=mysqli_query($db,"select distinct diagnosis from prescription_analysis");
							 while($rowdiagnosis=mysqli_fetch_array($seldiagnosis))
							 {
							?>
							<option><?php echo $rowdiagnosis["diagnosis"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">&nbsp;</td>
<td colspan="3">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>Rx</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td colspan="2">&nbsp;</td>
<td colspan="2">&nbsp;</td>
<td colspan="3">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td colspan="3">
<select name="drug[]" class="form-control">
							<option value="">----Drug----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct drug from prescription_analysis");
							 while($rowdrug=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowdrug["drug"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="freq[]" class="form-control">
							<option value="">----Frequency----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct freq from prescription_analysis");
							 while($rowfreq=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowfreq["freq"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="duration[]" class="form-control">
							<option value="">----Duration----</option>
							<?php
							 $seldur=mysqli_query($db,"select distinct duration from prescription_analysis");
							 while($rowdur=mysqli_fetch_array($seldur))
							 {
							?>
							<option><?php echo $rowdur["duration"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="deye[]" class="form-control">
							<option value="">----Diagnosis Eye----</option>
							<?php
							 $seldeye=mysqli_query($db,"select distinct eye2 from prescription_analysis");
							 while($rowdeye=mysqli_fetch_array($seldeye))
							 {
							?>
							<option><?php echo $rowdeye["eye2"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">&nbsp;</td>
<td colspan="3">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td colspan="3">
<select name="drug[]" class="form-control">
							<option value="">----Drug----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct drug from prescription_analysis");
							 while($rowdrug=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowdrug["drug"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="freq[]" class="form-control">
							<option value="">----Frequency----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct freq from prescription_analysis");
							 while($rowfreq=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowfreq["freq"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="duration[]" class="form-control">
							<option value="">----Duration----</option>
							<?php
							 $seldur=mysqli_query($db,"select distinct duration from prescription_analysis");
							 while($rowdur=mysqli_fetch_array($seldur))
							 {
							?>
							<option><?php echo $rowdur["duration"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="deye[]" class="form-control">
							<option value="">----Diagnosis Eye----</option>
							<?php
							 $seldeye=mysqli_query($db,"select distinct eye2 from prescription_analysis");
							 while($rowdeye=mysqli_fetch_array($seldeye))
							 {
							?>
							<option><?php echo $rowdeye["eye2"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">&nbsp;</td>
<td colspan="3">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td colspan="3">
<select name="drug[]" class="form-control">
							<option value="">----Drug----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct drug from prescription_analysis");
							 while($rowdrug=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowdrug["drug"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="freq[]" class="form-control">
							<option value="">----Frequency----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct freq from prescription_analysis");
							 while($rowfreq=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowfreq["freq"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="duration[]" class="form-control">
							<option value="">----Duration----</option>
							<?php
							 $seldur=mysqli_query($db,"select distinct duration from prescription_analysis");
							 while($rowdur=mysqli_fetch_array($seldur))
							 {
							?>
							<option><?php echo $rowdur["duration"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="deye[]" class="form-control">
							<option value="">----Diagnosis Eye----</option>
							<?php
							 $seldeye=mysqli_query($db,"select distinct eye2 from prescription_analysis");
							 while($rowdeye=mysqli_fetch_array($seldeye))
							 {
							?>
							<option><?php echo $rowdeye["eye2"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">&nbsp;</td>
<td colspan="3">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td colspan="3">
<select name="drug[]" class="form-control">
							<option value="">----Drug----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct drug from prescription_analysis");
							 while($rowdrug=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowdrug["drug"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="freq[]" class="form-control">
							<option value="">----Frequency----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct freq from prescription_analysis");
							 while($rowfreq=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowfreq["freq"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="duration[]" class="form-control">
							<option value="">----Duration----</option>
							<?php
							 $seldur=mysqli_query($db,"select distinct duration from prescription_analysis");
							 while($rowdur=mysqli_fetch_array($seldur))
							 {
							?>
							<option><?php echo $rowdur["duration"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="deye[]" class="form-control">
							<option value="">----Diagnosis Eye----</option>
							<?php
							 $seldeye=mysqli_query($db,"select distinct eye2 from prescription_analysis");
							 while($rowdeye=mysqli_fetch_array($seldeye))
							 {
							?>
							<option><?php echo $rowdeye["eye2"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">&nbsp;</td>
<td colspan="3">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td colspan="3">
<select name="drug[]" class="form-control">
							<option value="">----Drug----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct drug from prescription_analysis");
							 while($rowdrug=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowdrug["drug"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="freq[]" class="form-control">
							<option value="">----Frequency----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct freq from prescription_analysis");
							 while($rowfreq=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowfreq["freq"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="duration[]" class="form-control">
							<option value="">----Duration----</option>
							<?php
							 $seldur=mysqli_query($db,"select distinct duration from prescription_analysis");
							 while($rowdur=mysqli_fetch_array($seldur))
							 {
							?>
							<option><?php echo $rowdur["duration"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="deye[]" class="form-control">
							<option value="">----Diagnosis Eye----</option>
							<?php
							 $seldeye=mysqli_query($db,"select distinct eye2 from prescription_analysis");
							 while($rowdeye=mysqli_fetch_array($seldeye))
							 {
							?>
							<option><?php echo $rowdeye["eye2"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">&nbsp;</td>
<td colspan="3">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td colspan="3">
<select name="drug[]" class="form-control">
							<option value="">----Drug----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct drug from prescription_analysis");
							 while($rowdrug=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowdrug["drug"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="freq[]" class="form-control">
							<option value="">----Frequency----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct freq from prescription_analysis");
							 while($rowfreq=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowfreq["freq"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="duration[]" class="form-control">
							<option value="">----Duration----</option>
							<?php
							 $seldur=mysqli_query($db,"select distinct duration from prescription_analysis");
							 while($rowdur=mysqli_fetch_array($seldur))
							 {
							?>
							<option><?php echo $rowdur["duration"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="deye[]" class="form-control">
							<option value="">----Diagnosis Eye----</option>
							<?php
							 $seldeye=mysqli_query($db,"select distinct eye2 from prescription_analysis");
							 while($rowdeye=mysqli_fetch_array($seldeye))
							 {
							?>
							<option><?php echo $rowdeye["eye2"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">&nbsp;</td>
<td colspan="3">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td colspan="3">
<select name="drug[]" class="form-control">
							<option value="">----Drug----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct drug from prescription_analysis");
							 while($rowdrug=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowdrug["drug"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="freq[]" class="form-control">
							<option value="">----Frequency----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct freq from prescription_analysis");
							 while($rowfreq=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowfreq["freq"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="duration[]" class="form-control">
							<option value="">----Duration----</option>
							<?php
							 $seldur=mysqli_query($db,"select distinct duration from prescription_analysis");
							 while($rowdur=mysqli_fetch_array($seldur))
							 {
							?>
							<option><?php echo $rowdur["duration"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="deye[]" class="form-control">
							<option value="">----Diagnosis Eye----</option>
							<?php
							 $seldeye=mysqli_query($db,"select distinct eye2 from prescription_analysis");
							 while($rowdeye=mysqli_fetch_array($seldeye))
							 {
							?>
							<option><?php echo $rowdeye["eye2"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">&nbsp;</td>
<td colspan="3">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td colspan="3">
<select name="drug[]" class="form-control">
							<option value="">----Drug----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct drug from prescription_analysis");
							 while($rowdrug=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowdrug["drug"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="freq[]" class="form-control">
							<option value="">----Frequency----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct freq from prescription_analysis");
							 while($rowfreq=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowfreq["freq"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="duration[]" class="form-control">
							<option value="">----Duration----</option>
							<?php
							 $seldur=mysqli_query($db,"select distinct duration from prescription_analysis");
							 while($rowdur=mysqli_fetch_array($seldur))
							 {
							?>
							<option><?php echo $rowdur["duration"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="deye[]" class="form-control">
							<option value="">----Diagnosis Eye----</option>
							<?php
							 $seldeye=mysqli_query($db,"select distinct eye2 from prescription_analysis");
							 while($rowdeye=mysqli_fetch_array($seldeye))
							 {
							?>
							<option><?php echo $rowdeye["eye2"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">&nbsp;</td>
<td colspan="3">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td colspan="3">
<select name="drug[]" class="form-control">
							<option value="">----Drug----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct drug from prescription_analysis");
							 while($rowdrug=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowdrug["drug"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="freq[]" class="form-control">
							<option value="">----Frequency----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct freq from prescription_analysis");
							 while($rowfreq=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowfreq["freq"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="duration[]" class="form-control">
							<option value="">----Duration----</option>
							<?php
							 $seldur=mysqli_query($db,"select distinct duration from prescription_analysis");
							 while($rowdur=mysqli_fetch_array($seldur))
							 {
							?>
							<option><?php echo $rowdur["duration"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="deye[]" class="form-control">
							<option value="">----Diagnosis Eye----</option>
							<?php
							 $seldeye=mysqli_query($db,"select distinct eye2 from prescription_analysis");
							 while($rowdeye=mysqli_fetch_array($seldeye))
							 {
							?>
							<option><?php echo $rowdeye["eye2"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">&nbsp;</td>
<td colspan="3">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td colspan="3">
<select name="drug[]" class="form-control">
							<option value="">----Drug----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct drug from prescription_analysis");
							 while($rowdrug=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowdrug["drug"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="freq[]" class="form-control">
							<option value="">----Frequency----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct freq from prescription_analysis");
							 while($rowfreq=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowfreq["freq"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="duration[]" class="form-control">
							<option value="">----Duration----</option>
							<?php
							 $seldur=mysqli_query($db,"select distinct duration from prescription_analysis");
							 while($rowdur=mysqli_fetch_array($seldur))
							 {
							?>
							<option><?php echo $rowdur["duration"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="deye[]" class="form-control">
							<option value="">----Diagnosis Eye----</option>
							<?php
							 $seldeye=mysqli_query($db,"select distinct eye2 from prescription_analysis");
							 while($rowdeye=mysqli_fetch_array($seldeye))
							 {
							?>
							<option><?php echo $rowdeye["eye2"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">&nbsp;</td>
<td colspan="3">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td colspan="3">
<select name="drug[]" class="form-control">
							<option value="">----Drug----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct drug from prescription_analysis");
							 while($rowdrug=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowdrug["drug"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="freq[]" class="form-control">
							<option value="">----Frequency----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct freq from prescription_analysis");
							 while($rowfreq=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowfreq["freq"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="duration[]" class="form-control">
							<option value="">----Duration----</option>
							<?php
							 $seldur=mysqli_query($db,"select distinct duration from prescription_analysis");
							 while($rowdur=mysqli_fetch_array($seldur))
							 {
							?>
							<option><?php echo $rowdur["duration"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="deye[]" class="form-control">
							<option value="">----Diagnosis Eye----</option>
							<?php
							 $seldeye=mysqli_query($db,"select distinct eye2 from prescription_analysis");
							 while($rowdeye=mysqli_fetch_array($seldeye))
							 {
							?>
							<option><?php echo $rowdeye["eye2"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">&nbsp;</td>
<td colspan="3">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td colspan="3">
<select name="drug[]" class="form-control">
							<option value="">----Drug----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct drug from prescription_analysis");
							 while($rowdrug=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowdrug["drug"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="freq[]" class="form-control">
							<option value="">----Frequency----</option>
							<?php
							 $seldrug=mysqli_query($db,"select distinct freq from prescription_analysis");
							 while($rowfreq=mysqli_fetch_array($seldrug))
							 {
							?>
							<option><?php echo $rowfreq["freq"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="duration[]" class="form-control">
							<option value="">----Duration----</option>
							<?php
							 $seldur=mysqli_query($db,"select distinct duration from prescription_analysis");
							 while($rowdur=mysqli_fetch_array($seldur))
							 {
							?>
							<option><?php echo $rowdur["duration"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">
<select name="deye[]" class="form-control">
							<option value="">----Diagnosis Eye----</option>
							<?php
							 $seldeye=mysqli_query($db,"select distinct eye2 from prescription_analysis");
							 while($rowdeye=mysqli_fetch_array($seldeye))
							 {
							?>
							<option><?php echo $rowdeye["eye2"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2">&nbsp;</td>
<td colspan="3">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="2">GLASSES-</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td >&nbsp;</td>
<td  style="border:solid thin; border-width:2px; border-style:double;"  rowspan="2">&nbsp;</td>
<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="4">RE</td>
<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="4">LE</td>
<td  >&nbsp;</td>
<td  >&nbsp;</td>
<td  >&nbsp;</td>
<td  >&nbsp;</td>
<td  >&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td  >&nbsp;</td>
<td  style="border:solid thin; border-width:2px; border-style:double;">Sph.</td>
<td  style="border:solid thin; border-width:2px; border-style:double;">Cyl.</td>
<td  style="border:solid thin; border-width:2px; border-style:double;">Axis</td>
<td  style="border:solid thin; border-width:2px; border-style:double;">VA</td>
<td  style="border:solid thin; border-width:2px; border-style:double;">Sph.</td>
<td  style="border:solid thin; border-width:2px; border-style:double;">Cyl.</td>
<td  style="border:solid thin; border-width:2px; border-style:double;">Axis</td>
<td  style="border:solid thin; border-width:2px; border-style:double;">VA</td>
<td  >&nbsp;</td>
<td  >&nbsp;</td>
<td  >&nbsp;</td>
<td  >&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td  style="border:solid thin; border-width:2px; border-style:double;">Dist.</td>
<td  style="border:solid thin; border-width:2px; border-style:double;">
<select name="re_sph[]" class="form-control">
							<option value="">----Sph----</option>
							<?php
							 $selsph=mysqli_query($db,"select distinct glass from prescription_analysis");
							 while($rowsph=mysqli_fetch_array($selsph))
							 {
							?>
							<option><?php echo $rowsph["glass"];?></option>
							<?php
							 }
							 ?>
							 </select>

</td>
<td  style="border:solid thin; border-width:2px; border-style:double;">
<select name="re_cyl[]" class="form-control">
							<option value="">----Cyl----</option>
							<?php
							 $selcyl=mysqli_query($db,"select distinct glass from prescription_analysis");
							 while($rowcyl=mysqli_fetch_array($selcyl))
							 {
							?>
							<option><?php echo $rowcyl["glass"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td  style="border:solid thin; border-width:2px; border-style:double;">
<select name="re_axis[]" class="form-control">
							<option value="">----Axis----</option>
							<?php
							 $selaxis=mysqli_query($db,"select distinct axis from prescription_analysis");
							 while($rowaxis=mysqli_fetch_array($selaxis))
							 {
							?>
							<option><?php echo $rowaxis["axis"];?></option>
							<?php
							 }
							 ?>
							 </select>

</td>
<td  style="border:solid thin; border-width:2px; border-style:double;"><select name="re_va[]" class="form-control">
							<option value="">----Va----</option>
							<?php
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td  style="border:solid thin; border-width:2px; border-style:double;">
<select name="le_sph[]" class="form-control">
							<option value="">----Sph----</option>
							<?php
							 $selsph=mysqli_query($db,"select distinct glass from prescription_analysis");
							 while($rowsph=mysqli_fetch_array($selsph))
							 {
							?>
							<option><?php echo $rowsph["glass"];?></option>
							<?php
							 }
							 ?>
							 </select>

</td>
<td  style="border:solid thin; border-width:2px; border-style:double;">
<select name="le_cyl[]" class="form-control">
							<option value="">----Cyl----</option>
							<?php
							 $selcyl=mysqli_query($db,"select distinct glass from prescription_analysis");
							 while($rowcyl=mysqli_fetch_array($selcyl))
							 {
							?>
							<option><?php echo $rowcyl["glass"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td  style="border:solid thin; border-width:2px; border-style:double;">
<select name="le_axis[]" class="form-control">
							<option value="">----Axis----</option>
							<?php
							 $selaxis=mysqli_query($db,"select distinct axis from prescription_analysis");
							 while($rowaxis=mysqli_fetch_array($selaxis))
							 {
							?>
							<option><?php echo $rowaxis["axis"];?></option>
							<?php
							 }
							 ?>
							 </select>

</td>
<td  style="border:solid thin; border-width:2px; border-style:double;"><select name="le_va[]" class="form-control">
							<option value="">----Va----</option>
							<?php
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td  style="border:solid thin; border-width:2px; border-style:double;">Near</td>
<td  style="border:solid thin; border-width:2px; border-style:double;">Add</td>
<td style="border:solid thin; border-width:2px; border-style:double;" colspan="2">
<select name="re_add[]" class="form-control">
							<option value="">----Add----</option>
							<?php
							 $seladd=mysqli_query($db,"select distinct ad from prescription_analysis");
							 while($rowadd=mysqli_fetch_array($seladd))
							 {
							?>
							<option><?php echo $rowadd["ad"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td  style="border:solid thin; border-width:2px; border-style:double;">
<select name="re_nva[]" class="form-control">
							<option value="">----Nva----</option>
							<?php
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td  style="border:solid thin; border-width:2px; border-style:double;">Add</td>
<td style="border:solid thin; border-width:2px; border-style:double;" colspan="2">
<select name="le_add[]" class="form-control">
							<option value="">----Add----</option>
							<?php
							 $seladd=mysqli_query($db,"select distinct ad from prescription_analysis");
							 while($rowadd=mysqli_fetch_array($seladd))
							 {
							?>
							<option><?php echo $rowadd["ad"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td  style="border:solid thin; border-width:2px; border-style:double;">
<select name="le_nva[]" class="form-control">
							<option value="">----Nva----</option>
							<?php
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="2">English White</td>
<td  style="border:solid thin; border-width:2px; border-style:double;" colspan="5">CR lenses for constant use</td>
<td  style="border:solid thin; border-width:2px; border-style:double;"><select name="ipd[]" class="form-control">
							<option value="">----IPD----</option>
							<?php
							 $selipd=mysqli_query($db,"select distinct pd from prescription_analysis");
							 while($rowipd=mysqli_fetch_array($selipd))
							 {
							?>
							<option><?php echo $rowipd["pd"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td  style="border:solid thin; border-width:2px; border-style:double;">VD- 12</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td colspan="4">&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td colspan="3" width="192">&nbsp;</td>
<td width="64"></td>
<td colspan="2" width="128">&nbsp;</td>
</tr>
<tr>
<td colspan="9">Patient is advised to have-</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td width="64">&nbsp;</td>
<td width="64">&nbsp;</td>
<td width="64">&nbsp;</td>
<td width="64">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td colspan="4"><select name="advice[]" class="form-control" onchange="pushadvice()">
							<option value="">----Select Advice----</option>
							<?php
							 $seladv=mysqli_query($db,"select distinct adv from prescription_analysis");
							 while($rowadv=mysqli_fetch_array($seladv))
							 {
							?>
							<option><?php echo $rowadv["adv"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="4">
<select name="advice[]" class="form-control" onchange="pushadvice()">
							<option value="">----Select Advice----</option>
							<?php
							 $seladv=mysqli_query($db,"select distinct adv from prescription_analysis");
							 while($rowadv=mysqli_fetch_array($seladv))
							 {
							?>
							<option><?php echo $rowadv["adv"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td width="64">&nbsp;</td>
<td>&nbsp;</td>
<td width="64">&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td colspan="4"><select name="advice[]" class="form-control" onchange="pushadvice()">
							<option value="">----Select Advice----</option>
							<?php
							 $seladv=mysqli_query($db,"select distinct adv from prescription_analysis");
							 while($rowadv=mysqli_fetch_array($seladv))
							 {
							?>
							<option><?php echo $rowadv["adv"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="4">
<select name="advice[]" class="form-control" onchange="pushadvice()">
							<option value="">----Select Advice----</option>
							<?php
							 $seladv=mysqli_query($db,"select distinct adv from prescription_analysis");
							 while($rowadv=mysqli_fetch_array($seladv))
							 {
							?>
							<option><?php echo $rowadv["adv"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td width="64">&nbsp;</td>
<td width="64">&nbsp;</td>
<td width="64">&nbsp;</td>
<td width="64">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td colspan="4"><select name="advice[]" class="form-control" onchange="pushadvice()">
							<option value="">----Select Advice----</option>
							<?php
							 $seladv=mysqli_query($db,"select distinct adv from prescription_analysis");
							 while($rowadv=mysqli_fetch_array($seladv))
							 {
							?>
							<option><?php echo $rowadv["adv"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="4">
<select name="advice[]" class="form-control" onchange="pushadvice()">
							<option value="">----Select Advice----</option>
							<?php
							 $seladv=mysqli_query($db,"select distinct adv from prescription_analysis");
							 while($rowadv=mysqli_fetch_array($seladv))
							 {
							?>
							<option><?php echo $rowadv["adv"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td width="64">&nbsp;</td>
<td width="64">&nbsp;</td>
<td width="64">&nbsp;</td>
<td width="64">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td colspan="4"><select name="advice[]" class="form-control" onchange="pushadvice()">
							<option value="">----Select Advice----</option>
							<?php
							 $seladv=mysqli_query($db,"select distinct adv from prescription_analysis");
							 while($rowadv=mysqli_fetch_array($seladv))
							 {
							?>
							<option><?php echo $rowadv["adv"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="4">
<select name="advice[]" class="form-control" onchange="pushadvice()">
							<option value="">----Select Advice----</option>
							<?php
							 $seladv=mysqli_query($db,"select distinct adv from prescription_analysis");
							 while($rowadv=mysqli_fetch_array($seladv))
							 {
							?>
							<option><?php echo $rowadv["adv"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td width="64">&nbsp;</td>
<td width="64">&nbsp;</td>
<td width="64">&nbsp;</td>
<td width="64">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td colspan="4"><select name="advice[]" class="form-control" onchange="pushadvice()">
							<option value="">----Select Advice----</option>
							<?php
							 $seladv=mysqli_query($db,"select distinct adv from prescription_analysis");
							 while($rowadv=mysqli_fetch_array($seladv))
							 {
							?>
							<option><?php echo $rowadv["adv"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="4">
<select name="advice[]" class="form-control" onchange="pushadvice()">
							<option value="">----Select Advice----</option>
							<?php
							 $seladv=mysqli_query($db,"select distinct adv from prescription_analysis");
							 while($rowadv=mysqli_fetch_array($seladv))
							 {
							?>
							<option><?php echo $rowadv["adv"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td width="64">&nbsp;</td>
<td colspan="3" width="192">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td colspan="4">&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td width="64">&nbsp;</td>
<td colspan="3" width="192">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="2">Review after -</td>
<td>
<select name="ra" class="form-control">
							<option value="">----Select Duration-----</option>
							<?php
							 $selra=mysqli_query($db,"select distinct duration from prescription_analysis");
							 while($rowra=mysqli_fetch_array($selra))
							 {
							?>
							<option><?php echo $rowra["duration"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td colspan="5">&lt;Name of Doctor&gt;</td>
<td>&nbsp;</td>
<td width="64">&nbsp;</td>
<td colspan="3" width="192">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td colspan="3" width="192">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr style="border-width:5px; border-style:double;">
<td colspan="3">EXAMINATION</td>
<td colspan="12">
<select name="exam_head" class="form-control">
							<option value="">----Select----</option>
							<?php
							 $selehead=mysqli_query($db,"select distinct beanteriorcf from prescription_analysis");
							 while($rowehead=mysqli_fetch_array($selehead))
							 {
							?>
							<option><?php echo $rowehead["beanteriorcf"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">ANT. SEGMENT</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>OD</td>
<td colspan="2">&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>OS</td>
<td colspan="2">&nbsp;</td>
<td width="64">&nbsp;</td>
</tr>
<tr>
<td colspan="3" rowspan="2">Visual Acuity</td>
<td colspan="2">Unaided</td>
<td colspan="2">Old Spectacles</td>
<td colspan="2">PH/ SS</td>
<td colspan="2">Unaided</td>
<td colspan="2">Old Spectacles</td>
<td colspan="2">PH/ SS</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>
<select name="od_unaided_va" class="form-control">
							<option value="">----Select va----</option>
							<?php
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="od_unaided_nva" class="form-control">
							<option value="">----Select nva----</option>
							<?php
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="od_old_va" class="form-control">
							<option value="">----Select va----</option>
							<?php
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="od_old_nva" class="form-control">
							<option value="">----Select nva----</option>
							<?php
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="od_phss_va" class="form-control">
							<option value="">----Select va----</option>
							<?php
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
 <select name="od_phss_nva" class="form-control">
							<option value="">----Select nva----</option>
							<?php
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="os_unaided_va" class="form-control">
							<option value="">----Select va----</option>
							<?php
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="os_unaided_nva" class="form-control">
							<option value="">----Select nva----</option>
							<?php
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="os_old_va" class="form-control">
							<option value="">----Select va----</option>
							<?php
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="os_old_nva" class="form-control">
							<option value="">----Select nva----</option>
							<?php
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="os_phss_va" class="form-control">
							<option value="">----Select va----</option>
							<?php
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
 <select name="os_phss_nva" class="form-control">
							<option value="">----Select nva----</option>
							<?php
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">Projection of ray</td>
<td colspan="6">
<select id="od_pr[]" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selpr=mysqli_query($db,"select distinct pr from prescription_analysis");
							 while($rowpr=mysqli_fetch_array($selpr))
							 {
							?>
							<option><?php echo $rowpr["pr"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="6"><select id="os_pr[]" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selpr=mysqli_query($db,"select distinct pr from prescription_analysis");
							 while($rowpr=mysqli_fetch_array($selpr))
							 {
							?>
							<option><?php echo $rowpr["pr"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td width="64">&nbsp;</td>
</tr>
<tr>
<td colspan="3">ARK</td>
<td>Sph.</td>
<td>Cyl.</td>
<td>Axis</td>
<td>VA</td>
<td colspan="2">Comment</td>
<td>Sph.</td>
<td>Cyl.</td>
<td>Axis</td>
<td>VA</td>
<td colspan="2">Comment</td>
<td>&nbsp;</td>
</tr>
<tr>
<td rowspan="2">&nbsp;</td>
<td>IPD</td>
<td>Dist.</td>
<td>
<select name="od_sph" class="form-control">
							<option value="">----Select----</option>
							<?php
							 $selglass=mysqli_query($db,"select distinct glass from prescription_analysis");
							 while($rowglass=mysqli_fetch_array($selglass))
							 {
							?>
							<option><?php echo $rowglass["glass"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td><select name="od_cyl" class="form-control">
							<option value="">----Select----</option>
							<?php
							 $selglass=mysqli_query($db,"select distinct glass from prescription_analysis");
							 while($rowglass=mysqli_fetch_array($selglass))
							 {
							?>
							<option><?php echo $rowglass["glass"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>
<select name="od_axis" class="form-control">
							<option value="">----Select----</option>
							<?php
							 $selaxis=mysqli_query($db,"select distinct axis from prescription_analysis");
							 while($rowaxis=mysqli_fetch_array($selaxis))
							 {
							?>
							<option><?php echo $rowaxis["axis"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="od_va" class="form-control">
							<option value="">----Select va----</option>
							<?php
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2" rowspan="2"><input class = "form-control" type = "text" name = "od_comment"></td>
<td>
<select name="os_sph" class="form-control">
							<option value="">----Select----</option>
							<?php
							 $selglass=mysqli_query($db,"select distinct glass from prescription_analysis");
							 while($rowglass=mysqli_fetch_array($selglass))
							 {
							?>
							<option><?php echo $rowglass["glass"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td><select name="os_cyl" class="form-control">
							<option value="">----Select----</option>
							<?php
							 $selglass=mysqli_query($db,"select distinct glass from prescription_analysis");
							 while($rowglass=mysqli_fetch_array($selglass))
							 {
							?>
							<option><?php echo $rowglass["glass"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>
<select name="os_axis" class="form-control">
							<option value="">----Select----</option>
							<?php
							 $selaxis=mysqli_query($db,"select distinct axis from prescription_analysis");
							 while($rowaxis=mysqli_fetch_array($selaxis))
							 {
							?>
							<option><?php echo $rowaxis["axis"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="os_va" class="form-control">
							<option value="">----Select va----</option>
							<?php
							 $selva=mysqli_query($db,"select distinct va from prescription_analysis");
							 while($rowva=mysqli_fetch_array($selva))
							 {
							?>
							<option><?php echo $rowva["va"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="2" rowspan="2"><input class = "form-control" type = "text" name = "os_comment"></td>
<td>&nbsp;</td>
</tr>
<tr>
<td>
<select name="ipd" class="form-control">
							<option value="">----Select----</option>
							<?php
							 $selpd=mysqli_query($db,"select distinct pd from prescription_analysis");
							 while($rowpd=mysqli_fetch_array($selpd))
							 {
							?>
							<option><?php echo $rowpd["pd"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>Near</td>
<td>Add</td>
<td colspan="2"><select name="od_add" class="form-control">
							<option value="">----Select----</option>
							<?php
							 $seladd=mysqli_query($db,"select distinct ad from prescription_analysis");
							 while($rowadd=mysqli_fetch_array($seladd))
							 {
							?>
							<option><?php echo $rowadd["ad"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>
<select name="od_nva" class="form-control">
							<option value="">----Select nva----</option>
							<?php
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>Add</td>
<td colspan="2">
<select name="os_add" class="form-control">
							<option value="">----Select----</option>
							<?php
							 $seladd=mysqli_query($db,"select distinct ad from prescription_analysis");
							 while($rowadd=mysqli_fetch_array($seladd))
							 {
							?>
							<option><?php echo $rowadd["ad"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>
<select name="os_nva" class="form-control">
							<option value="">----Select nva----</option>
							<?php
							 $selnva=mysqli_query($db,"select distinct nva from prescription_analysis");
							 while($rownva=mysqli_fetch_array($selnva))
							 {
							?>
							<option><?php echo $rownva["nva"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">Head posture</td>
<td colspan="12">
<select name="head_posture" class="form-control">
							<option value="">----Select----</option>
							<?php
							 $selhead=mysqli_query($db,"select distinct head from prescription_analysis");
							 while($rowhead=mysqli_fetch_array($selhead))
							 {
							?>
							<option><?php echo $rowhead["head"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">Forehead</td>
<td colspan="6">
<select name="od_forehead" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selfhead=mysqli_query($db,"select distinct forehead from prescription_analysis");
							 while($rowfhead=mysqli_fetch_array($selfhead))
							 {
							?>
							<option><?php echo $rowfhead["forehead"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="6">
<select name="os_forehead" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selfhead=mysqli_query($db,"select distinct forehead from prescription_analysis");
							 while($rowfhead=mysqli_fetch_array($selfhead))
							 {
							?>
							<option><?php echo $rowfhead["forehead"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">Orbit</td>
<td colspan="6"><input class = "form-control" type = "text" name="od_orbit" placeholder="OD Orbit"></td>
<td colspan="6"><input class = "form-control" type = "text" name="os_orbit" placeholder="OS Orbit"></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">Eye brows</td>
<td colspan="6">
<select name="od_eyebrows" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $seleyebrows=mysqli_query($db,"select distinct eyebrows from prescription_analysis");
							 while($roweyebrows=mysqli_fetch_array($seleyebrows))
							 {
							?>
							<option><?php echo $roweyebrows["eyebrows"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="6">
<select name="os_eyebrows" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $seleyebrows=mysqli_query($db,"select distinct eyebrows from prescription_analysis");
							 while($roweyebrows=mysqli_fetch_array($seleyebrows))
							 {
							?>
							<option><?php echo $roweyebrows["eyebrows"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">Eye lids</td>
<td colspan="6">
<input class = "form-control" type = "text" name = "od_eye_lids" placeholder="OD Eye Lid">
</td>
<td colspan="6"><input class = "form-control" type = "text" name = "os_eye_lids" placeholder="OS Eye Lid"></td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td colspan="2">Position</td>
<td colspan="6"><select name="od_eyelid_position" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $sellidpos=mysqli_query($db,"select distinct lidposition from prescription_analysis");
							 while($rowlidpos=mysqli_fetch_array($sellidpos))
							 {
							?>
							<option><?php echo $rowlidpos["lidposition"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6">
<select name="os_eyelid_position" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $sellidpos=mysqli_query($db,"select distinct lidposition from prescription_analysis");
							 while($rowlidpos=mysqli_fetch_array($sellidpos))
							 {
							?>
							<option><?php echo $rowlidpos["lidposition"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td colspan="2">Skin</td>
<td colspan="6">
<select name="od_eyelid_skin" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $sellidskin=mysqli_query($db,"select distinct lidskin from prescription_analysis");
							 while($rowlidskin=mysqli_fetch_array($sellidskin))
							 {
							?>
							<option><?php echo $rowlidskin["lidskin"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="6">
<select name="os_eyelid_skin" class="form-control">
<option value="">----Select for OS----</option>
							<?php
							 $sellidskin=mysqli_query($db,"select distinct lidskin from prescription_analysis");
							 while($rowlidskin=mysqli_fetch_array($sellidskin))
							 {
							?>
							<option><?php echo $rowlidskin["lidskin"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td colspan="2">Margins</td>
<td colspan="6"><select name="od_eyelid_margine" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $sellidmargine=mysqli_query($db,"select distinct lidmargine from prescription_analysis");
							 while($rowlidmargine=mysqli_fetch_array($sellidmargine))
							 {
							?>
							<option><?php echo $rowlidmargine["lidmargine"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_eyelid_margine" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $sellidmargine=mysqli_query($db,"select distinct lidmargine from prescription_analysis");
							 while($rowlidmargine=mysqli_fetch_array($sellidmargine))
							 {
							?>
							<option><?php echo $rowlidmargine["lidmargine"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">Lacrimal app.</td>
<td colspan="6"><input class = "form-control" type = "text" name = "od_lacrimal_app" placeholder="OD Lacrimal App"></td>
<td colspan="6"><input class = "form-control" type = "text" name = "os_lacrimal_app" placeholder="OS Lacrimal App"></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">Eye ball</td>
<td colspan="6"><select name="od_eye_ball" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $seleyeball=mysqli_query($db,"select distinct eyeball from prescription_analysis");
							 while($roweyeball=mysqli_fetch_array($seleyeball))
							 {
							?>
							<option><?php echo $roweyeball["eyeball"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_eye_ball" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $seleyeball=mysqli_query($db,"select distinct eyeball from prescription_analysis");
							 while($roweyeball=mysqli_fetch_array($seleyeball))
							 {
							?>
							<option><?php echo $roweyeball["eyeball"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td colspan="2">Moments</td>
<td colspan="6"><select name="od_eyeball_moments" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selmoment=mysqli_query($db,"select distinct moments from prescription_analysis");
							 while($rowmoment=mysqli_fetch_array($selmoment))
							 {
							?>
							<option><?php echo $rowmoment["moments"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_eyeball_moments" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selmoment=mysqli_query($db,"select distinct moments from prescription_analysis");
							 while($rowmoment=mysqli_fetch_array($selmoment))
							 {
							?>
							<option><?php echo $rowmoment["moments"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">Conjunctiva</td>
<td colspan="6">
<select name="od_conjunctiva" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selconjunctiva=mysqli_query($db,"select distinct conjunctiva from prescription_analysis");
							 while($rowconjunctiva=mysqli_fetch_array($selconjunctiva))
							 {
							?>
							<option><?php echo $rowconjunctiva["conjunctiva"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="6">
 <select name="os_conjunctiva" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selconjunctiva=mysqli_query($db,"select distinct conjunctiva from prescription_analysis");
							 while($rowconjunctiva=mysqli_fetch_array($selconjunctiva))
							 {
							?>
							<option><?php echo $rowconjunctiva["conjunctiva"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>&nbsp;</td>
</tr>
<tr>
<td rowspan="2">&nbsp;</td>
<td colspan="2">Palpebral</td>
<td colspan="6"><select name="od_pulpebral_conjunctiva" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selpulp=mysqli_query($db,"select distinct conjunctiva from prescription_analysis");
							 while($rowpulp=mysqli_fetch_array($selpulp))
							 {
							?>
							<option><?php echo $rowpulp["conjunctiva"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_pulpebral_conjunctiva" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selpulp=mysqli_query($db,"select distinct conjunctiva from prescription_analysis");
							 while($rowpulp=mysqli_fetch_array($selpulp))
							 {
							?>
							<option><?php echo $rowpulp["conjunctiva"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="2">Bulbar</td>
<td colspan="6"><select name="od_bulbar_conjunctiva" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selbulbar=mysqli_query($db,"select distinct conjunctiva from prescription_analysis");
							 while($rowbulbar=mysqli_fetch_array($selbulbar))
							 {
							?>
							<option><?php echo $rowbulbar["conjunctiva"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_bulbar_conjunctiva" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selbulbar=mysqli_query($db,"select distinct conjunctiva from prescription_analysis");
							 while($rowbulbar=mysqli_fetch_array($selbulbar))
							 {
							?>
							<option><?php echo $rowbulbar["conjunctiva"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">Sclera</td>
<td colspan="6">&nbsp;</td>
<td colspan="6">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">Cornea</td>
<td colspan="6">&nbsp;</td>
<td colspan="6">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td rowspan="5">&nbsp;</td>
<td colspan="2">Size</td>
<td colspan="6">
<select name="od_cornea_size" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selcsize=mysqli_query($db,"select distinct corneasize from prescription_analysis");
							 while($rowcsize=mysqli_fetch_array($selcsize))
							 {
							?>
							<option><?php echo $rowcsize["corneasize"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="6">
<select name="os_cornea_size" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selcsize=mysqli_query($db,"select distinct corneasize from prescription_analysis");
							 while($rowcsize=mysqli_fetch_array($selcsize))
							 {
							?>
							<option><?php echo $rowcsize["corneasize"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="2">Surface</td>
<td colspan="6"><select name="od_cornea_surface" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selcsurface=mysqli_query($db,"select distinct corneasurface from prescription_analysis");
							 while($rowcsurface=mysqli_fetch_array($selcsurface))
							 {
							?>
							<option><?php echo $rowcsurface["corneasurface"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_cornea_surface" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selcsurface=mysqli_query($db,"select distinct corneasurface from prescription_analysis");
							 while($rowcsurface=mysqli_fetch_array($selcsurface))
							 {
							?>
							<option><?php echo $rowcsurface["corneasurface"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="2">Tansparancy</td>
<td colspan="6"><select name="od_transparency" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $seltransparency=mysqli_query($db,"select distinct transparency from prescription_analysis");
							 while($rowtransparency=mysqli_fetch_array($seltransparency))
							 {
							?>
							<option><?php echo $rowtransparency["transparency"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"> <select name="os_transparency" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $seltransparency=mysqli_query($db,"select distinct transparency from prescription_analysis");
							 while($rowtransparency=mysqli_fetch_array($seltransparency))
							 {
							?>
							<option><?php echo $rowtransparency["transparency"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="2">Stroma</td>
<td colspan="6"><select name="od_stroma" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selstroma=mysqli_query($db,"select distinct stroma from prescription_analysis");
							 while($rowstroma=mysqli_fetch_array($selstroma))
							 {
							?>
							<option><?php echo $rowstroma["stroma"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"> <select name="os_stroma" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selstroma=mysqli_query($db,"select distinct stroma from prescription_analysis");
							 while($rowstroma=mysqli_fetch_array($selstroma))
							 {
							?>
							<option><?php echo $rowstroma["stroma"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="2">Endothelium</td>
<td colspan="6"><select name="od_endothelium" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selendoth=mysqli_query($db,"select distinct endoth from prescription_analysis");
							 while($rowendoth=mysqli_fetch_array($selendoth))
							 {
							?>
							<option><?php echo $rowendoth["endoth"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_endothelium" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selendoth=mysqli_query($db,"select distinct endoth from prescription_analysis");
							 while($rowendoth=mysqli_fetch_array($selendoth))
							 {
							?>
							<option><?php echo $rowendoth["endoth"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">AC</td>
<td colspan="6">&nbsp;</td>
<td colspan="6">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td rowspan="2">&nbsp;</td>
<td colspan="2">Contant</td>
<td colspan="6">	<select name="od_accontant" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selaccontant=mysqli_query($db,"select distinct accontant from prescription_analysis");
							 while($rowaccontant=mysqli_fetch_array($selaccontant))
							 {
							?>
							<option><?php echo $rowaccontant["accontant"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_accontant" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selaccontant=mysqli_query($db,"select distinct accontant from prescription_analysis");
							 while($rowaccontant=mysqli_fetch_array($selaccontant))
							 {
							?>
							<option><?php echo $rowaccontant["accontant"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="2">Depth</td>
<td colspan="6">
<select name="od_acdepth" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selacdepth=mysqli_query($db,"select distinct acdepth from prescription_analysis");
							 while($rowacdepth=mysqli_fetch_array($selacdepth))
							 {
							?>
							<option><?php echo $rowacdepth["acdepth"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="6">
<select name="os_acdepth" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selacdepth=mysqli_query($db,"select distinct acdepth from prescription_analysis");
							 while($rowacdepth=mysqli_fetch_array($selacdepth))
							 {
							?>
							<option><?php echo $rowacdepth["acdepth"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">Iris</td>
<td colspan="6">&nbsp;</td>
<td colspan="6">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td rowspan="2">&nbsp;</td>
<td colspan="2">Colour</td>
<td colspan="6"><select name="od_iriscolour" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $seliriscolour=mysqli_query($db,"select distinct iriscolour from prescription_analysis");
							 while($rowiriscolour=mysqli_fetch_array($seliriscolour))
							 {
							?>
							<option><?php echo $rowiriscolour["iriscolour"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_iriscolour" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $seliriscolour=mysqli_query($db,"select distinct iriscolour from prescription_analysis");
							 while($rowiriscolour=mysqli_fetch_array($seliriscolour))
							 {
							?>
							<option><?php echo $rowiriscolour["iriscolour"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="2">Pattern</td>
<td colspan="6"><select name="od_irispattern" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selirispattern=mysqli_query($db,"select distinct irispattern from prescription_analysis");
							 while($rowirispattern=mysqli_fetch_array($selirispattern))
							 {
							?>
							<option><?php echo $rowirispattern["irispattern"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_irispattern" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selirispattern=mysqli_query($db,"select distinct irispattern from prescription_analysis");
							 while($rowirispattern=mysqli_fetch_array($selirispattern))
							 {
							?>
							<option><?php echo $rowirispattern["irispattern"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">Pulpil</td>
<td colspan="6">&nbsp;</td>
<td colspan="6">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td rowspan="3">&nbsp;</td>
<td colspan="2">Size</td>
<td colspan="6">
<select name="od_pupilsize" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selpupilsize=mysqli_query($db,"select distinct pupilsize from prescription_analysis");
							 while($rowpupilsize=mysqli_fetch_array($selpupilsize))
							 {
							?>
							<option><?php echo $rowpupilsize["pupilsize"];?></option>
							<?php
							 }
							 ?>
							 </select>
</td>
<td colspan="6"><select name="os_pupilsize" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selpupilsize=mysqli_query($db,"select distinct pupilsize from prescription_analysis");
							 while($rowpupilsize=mysqli_fetch_array($selpupilsize))
							 {
							?>
							<option><?php echo $rowpupilsize["pupilsize"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="2">Shape</td>
<td colspan="6"><select name="od_pupilshape" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selpupilshape=mysqli_query($db,"select distinct pupilshape from prescription_analysis");
							 while($rowpupilshape=mysqli_fetch_array($selpupilshape))
							 {
							?>
							<option><?php echo $rowpupilshape["pupilshape"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"> <select name="os_pupilshape" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selpupilshape=mysqli_query($db,"select distinct pupilshape from prescription_analysis");
							 while($rowpupilshape=mysqli_fetch_array($selpupilshape))
							 {
							?>
							<option><?php echo $rowpupilshape["pupilshape"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="2">Reaction</td>
<td colspan="6"><select name="od_pupilreaction" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selpupilreaction=mysqli_query($db,"select distinct pupilreaction from prescription_analysis");
							 while($rowpupilreaction=mysqli_fetch_array($selpupilreaction))
							 {
							?>
							<option><?php echo $rowpupilreaction["pupilreaction"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_pupilreaction" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selpupilreaction=mysqli_query($db,"select distinct pupilreaction from prescription_analysis");
							 while($rowpupilreaction=mysqli_fetch_array($selpupilreaction))
							 {
							?>
							<option><?php echo $rowpupilreaction["pupilreaction"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">Lens</td>
<td colspan="6">&nbsp;</td>
<td colspan="6">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td colspan="2">Opacity</td>
<td colspan="6"><select name="od_lens_opacity" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $sellens_opacity=mysqli_query($db,"select distinct lens from prescription_analysis");
							 while($rowlens=mysqli_fetch_array($sellens_opacity))
							 {
							?>
							<option><?php echo $rowlens["lens"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_lens_opacity" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $sellens_opacity=mysqli_query($db,"select distinct lens from prescription_analysis");
							 while($rowlens=mysqli_fetch_array($sellens_opacity))
							 {
							?>
							<option><?php echo $rowlens["lens"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">IOP</td>
<td colspan="6"><input class = "form-control" type = "text" name = "od_IOP" placeholder="OD IOP"></td>
<td colspan="6"><input class = "form-control" type = "text" name = "os_IOP" placeholder="OS IOP"></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="2">Fundus</td>
<td>Direct</td>
<td colspan="6">&nbsp;</td>
<td colspan="6">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">Media</td>
<td colspan="6"><select name="od_media" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selmedia=mysqli_query($db,"select distinct media from prescription_analysis");
							 while($rowmedia=mysqli_fetch_array($selmedia))
							 {
							?>
							<option><?php echo $rowmedia["media"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_media" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selmedia=mysqli_query($db,"select distinct media from prescription_analysis");
							 while($rowmedia=mysqli_fetch_array($selmedia))
							 {
							?>
							<option><?php echo $rowmedia["media"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">Optic Disc</td>
<td colspan="6"><select name="od_optic_disc" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $seloptic=mysqli_query($db,"select distinct opticdisc from prescription_analysis");
							 while($rowoptic=mysqli_fetch_array($seloptic))
							 {
							?>
							<option><?php echo $rowoptic["opticdisc"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_optic_disc" class="form-control"><option value="">----Select for OS----</option>
							<?php
							 $seloptic=mysqli_query($db,"select distinct opticdisc from prescription_analysis");
							 while($rowoptic=mysqli_fetch_array($seloptic))
							 {
							?>
							<option><?php echo $rowoptic["opticdisc"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td colspan="2">Size</td>
<td colspan="6"><select name="od_disc_size" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $seldiscsize=mysqli_query($db,"select distinct discsize from prescription_analysis");
							 while($rowdiscsize=mysqli_fetch_array($seldiscsize))
							 {
							?>
							<option><?php echo $rowdiscsize["discsize"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_disc_size" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $seldiscsize=mysqli_query($db,"select distinct discsize from prescription_analysis");
							 while($rowdiscsize=mysqli_fetch_array($seldiscsize))
							 {
							?>
							<option><?php echo $rowdiscsize["discsize"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td colspan="2">Shape</td>
<td colspan="6"><select name="od_disc_shape" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $seldiscshape=mysqli_query($db,"select distinct discshape from prescription_analysis");
							 while($rowdiscshape=mysqli_fetch_array($seldiscshape))
							 {
							?>
							<option><?php echo $rowdiscshape["discshape"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_disc_shape" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $seldiscshape=mysqli_query($db,"select distinct discshape from prescription_analysis");
							 while($rowdiscshape=mysqli_fetch_array($seldiscshape))
							 {
							?>
							<option><?php echo $rowdiscshape["discshape"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td colspan="2">Colour</td>
<td colspan="6"><select name="od_disc_colour" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $seldisccolour=mysqli_query($db,"select distinct disccolour from prescription_analysis");
							 while($rowdisccolour=mysqli_fetch_array($seldisccolour))
							 {
							?>
							<option><?php echo $rowdisccolour["disccolour"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_disc_colour" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $seldisccolour=mysqli_query($db,"select distinct disccolour from prescription_analysis");
							 while($rowdisccolour=mysqli_fetch_array($seldisccolour))
							 {
							?>
							<option><?php echo $rowdisccolour["disccolour"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td colspan="2">Margine</td>
<td colspan="6"><select name="od_disc_margine" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $seldiscmargine=mysqli_query($db,"select distinct discmargine from prescription_analysis");
							 while($rowdiscmargine=mysqli_fetch_array($seldiscmargine))
							 {
							?>
							<option><?php echo $rowdiscmargine["discmargine"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_disc_margine" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $seldiscmargine=mysqli_query($db,"select distinct discmargine from prescription_analysis");
							 while($rowdiscmargine=mysqli_fetch_array($seldiscmargine))
							 {
							?>
							<option><?php echo $rowdiscmargine["discmargine"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">C:D ratio</td>
<td colspan="6"><select name="od_cd_ratio" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selcdratio=mysqli_query($db,"select distinct cdratio from prescription_analysis");
							 while($rowcdratio=mysqli_fetch_array($selcdratio))
							 {
							?>
							<option><?php echo $rowcdratio["cdratio"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_cd_ratio" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selcdratio=mysqli_query($db,"select distinct cdratio from prescription_analysis");
							 while($rowcdratio=mysqli_fetch_array($selcdratio))
							 {
							?>
							<option><?php echo $rowcdratio["cdratio"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">Blood vessels</td>
<td colspan="6">&nbsp;</td>
<td colspan="6">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td colspan="2">Disc</td>
<td colspan="6"><select name="od_bv_disc" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selbvdisc=mysqli_query($db,"select distinct bvdisc from prescription_analysis");
							 while($rowbvdisc=mysqli_fetch_array($selbvdisc))
							 {
							?>
							<option><?php echo $rowbvdisc["bvdisc"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_bv_disc" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selbvdisc=mysqli_query($db,"select distinct bvdisc from prescription_analysis");
							 while($rowbvdisc=mysqli_fetch_array($selbvdisc))
							 {
							?>
							<option><?php echo $rowbvdisc["bvdisc"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td colspan="2">GF</td>
<td colspan="6"><select name="od_bv_gf" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selbvgf=mysqli_query($db,"select distinct bvgf from prescription_analysis");
							 while($rowbvgf=mysqli_fetch_array($selbvgf))
							 {
							?>
							<option><?php echo $rowbvgf["bvgf"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"> <select name="os_bv_gf" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selbvgf=mysqli_query($db,"select distinct bvgf from prescription_analysis");
							 while($rowbvgf=mysqli_fetch_array($selbvgf))
							 {
							?>
							<option><?php echo $rowbvgf["bvgf"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td colspan="2">&nbsp;</td>
<td colspan="6">&nbsp;</td>
<td colspan="6">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">Macula</td>
<td colspan="6"><select name="od_macula[]" class="form-control">
							<option value="">----Select Macula for OD----</option>
							<?php
							 $selmacula=mysqli_query($db,"select distinct macula from prescription_analysis");
							 while($rowmacula=mysqli_fetch_array($selmacula))
							 {
							?>
							<option><?php echo $rowmacula["macula"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_macula[]" class="form-control">
							<option value="">----Select Macula for OS----</option>
							<?php
							 $selmacula=mysqli_query($db,"select distinct macula from prescription_analysis");
							 while($rowmacula=mysqli_fetch_array($selmacula))
							 {
							?>
							<option><?php echo $rowmacula["macula"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td colspan="6"><select name="od_macula[]" class="form-control">
							<option value="">----Select Macula for OD----</option>
							<?php
							 $selmacula=mysqli_query($db,"select distinct macula from prescription_analysis");
							 while($rowmacula=mysqli_fetch_array($selmacula))
							 {
							?>
							<option><?php echo $rowmacula["macula"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_macula[]" class="form-control">
							<option value="">----Select Macula for OS----</option>
							<?php
							 $selmacula=mysqli_query($db,"select distinct macula from prescription_analysis");
							 while($rowmacula=mysqli_fetch_array($selmacula))
							 {
							?>
							<option><?php echo $rowmacula["macula"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">&nbsp;</td>
<td colspan="6"><select name="od_macula[]" class="form-control">
							<option value="">----Select Macula for OD----</option>
							<?php
							 $selmacula=mysqli_query($db,"select distinct macula from prescription_analysis");
							 while($rowmacula=mysqli_fetch_array($selmacula))
							 {
							?>
							<option><?php echo $rowmacula["macula"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select name="os_macula[]" class="form-control">
							<option value="">----Select Macula for OS----</option>
							<?php
							 $selmacula=mysqli_query($db,"select distinct macula from prescription_analysis");
							 while($rowmacula=mysqli_fetch_array($selmacula))
							 {
							?>
							<option><?php echo $rowmacula["macula"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">General fundus</td>
<td colspan="6"><select name="od_gf[]" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selgf=mysqli_query($db,"select distinct gf from prescription_analysis");
							 while($rowgf=mysqli_fetch_array($selgf))
							 {
							?>
							<option><?php echo $rowgf["gf"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select id="os_gf[]" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selgf=mysqli_query($db,"select distinct gf from prescription_analysis");
							 while($rowgf=mysqli_fetch_array($selgf))
							 {
							?>
							<option><?php echo $rowgf["gf"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3" rowspan="2">&nbsp;</td>
<td colspan="6"><select name="od_gf[]" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selgf=mysqli_query($db,"select distinct gf from prescription_analysis");
							 while($rowgf=mysqli_fetch_array($selgf))
							 {
							?>
							<option><?php echo $rowgf["gf"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select id="os_gf[]" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selgf=mysqli_query($db,"select distinct gf from prescription_analysis");
							 while($rowgf=mysqli_fetch_array($selgf))
							 {
							?>
							<option><?php echo $rowgf["gf"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="6"><select name="od_gf[]" class="form-control">
							<option value="">----Select for OD----</option>
							<?php
							 $selgf=mysqli_query($db,"select distinct gf from prescription_analysis");
							 while($rowgf=mysqli_fetch_array($selgf))
							 {
							?>
							<option><?php echo $rowgf["gf"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td colspan="6"><select id="os_gf[]" class="form-control">
							<option value="">----Select for OS----</option>
							<?php
							 $selgf=mysqli_query($db,"select distinct gf from prescription_analysis");
							 while($rowgf=mysqli_fetch_array($selgf))
							 {
							?>
							<option><?php echo $rowgf["gf"];?></option>
							<?php
							 }
							 ?>
							 </select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">Special tests</td>
<td colspan="6">&nbsp;</td>
<td colspan="6">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">Syringing</td>
<td colspan="6"><input class = "form-control" type = "text" name = "od_syringing" placeholder="Syringing for OD"></td>
<td colspan="6"><input class = "form-control" type = "text" name = "os_syringing" placeholder="Syringing for OS"></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">Shirmers test</td>
<td colspan="6"><input class = "form-control" type = "text" name = "od_shirmers_test" placeholder="For OD"></td>
<td colspan="6"><input class = "form-control" type = "text" name = "os_shirmers_test" placeholder="For OS"></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">Gonioscopy</td>
<td colspan="6"><input class = "form-control" type = "text" name = "od_gonioscopy" placeholder="For OD"></td>
<td colspan="6"><input class = "form-control" type = "text" name = "os_gonioscopy" placeholder="For OS"></td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">&nbsp;</td>
<td colspan="6">&nbsp;</td>
<td colspan="6">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">&nbsp;</td>
<td colspan="6">&nbsp;</td>
<td colspan="6">&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td colspan="3">Photograph No.</td>
<td colspan="6"><input class = "form-control" type = "text" name = "od_phno" placeholder="For OD"></td>
<td colspan="6"><input class = "form-control" type = "text" name = "os_phno" placeholder="For OS"></td>
<td>&nbsp;</td>
</tr>
</tbody>
</table>
<br>
<button  class = "btn btn-warning" name = "submit" ><span class = "glyphicon glyphicon-edit"></span> SAVE</button>
				</form>
			</div>	
		</div>	
	</div>
	<div id = "footer">
		<label class = "footer-title">&copy; Copyright EyeCare 2022</label>
	</div>
<?php require'script.php' ?>
<script type = "text/javascript">
    $(document).ready(function() {
        function disableBack() { window.history.forward() }

        window.onload = disableBack();
        window.onpageshow = function(evt) { if (evt.persisted) disableBack() }
</script>
</body>
</html>