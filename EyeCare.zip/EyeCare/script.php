<script src = "js/bootstrap.js"></script>
<script src = "js/jquery.min.js"></script>
<script src = "js/dropdown.js"></script>
<script src = "js/sidebar.js"></script>
<script src = "js/jquery.dataTables.js"></script>
<script src = "js/custom.js"></script>
<script type = "text/javascript">
	$(document).ready(function() {
		$('#table').DataTable();
		$('#table1').DataTable();
	});
	
</script>
